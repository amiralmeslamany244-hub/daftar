// Device fingerprint / face unlock via WebAuthn platform authenticator. Fully local: the device
// verifies the user, the app only checks that this device's saved credential answered.
const b64 = (b: ArrayBuffer) => btoa(String.fromCharCode(...new Uint8Array(b))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
const unb64 = (s: string) => Uint8Array.from(atob(s.replace(/-/g, "+").replace(/_/g, "/")), (c) => c.charCodeAt(0));
const rnd = (n: number) => crypto.getRandomValues(new Uint8Array(n));

export async function bioSupported() {
  try {
    return typeof window !== "undefined" && !!window.PublicKeyCredential && window.isSecureContext &&
      (await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable());
  } catch { return false; }
}

/** Registers this device's fingerprint/face. Returns the credential id to store. */
export async function bioRegister(name: string): Promise<string> {
  const cred = (await navigator.credentials.create({
    publicKey: {
      challenge: rnd(32), rp: { name: "دفتر زمرد" },
      user: { id: rnd(16), name, displayName: name },
      pubKeyCredParams: [{ type: "public-key", alg: -7 }, { type: "public-key", alg: -257 }],
      authenticatorSelection: { authenticatorAttachment: "platform", userVerification: "required", residentKey: "discouraged" },
      timeout: 60_000, attestation: "none",
    },
  })) as PublicKeyCredential | null;
  if (!cred) throw new Error("cancelled");
  return b64(cred.rawId);
}

/** Asks the device to verify the owner's fingerprint/face. Resolves true only on success. */
export async function bioVerify(id: string): Promise<boolean> {
  try {
    const cred = (await navigator.credentials.get({
      publicKey: { challenge: rnd(32), allowCredentials: [{ type: "public-key", id: unb64(id) }], userVerification: "required", timeout: 60_000 },
    })) as PublicKeyCredential | null;
    return !!cred && b64(cred.rawId) === id;
  } catch { return false; }
}
