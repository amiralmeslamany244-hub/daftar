import { describe, it, expect } from "vitest";
import { buildSchedule, planRows, totals, emptyDB, addPeriod, hash, whatsappLink, type Plan, type DB } from "./store";

const plan: Plan = { id: "p", customerId: "c", item: "ثلاجة", total: 1200, down: 200, count: 10, everyDays: 30, start: "2026-01-10", createdAt: "" };
const db = (payments: number[] = [], opening = 0, expenses: number[] = []): DB => ({
  ...emptyDB(), settings: { ...emptyDB().settings, opening },
  plans: [plan], installments: buildSchedule(plan),
  payments: payments.map((a, i) => ({ id: "x" + i, planId: "p", amount: a, date: "2026-01-10", note: "" })),
  expenses: expenses.map((a, i) => ({ id: "e" + i, title: "", category: "", amount: a, date: "2026-01-10" })),
});

describe("installment schedule", () => {
  it("splits total minus down payment into equal installments", () => {
    const s = buildSchedule(plan);
    expect(s).toHaveLength(10);
    expect(s[0]!.amount).toBe(100);
  });
  it("monthly installments keep the start day", () => expect(addPeriod("2026-01-10", 2, 30)).toBe("2026-03-10"));
  it("month-end start clamps to shorter months", () => expect(addPeriod("2026-01-31", 1, 30)).toBe("2026-02-28"));
  it("weekly schedule adds 7 days", () => expect(addPeriod("2026-01-10", 1, 7)).toBe("2026-01-17"));
});

describe("payments and status", () => {
  it("payments fill the oldest installment first", () => {
    const r = planRows(db([150]), "p", "2026-01-10");
    expect(r[0]!.status).toBe("paid");
    expect(r[1]!.left).toBe(50);
  });
  it("unpaid past installments are overdue", () => {
    const r = planRows(db([100]), "p", "2026-03-15");
    expect(r.filter((x) => x.status === "overdue")).toHaveLength(2);
  });
});

describe("treasury", () => {
  it("cash = opening + down payments + payments − expenses", () => expect(totals(db([100], 500, [50])).cash).toBe(750));
  it("overpayment becomes customer credit", () => expect(totals(db([1100])).credit).toBe(100));
});

describe("recovery word", () => {
  it("ignores surrounding spaces", async () => expect(await hash(" جدة ")).toBe(await hash("جدة")));
});

describe("whatsapp", () => {
  it("local Egyptian number gets 20", () => expect(whatsappLink("01001234567", "x")).toBe("https://wa.me/201001234567?text=x"));
  it("Saudi code when chosen", () => expect(whatsappLink("0551234567", "x", "966")).toBe("https://wa.me/966551234567?text=x"));
});

import { customerRating } from "./store";
const pay = (d: DB, rows: [number, string][]): DB => ({ ...d, customers: [{ id: "c", name: "", phone: "", address: "", notes: "", archived: false, createdAt: "" }],
  payments: rows.map(([amount, date], i) => ({ id: "r" + i, planId: "p", amount, date, note: "" })) });
describe("customer rating", () => {
  it("no installment due yet is new", () => expect(customerRating(pay(db(), []), "c", "2026-01-05")).toBe("new"));
  it("paying every installment on time is regular", () =>
    expect(customerRating(pay(db(), [[100, "2026-01-10"], [100, "2026-02-10"], [100, "2026-03-11"]]), "c", "2026-03-20")).toBe("regular"));
  it("paying within the 3-day grace still counts as on time", () =>
    expect(customerRating(pay(db(), [[100, "2026-01-13"]]), "c", "2026-01-20")).toBe("regular"));
  it("one late installment out of three is sometimes late", () =>
    expect(customerRating(pay(db(), [[100, "2026-01-10"], [100, "2026-02-25"], [100, "2026-03-10"]]), "c", "2026-03-20")).toBe("sometimes"));
  it("three unpaid overdue installments is defaulting", () =>
    expect(customerRating(pay(db(), []), "c", "2026-03-20")).toBe("defaulting"));
});

import { toNum } from "./store";
describe("toNum", () => {
  it("reads Arabic-Indic digits", () => expect(toNum("١٠٠٠٠")).toBe(10000));
  it("reads Arabic decimal mark", () => expect(toNum("٢٥٠٫٥")).toBe(250.5));
  it("reads Persian digits", () => expect(toNum("۱۲۰")).toBe(120));
  it("ignores thousands separators", () => expect(toNum("10,000")).toBe(10000));
  it("returns NaN for empty or text", () => { expect(toNum("")).toBeNaN(); expect(toNum("abc")).toBeNaN(); });
});

import { can, matchLogin, matchPin, hashPin, backupDue, type Auth } from "./store";
describe("users & permissions", () => {
  it("owner can delete and open settings", () => { expect(can("owner", "delete")).toBe(true); expect(can("owner", "settings")).toBe(true); });
  it("staff cannot delete, archive, or open reports/log/backups/settings", () => {
    for (const a of ["delete", "archive", "reports", "log", "backups", "settings"] as const) expect(can("staff", a)).toBe(false);
  });
  const mk = async (): Promise<Auth> => ({ user: "owner", pass: await hash("1234"), recovery: await hash("rec1"), enabled: true, pin: await hashPin("1111"),
    staff: [{ id: "s1", name: "سامي", user: "sami", pass: await hash("abcd"), pin: await hashPin("2222"), active: true },
            { id: "s2", name: "موقوف", user: "off", pass: await hash("abcd"), pin: await hashPin("3333"), active: false }] });
  it("password login identifies owner and staff", async () => {
    const a = await mk();
    expect((await matchLogin(a, "owner", "1234"))?.role).toBe("owner");
    expect(await matchLogin(a, "sami", "abcd")).toEqual({ role: "staff", name: "سامي", staffId: "s1" });
    expect(await matchLogin(a, "sami", "wrong")).toBeNull();
  });
  it("PIN identifies the user; suspended staff are refused", async () => {
    const a = await mk();
    expect((await matchPin(a, "1111"))?.role).toBe("owner");
    expect((await matchPin(a, "2222"))?.staffId).toBe("s1");
    expect(await matchPin(a, "3333")).toBeNull();
    expect(await matchPin(a, "9999")).toBeNull();
  });
  it("PIN is not the same as a password with the same digits", async () => {
    const a = await mk();
    expect(await matchPin(a, "1234")).toBeNull();
  });
});
describe("backup reminder", () => {
  const s = emptyDB().settings;
  it("is due when no backup was ever made", () => expect(backupDue({ ...s, backupEveryDays: 7 })).toBe(true));
  it("is due after the chosen number of days", () => {
    const now = new Date("2026-11-17T12:00:00Z").getTime();
    expect(backupDue({ ...s, backupEveryDays: 7, lastBackup: "2026-11-10T12:00:00Z" }, now)).toBe(true);
    expect(backupDue({ ...s, backupEveryDays: 7, lastBackup: "2026-11-12T12:00:00Z" }, now)).toBe(false);
  });
  it("never nags when reminders are off", () => expect(backupDue({ ...s, backupEveryDays: 0 })).toBe(false));
});

import { thermalHtml } from "../components/app/extras";
describe("thermal receipt", () => {
  const r = { shop: "محل <تجربة>", customer: "أحمد", phone: "010", item: "ثلاجة", amount: 1500, date: "2026-11-17", left: 7500, sym: "ج.م", no: "00001" };
  it("uses a 58 mm page with 48 mm print width", () => { const h = thermalHtml(r, "58"); expect(h).toContain("size: 58mm auto"); expect(h).toContain("width: 48mm"); });
  it("uses an 80 mm page with 72 mm print width", () => { const h = thermalHtml(r, "80"); expect(h).toContain("size: 80mm auto"); expect(h).toContain("width: 72mm"); });
  it("shows the amount and remaining balance", () => { const h = thermalHtml(r, "80"); expect(h).toContain("1,500 ج.م"); expect(h).toContain("7,500 ج.م"); });
  it("escapes shop name so it can't break the page", () => expect(thermalHtml(r, "58")).toContain("محل &lt;تجربة&gt;"));
});
