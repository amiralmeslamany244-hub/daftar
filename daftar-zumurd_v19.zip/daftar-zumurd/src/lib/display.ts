// Per-device display preferences. Kept outside the ledger so they apply on the lock screen too.
export type Theme = "dark" | "light";
export type Paper = "58" | "80";
export type Display = { theme: Theme; scale: number; paper: Paper };
export const SCALES = [{ v: 1, label: "عادي" }, { v: 1.125, label: "كبير" }, { v: 1.25, label: "كبير جدًا" }];
const KEY = "zumurd_display_v1";
export const DEFAULT_DISPLAY: Display = { theme: "dark", scale: 1, paper: "80" };

export function loadDisplay(): Display {
  try { return { ...DEFAULT_DISPLAY, ...JSON.parse(localStorage.getItem(KEY) ?? "{}") }; } catch { return DEFAULT_DISPLAY; }
}
export function applyDisplay(d: Display) {
  const h = document.documentElement;
  h.classList.toggle("light", d.theme === "light");
  h.style.fontSize = `${d.scale * 100}%`;
  document.querySelector('meta[name="theme-color"]')?.setAttribute("content", d.theme === "light" ? "#f4f1e8" : "#0c1f19");
}
export function saveDisplay(d: Display) { localStorage.setItem(KEY, JSON.stringify(d)); applyDisplay(d); window.dispatchEvent(new Event("zumurd-display")); }
