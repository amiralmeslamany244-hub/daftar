// Local-only data model for Daftar Zumurd. Everything lives in localStorage on this device.
export type CustomerDoc = { id: string; name: string; data: string; at: string };
export type Guarantor = { name: string; phone: string; address: string; idNo: string };
export type Customer = { id: string; name: string; phone: string; address: string; notes: string; archived: boolean; createdAt: string; guarantor?: Guarantor | undefined; docs?: CustomerDoc[] };
export type Plan = { id: string; customerId: string; item: string; total: number; down: number; count: number; everyDays: number; start: string; createdAt: string };
export type Postpone = { from: string; to: string; reason: string; at: string };
export type Installment = { id: string; planId: string; n: number; due: string; amount: number; history?: Postpone[] };
export type PayMethod = "cash" | "bank" | "wallet";
export type PayKind = "installment" | "partial" | "credit";
export type Payment = { id: string; planId: string; amount: number; date: string; note: string; method?: PayMethod; kind?: PayKind };
export type Expense = { id: string; title: string; category: string; amount: number; date: string };
export type LogKind = "payment" | "expense" | "customer" | "plan" | "security";
export type LogEntry = { id: string; kind: LogKind; text: string; at: string };
export type BackupMeta = { id: string; at: string; size: number; counts: string };
export type Settings = { shop: string; currency: string; opening: number; backupEveryDays: number; autoLockMin: number; lastBackup?: string; dailyReminder?: boolean; lastReminder?: string | undefined; logo?: string | undefined };
export type Staff = { id: string; name: string; user: string; pass: string; pin?: string | undefined; active: boolean };
export type Auth = {
  user: string; pass: string; recovery: string; enabled: boolean;
  /** Owner's quick-unlock PIN (hashed). */ pin?: string | undefined;
  /** WebAuthn credential id (base64url) for device fingerprint / face unlock. */ bio?: string | undefined;
  staff?: Staff[];
};
export type Role = "owner" | "staff";
export type Session = { role: Role; name: string; staffId?: string | undefined };
export type DB = {
  settings: Settings; customers: Customer[]; plans: Plan[]; installments: Installment[];
  payments: Payment[]; expenses: Expense[]; log: LogEntry[]; backups: BackupMeta[]; trash: TrashItem[];
};
export type TrashItem = { id: string; kind: "customer" | "plan" | "payment" | "expense"; label: string; at: string;
  data: { customers?: Customer[]; plans?: Plan[]; installments?: Installment[]; payments?: Payment[]; expenses?: Expense[] } };

export const CURRENCIES = [
  { code: "EGP", label: "الجنيه المصري — ج.م", sym: "ج.م", cc: "20" },
  { code: "SAR", label: "الريال السعودي — ر.س", sym: "ر.س", cc: "966" },
  { code: "AED", label: "الدرهم الإماراتي — د.إ", sym: "د.إ", cc: "971" },
  { code: "KWD", label: "الدينار الكويتي — د.ك", sym: "د.ك", cc: "965" },
  { code: "QAR", label: "الريال القطري — ر.ق", sym: "ر.ق", cc: "974" },
  { code: "BHD", label: "الدينار البحريني — د.ب", sym: "د.ب", cc: "973" },
  { code: "OMR", label: "الريال العماني — ر.ع", sym: "ر.ع", cc: "968" },
  { code: "JOD", label: "الدينار الأردني — د.أ", sym: "د.أ", cc: "962" },
  { code: "IQD", label: "الدينار العراقي — د.ع", sym: "د.ع", cc: "964" },
  { code: "LYD", label: "الدينار الليبي — د.ل", sym: "د.ل", cc: "218" },
  { code: "USD", label: "الدولار الأمريكي — $", sym: "$", cc: "1" },
];
export const cur = (s: Settings) => CURRENCIES.find((c) => c.code === s.currency) ?? CURRENCIES[0]!;

const KEY_DB = "zumurd_db_v4";
const KEY_AUTH = "zumurd_auth_v4";
const KEY_OLD_AUTH = "zumurd_auth";
const KEY_OLD_DATA = "zumurd_data";

export const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
export const todayISO = (d = new Date()) => {
  const z = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
  return z.toISOString().slice(0, 10);
};

export async function hash(s: string) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s.trim()));
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

export const emptyDB = (shop = "دفتر زمرد"): DB => ({
  settings: { shop, currency: "EGP", opening: 0, backupEveryDays: 7, autoLockMin: 0 },
  customers: [], plans: [], installments: [], payments: [], expenses: [], log: [], backups: [], trash: [],
});

export function loadDB(): DB | null {
  const raw = localStorage.getItem(KEY_DB);
  if (!raw) return null;
  const d = { ...emptyDB(), ...JSON.parse(raw) } as DB; d.trash ??= []; return d;
}
export const saveDB = (d: DB) => localStorage.setItem(KEY_DB, JSON.stringify(d));
export function loadAuth(): Auth | null {
  const a = localStorage.getItem(KEY_AUTH);
  if (a) return JSON.parse(a);
  // Older version kept shop + credentials together; reuse its credentials.
  const old = localStorage.getItem(KEY_OLD_AUTH);
  if (old) { const o = JSON.parse(old); return { user: o.user, pass: o.pass, recovery: o.recovery, enabled: true }; }
  return null;
}
export const oldShopName = (): string | null => { const o = localStorage.getItem(KEY_OLD_AUTH); return o ? JSON.parse(o).shop ?? null : null; };
export const saveAuth = (a: Auth) => localStorage.setItem(KEY_AUTH, JSON.stringify(a));

export const log = (d: DB, kind: LogKind, text: string): DB => ({
  ...d, log: [{ id: uid(), kind, text, at: new Date().toISOString() }, ...d.log].slice(0, 1000),
});

/** Add `n` steps of a schedule to a start date: every 30 days → calendar months, otherwise plain days. */
export function addPeriod(start: string, n: number, everyDays: number) {
  const d = new Date(start + "T00:00:00");
  if (everyDays === 30) {
    const day = d.getDate();
    d.setDate(1); d.setMonth(d.getMonth() + n);
    const last = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
    d.setDate(Math.min(day, last));
  } else d.setDate(d.getDate() + n * everyDays);
  return todayISO(d);
}

/** Split (total − down) into `count` installments; rounding remainder goes to the last one. */
export function buildSchedule(p: Plan): Installment[] {
  const base = p.total - p.down;
  if (p.count <= 0 || base <= 0) return [];
  const each = Math.floor((base / p.count) * 100) / 100;
  return Array.from({ length: p.count }, (_, i) => ({
    id: `${p.id}_${i + 1}`, planId: p.id, n: i + 1, due: addPeriod(p.start, i, p.everyDays),
    amount: i === p.count - 1 ? Math.round((base - each * (p.count - 1)) * 100) / 100 : each,
  }));
}

export type InstStatus = "paid" | "today" | "overdue" | "upcoming";
export type InstRow = Installment & { paid: number; left: number; status: InstStatus };

/** Payments fill installments oldest-first. */
export function planRows(d: DB, planId: string, today = todayISO()): InstRow[] {
  let pool = paidFor(d, planId);
  return d.installments.filter((i) => i.planId === planId).sort((a, b) => a.n - b.n).map((i) => {
    const paid = Math.min(pool, i.amount); pool = Math.max(0, pool - paid);
    const left = Math.round((i.amount - paid) * 100) / 100;
    const status: InstStatus = left <= 0 ? "paid" : i.due < today ? "overdue" : i.due === today ? "today" : "upcoming";
    return { ...i, paid, left, status };
  });
}
export const allRows = (d: DB, today = todayISO()) => d.plans.flatMap((p) => planRows(d, p.id, today));

export const paidFor = (d: DB, planId: string) => d.payments.filter((p) => p.planId === planId).reduce((s, p) => s + p.amount, 0);
export const planRemaining = (d: DB, p: Plan) => Math.max(0, p.total - p.down - paidFor(d, p.id));
/** Money paid beyond what a plan owes. */
export const planCredit = (d: DB, p: Plan) => Math.max(0, paidFor(d, p.id) - (p.total - p.down));

export function totals(d: DB, today = todayISO()) {
  const rows = allRows(d, today);
  const sum = (f: (r: InstRow) => boolean) => rows.filter(f).reduce((s, r) => s + r.left, 0);
  const downs = d.plans.reduce((s, p) => s + p.down, 0);
  const payments = d.payments.reduce((s, p) => s + p.amount, 0);
  const collected = downs + payments;
  const expenses = d.expenses.reduce((s, e) => s + e.amount, 0);
  return {
    collected, expenses, cash: d.settings.opening + collected - expenses,
    remaining: d.plans.reduce((s, p) => s + planRemaining(d, p), 0),
    overdue: sum((r) => r.status === "overdue"), dueToday: sum((r) => r.status === "today"),
    upcoming: sum((r) => r.status === "upcoming"),
    credit: d.plans.reduce((s, p) => s + planCredit(d, p), 0),
    overdueCount: rows.filter((r) => r.status === "overdue").length,
    activeCustomers: d.customers.filter((c) => !c.archived).length,
  };
}

export const customerRemaining = (d: DB, customerId: string) =>
  d.plans.filter((p) => p.customerId === customerId).reduce((s, p) => s + planRemaining(d, p), 0);

export const fmt = (n: number) => new Intl.NumberFormat("en-US", { maximumFractionDigits: 2 }).format(n);
export const dateAr = (iso: string) => new Date(iso.length === 10 ? iso + "T00:00:00" : iso)
  .toLocaleDateString("ar-EG-u-nu-latn", { year: "numeric", month: "long", day: "numeric" });

export function whatsappLink(phone: string, text: string, cc = "20") {
  let p = phone.replace(/[^\d]/g, "");
  if (p.startsWith("00")) p = p.slice(2);
  else if (p.startsWith("0")) p = cc + p.slice(1);
  return `https://wa.me/${p}?text=${encodeURIComponent(text)}`;
}

/** One-time import of the previous app version's data (customers / sales / payments). */
export function importOld(d: DB): { db: DB; added: number } | null {
  const raw = localStorage.getItem(KEY_OLD_DATA);
  if (!raw) return null;
  const old = JSON.parse(raw) as { customers: { id: string; name: string; phone: string; notes: string }[];
    sales: { id: string; customerId: string; item: string; total: number; down: number; count: number; start: string }[];
    payments: { id: string; saleId: string; amount: number; date: string; note: string }[] };
  const now = new Date().toISOString();
  const has = (arr: { id: string }[], id: string) => arr.some((x) => x.id === id);
  const customers = old.customers.filter((c) => !has(d.customers, c.id)).map((c) => ({ ...c, address: "", archived: false, createdAt: now }));
  const plans = old.sales.filter((s) => !has(d.plans, s.id)).map((s) => ({ ...s, everyDays: 30, createdAt: now }));
  const payments = old.payments.filter((p) => !has(d.payments, p.id)).map((p) => ({ id: p.id, planId: p.saleId, amount: p.amount, date: p.date, note: p.note }));
  const db = { ...d, customers: [...d.customers, ...customers], plans: [...d.plans, ...plans],
    installments: [...d.installments, ...plans.flatMap(buildSchedule)], payments: [...d.payments, ...payments] };
  return { db: log(db, "security", `نسخ البيانات القديمة: ${customers.length} عميل، ${plans.length} خطة`), added: customers.length + plans.length };
}

/** Restore merges by id: adds missing rows and updates existing ones, never deletes. */
export function mergeBackup(d: DB, b: DB): DB {
  const m = <T extends { id: string }>(a: T[], c: T[] = []) => { const map = new Map(a.map((x) => [x.id, x])); c.forEach((x) => map.set(x.id, x)); return [...map.values()]; };
  return { ...d, settings: { ...d.settings, ...b.settings }, customers: m(d.customers, b.customers), plans: m(d.plans, b.plans),
    installments: m(d.installments, b.installments), payments: m(d.payments, b.payments), expenses: m(d.expenses, b.expenses), trash: m(d.trash ?? [], b.trash ?? []),
    log: m(d.log, b.log).sort((x, y) => y.at.localeCompare(x.at)) };
}

/** Date each installment was fully covered by payments (waterfall in payment-date order), or null if still open. */
export function coveredDates(d: DB, planId: string): (string | null)[] {
  const inst = d.installments.filter((i) => i.planId === planId).sort((a, b) => a.n - b.n);
  const pays = d.payments.filter((p) => p.planId === planId).sort((a, b) => a.date.localeCompare(b.date));
  let pi = 0, carry = 0;
  return inst.map((i) => {
    let need = i.amount;
    while (need > 0.0001) {
      if (carry <= 0) { const p = pays[pi++]; if (!p) return null; carry = p.amount; }
      const take = Math.min(carry, need); carry -= take; need -= take;
    }
    return pays[Math.max(0, pi - 1)]?.date ?? null;
  });
}

export type Rating = "new" | "regular" | "sometimes" | "defaulting";
export const RATING_LABEL: Record<Rating, string> = { new: "جديد", regular: "منتظم", sometimes: "متأخر أحيانًا", defaulting: "متعثر" };
const GRACE_DAYS = 3;
/** Rates a customer from their payment history: an installment is late if paid (or still unpaid) more than GRACE_DAYS after its due date. */
export function customerRating(d: DB, customerId: string, today = todayISO()): Rating {
  let due = 0, late = 0, openLate = 0;
  for (const p of d.plans.filter((x) => x.customerId === customerId)) {
    const inst = d.installments.filter((i) => i.planId === p.id).sort((a, b) => a.n - b.n);
    const cov = coveredDates(d, p.id);
    inst.forEach((i, k) => {
      if (i.due > today) return;
      due++;
      const limit = addPeriod(i.due, 1, GRACE_DAYS);
      const c = cov[k];
      if (c == null) { if (today > limit) { late++; openLate++; } }
      else if (c > limit) late++;
    });
  }
  if (due === 0) return "new";
  if (openLate >= 3 || late / due > 0.5) return "defaulting";
  return late === 0 ? "regular" : "sometimes";
}

/** Parse a typed amount: accepts Arabic-Indic (٠-٩) and Persian (۰-۹) digits, Arabic decimal/thousands marks and spaces. Returns NaN when invalid. */
export function toNum(v: string | number): number {
  if (typeof v === "number") return v;
  const s = v.trim()
    .replace(/[٠-٩]/g, (c) => String(c.charCodeAt(0) - 0x660))
    .replace(/[۰-۹]/g, (c) => String(c.charCodeAt(0) - 0x6f0))
    .replace(/٫/g, ".").replace(/[٬,\s]/g, "");
  return s === "" ? NaN : Number(s);
}

/* ---------- Users & permissions ---------- */
export type Action = "delete" | "archive" | "reports" | "log" | "backups" | "settings";
const STAFF_DENIED: Action[] = ["delete", "archive", "reports", "log", "backups", "settings"];
/** The owner can do everything; staff can add customers, plans, payments and expenses but cannot delete, archive or open reports/log/backups/settings. */
export const can = (role: Role, a: Action) => role === "owner" || !STAFF_DENIED.includes(a);

/** Which user (if any) a username + password belongs to. */
export async function matchLogin(a: Auth, user: string, pass: string): Promise<Session | null> {
  const u = user.trim(); const h = await hash(pass);
  if (u === a.user && h === a.pass) return { role: "owner", name: a.user };
  const s = (a.staff ?? []).find((x) => x.active && x.user === u && x.pass === h);
  return s ? { role: "staff", name: s.name, staffId: s.id } : null;
}
/** Which user (if any) a PIN belongs to. */
export async function matchPin(a: Auth, pin: string): Promise<Session | null> {
  if (!pin) return null;
  const h = await hash("pin:" + pin);
  if (a.pin && a.pin === h) return { role: "owner", name: a.user };
  const s = (a.staff ?? []).find((x) => x.active && x.pin === h);
  return s ? { role: "staff", name: s.name, staffId: s.id } : null;
}
export const hashPin = (pin: string) => hash("pin:" + pin);
export const validPin = (pin: string) => /^\d{4,6}$/.test(pin);
export const hasAnyPin = (a: Auth) => !!a.pin || (a.staff ?? []).some((x) => x.active && !!x.pin);
/** True when another user already uses this PIN (PINs must be unique so they identify the user). */
export async function pinTaken(a: Auth, pin: string, exceptStaffId?: string, exceptOwner = false) {
  const h = await hashPin(pin);
  if (!exceptOwner && a.pin === h) return true;
  return (a.staff ?? []).some((x) => x.id !== exceptStaffId && x.pin === h);
}
export const usernameTaken = (a: Auth, user: string, exceptStaffId?: string) =>
  user.trim() === a.user || (a.staff ?? []).some((x) => x.id !== exceptStaffId && x.user === user.trim());

/* ---------- Backups ---------- */
export function backupDue(s: Settings, now = Date.now()) {
  return s.backupEveryDays > 0 && (!s.lastBackup || (now - new Date(s.lastBackup).getTime()) / 864e5 >= s.backupEveryDays);
}
export function backupFile(d: DB, at = new Date().toISOString()) {
  const body = JSON.stringify({ app: "daftar-zumurd", version: 4, at, db: d });
  return { body, name: `daftar-zumurd-${at.slice(0, 10)}.json`, at };
}
export const recordBackup = (d: DB, at: string, size: number, via: string): DB => log({ ...d, settings: { ...d.settings, lastBackup: at },
  backups: [{ id: uid(), at, size, counts: `${d.customers.length} عميل · ${d.plans.length} خطة · ${d.payments.length} دفعة` }, ...d.backups].slice(0, 30) }, "security", `إنشاء نسخة احتياطية (${via})`);

/* ---------- Trash (soft delete) ---------- */
const sameIds = <T extends { id: string }>(a: T[], ids: Set<string>) => a.filter((x) => !ids.has(x.id));
/** Moves records into the trash; they come back intact with restoreTrash. */
export function toTrash(d: DB, kind: TrashItem["kind"], label: string, data: TrashItem["data"]): DB {
  const ids = (a?: { id: string }[]) => new Set((a ?? []).map((x) => x.id));
  const item: TrashItem = { id: uid(), kind, label, at: new Date().toISOString(), data };
  return {
    ...d,
    customers: sameIds(d.customers, ids(data.customers)), plans: sameIds(d.plans, ids(data.plans)),
    installments: sameIds(d.installments, ids(data.installments)), payments: sameIds(d.payments, ids(data.payments)),
    expenses: sameIds(d.expenses, ids(data.expenses)), trash: [item, ...(d.trash ?? [])].slice(0, 500),
  };
}
export function restoreTrash(d: DB, id: string): DB {
  const t = (d.trash ?? []).find((x) => x.id === id);
  if (!t) return d;
  const add = <T extends { id: string }>(a: T[], b?: T[]) => { const have = new Set(a.map((x) => x.id)); return [...a, ...(b ?? []).filter((x) => !have.has(x.id))]; };
  return {
    ...d, customers: add(d.customers, t.data.customers), plans: add(d.plans, t.data.plans), installments: add(d.installments, t.data.installments),
    payments: add(d.payments, t.data.payments), expenses: add(d.expenses, t.data.expenses), trash: d.trash.filter((x) => x.id !== id),
  };
}
export const trashCustomer = (d: DB, customerId: string): DB => {
  const c = d.customers.find((x) => x.id === customerId); if (!c) return d;
  const plans = d.plans.filter((p) => p.customerId === customerId); const pids = new Set(plans.map((p) => p.id));
  return log(toTrash(d, "customer", `العميل ${c.name}`, { customers: [c], plans, installments: d.installments.filter((i) => pids.has(i.planId)), payments: d.payments.filter((p) => pids.has(p.planId)) }), "customer", `حذف عميل: ${c.name} (إلى سلة المحذوفات)`);
};
export const trashPlan = (d: DB, planId: string): DB => {
  const p = d.plans.find((x) => x.id === planId); if (!p) return d;
  const c = d.customers.find((x) => x.id === p.customerId);
  return log(toTrash(d, "plan", `خطة "${p.item}" — ${c?.name ?? ""}`, { plans: [p], installments: d.installments.filter((i) => i.planId === planId), payments: d.payments.filter((x) => x.planId === planId) }), "plan", `حذف خطة أقساط "${p.item}" (إلى سلة المحذوفات)`);
};
export const trashPayment = (d: DB, payId: string): DB => {
  const x = d.payments.find((p) => p.id === payId); if (!x) return d;
  const p = d.plans.find((y) => y.id === x.planId); const c = d.customers.find((y) => y.id === p?.customerId);
  return log(toTrash(d, "payment", `دفعة ${fmt(x.amount)} — ${c?.name ?? ""}`, { payments: [x] }), "payment", `حذف عملية سداد بمبلغ ${fmt(x.amount)} — ${c?.name ?? ""} (إلى سلة المحذوفات)`);
};
export const trashExpense = (d: DB, id: string): DB => {
  const e = d.expenses.find((x) => x.id === id); if (!e) return d;
  return log(toTrash(d, "expense", `مصروف ${e.title} (${fmt(e.amount)})`, { expenses: [e] }), "expense", `حذف المصروف ${e.title} (إلى سلة المحذوفات)`);
};

/* ---------- Postpone ---------- */
export function postpone(d: DB, instId: string, to: string, reason: string): DB {
  const i = d.installments.find((x) => x.id === instId); if (!i) return d;
  const h: Postpone = { from: i.due, to, reason, at: new Date().toISOString() };
  return log({ ...d, installments: d.installments.map((x) => (x.id === instId ? { ...x, due: to, history: [...(x.history ?? []), h] } : x)) },
    "plan", `تأجيل القسط ${i.n} من ${dateAr(i.due)} إلى ${dateAr(to)}${reason ? ` — ${reason}` : ""}`);
}

/* ---------- Credit settlement ---------- */
/** Moves an amount of a customer's credit (overpayment on one plan) onto another plan's open balance. Not new cash. */
export function settleCredit(d: DB, fromPlanId: string, toPlanId: string, amount: number, date = todayISO()): DB {
  const pays: Payment[] = [
    { id: uid(), planId: fromPlanId, amount: -amount, date, note: "تسوية من الرصيد الدائن", kind: "credit" },
    { id: uid(), planId: toPlanId, amount, date, note: "تسوية رصيد دائن", kind: "credit" },
  ];
  return log({ ...d, payments: [...d.payments, ...pays] }, "payment", `تسوية رصيد دائن بمبلغ ${fmt(amount)}`);
}

/* ---------- Receipt verification code ---------- */
const ALPHA = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
function checkChar(s: string) { let h = 7; for (const ch of s) h = (h * 31 + ch.charCodeAt(0)) >>> 0; return ALPHA[h % ALPHA.length]!; }
/** Receipt code = payment id + amount + date + a check letter, so a hand-edited number or amount is detected. */
export function receiptCode(payId: string, amount: number, date: string) {
  const body = `${payId}.${Math.round(amount * 100)}.${date.replace(/-/g, "")}`;
  return `ZM1.${body}.${checkChar(body)}`;
}
export const receiptNo = (payId: string) => payId.slice(0, 8).toUpperCase();
export type VerifyResult =
  | { ok: "match"; pay: Payment } | { ok: "differs"; pay: Payment; amount: number; date: string }
  | { ok: "missing" } | { ok: "tampered" } | { ok: "invalid" };
export function verifyReceipt(d: DB, raw: string): VerifyResult {
  const s = raw.trim();
  const m = /^ZM1\.([a-z0-9]+)\.(-?\d+)\.(\d{8})\.([A-Z0-9])$/i.exec(s);
  if (!m) {
    const no = s.toUpperCase().replace(/[^A-Z0-9]/g, "");
    const pay = no.length >= 6 ? d.payments.find((p) => receiptNo(p.id) === no) : undefined;
    return pay ? { ok: "match", pay } : s ? (no.length >= 6 ? { ok: "missing" } : { ok: "invalid" }) : { ok: "invalid" };
  }
  const [, id, cents, ymd, chk] = m;
  if (checkChar(`${id}.${cents}.${ymd}`) !== chk!.toUpperCase()) return { ok: "tampered" };
  const pay = d.payments.find((p) => p.id === id);
  if (!pay) return { ok: "missing" };
  const amount = Number(cents) / 100; const date = `${ymd!.slice(0, 4)}-${ymd!.slice(4, 6)}-${ymd!.slice(6)}`;
  return Math.round(pay.amount * 100) === Number(cents) && pay.date === date ? { ok: "match", pay } : { ok: "differs", pay, amount, date };
}

/* ---------- Financial report ---------- */
export const monthKey = (iso: string) => iso.slice(0, 7);
export function monthStats(d: DB, key: string) {
  const end = `${key}-31`;
  const inst = d.installments.filter((i) => i.due.startsWith(key));
  const due = inst.reduce((s, i) => s + i.amount, 0);
  const collected = d.payments.filter((p) => p.date.startsWith(key) && p.kind !== "credit").reduce((s, p) => s + p.amount, 0)
    + d.plans.filter((p) => p.createdAt.startsWith(key)).reduce((s, p) => s + p.down, 0);
  const expenses = d.expenses.filter((e) => e.date.startsWith(key)).reduce((s, e) => s + e.amount, 0);
  const rows = allRows(d, end < todayISO() ? end : todayISO());
  const overdueEnd = rows.filter((r) => r.due <= end && r.status === "overdue").reduce((s, r) => s + r.left, 0);
  return { key, due, collected, expenses, net: collected - expenses, rate: due > 0 ? Math.round((collected / due) * 100) : 0, overdueEnd };
}
export function lastMonths(n: number, now = new Date()) {
  return Array.from({ length: n }, (_, i) => { const x = new Date(now.getFullYear(), now.getMonth() - (n - 1) + i, 1); return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, "0")}`; });
}
export function nextMonths(n: number, now = new Date()) {
  return Array.from({ length: n }, (_, i) => { const x = new Date(now.getFullYear(), now.getMonth() + i, 1); return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, "0")}`; });
}
/** Expected inflow per upcoming month from unpaid installments, minus the average monthly expense of the last 3 months. */
export function cashForecast(d: DB, n = 3) {
  const rows = allRows(d).filter((r) => r.left > 0);
  const avgExp = lastMonths(3).reduce((s, k) => s + d.expenses.filter((e) => e.date.startsWith(k)).reduce((a, e) => a + e.amount, 0), 0) / 3;
  const overdue = rows.filter((r) => r.status === "overdue").reduce((s, r) => s + r.left, 0);
  const months = nextMonths(n).map((k) => { const exp = rows.filter((r) => r.status !== "overdue" && r.due.startsWith(k)).reduce((s, r) => s + r.left, 0); return { key: k, expected: exp, expense: avgExp, net: exp - avgExp }; });
  return { overdue, avgExp, months };
}
/** Delay stats for a customer: average and longest days between due date and full payment. */
export function delayStats(d: DB, customerId: string, today = todayISO()) {
  const days: number[] = [];
  for (const p of d.plans.filter((x) => x.customerId === customerId)) {
    const inst = d.installments.filter((i) => i.planId === p.id).sort((a, b) => a.n - b.n);
    const cov = coveredDates(d, p.id);
    inst.forEach((i, k) => { if (i.due > today) return; const c = cov[k] ?? today; days.push(Math.max(0, Math.round((new Date(c).getTime() - new Date(i.due).getTime()) / 864e5))); });
  }
  return { count: days.length, avg: days.length ? Math.round(days.reduce((a, b) => a + b, 0) / days.length) : 0, max: days.length ? Math.max(...days) : 0, onTime: days.filter((x) => x <= 3).length };
}
