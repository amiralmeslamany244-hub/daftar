import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/** Opens an external link (WhatsApp) reliably on Android/standalone PWA where popups get blocked. */
export function openExternal(url: string) {
  const w = window.open(url, "_blank");
  if (!w) window.location.href = url;
}
