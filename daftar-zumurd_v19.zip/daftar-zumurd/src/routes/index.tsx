import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { applyDisplay, loadDisplay } from "@/lib/display";
import { Lock, Setup } from "@/components/Gate";
import { AppShell } from "@/components/app/AppShell";
import { emptyDB, loadAuth, loadDB, oldShopName, saveAuth, saveDB, type Auth, type DB, type Session } from "@/lib/store";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "دفتر زمرد — دفتر الأقساط والحسابات" },
      { name: "description", content: "العملاء والأقساط والخزينة والمصروفات والتقارير — محفوظة ومقفلة على جهازك." },
      { property: "og:title", content: "دفتر زمرد" },
      { property: "og:description", content: "دفتر الأقساط والحسابات المحلي لمحلك." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  const [ready, setReady] = useState(false);
  const [auth, setAuth] = useState<Auth | null>(null);
  const [db, setDb] = useState<DB | null>(null);
  const [open, setOpen] = useState(false);
  const [session, setSession] = useState<Session | null>(null);
  useEffect(() => {
    applyDisplay(loadDisplay());
    const a = loadAuth();
    let d = loadDB();
    // Upgrading from the previous version: keep its credentials and shop name, start a fresh ledger.
    if (a && !d) { d = emptyDB(oldShopName() ?? "دفتر زمرد"); saveDB(d); saveAuth(a); }
    setAuth(a); setDb(d); setOpen(!!a && !a.enabled); if (a && !a.enabled) setSession({ role: "owner", name: a.user }); setReady(true);
  }, []);
  const lock = useCallback(() => { setDb(loadDB()); setOpen(false); setSession(null); }, []);
  if (!ready) return <div className="min-h-dvh" />;
  if (!auth || !db) return <Setup onDone={(a, d) => { setAuth(a); setDb(d); setSession({ role: "owner", name: a.user }); setOpen(true); }} />;
  if (!open || !session) return <Lock auth={auth} shop={db.settings.shop} onOpen={(a, s) => { setAuth(a); setSession(s); setDb(loadDB()); setOpen(true); }} />;
  return <AppShell key={session.staffId ?? "owner"} db={db} auth={auth} session={session} setAuth={setAuth} onLock={auth.enabled ? lock : () => {}} />;
}
