import { useState, type ReactNode } from "react";
import { DateField, SelectField } from "./fields";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { buildSchedule, fmt, toNum, log, planRemaining, todayISO, uid, type Customer, type PayKind, type PayMethod, type Plan } from "@/lib/store";
import { useApp } from "./ctx";
import { L } from "./ui";
import { ReceiptActions, receiptFor, type ReceiptData } from "./extras";

function Modal({ open, onClose, title, children }: { open: boolean; onClose: () => void; title: string; children: ReactNode }) {
  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent dir="rtl" className="w-[calc(100%-1rem)] max-h-[85dvh] overflow-y-auto overscroll-contain rounded-2xl border-border bg-card text-right">
        <DialogTitle className="text-lg font-bold">{title}</DialogTitle>
        {children}
      </DialogContent>
    </Dialog>
  );
}

export function CustomerDialog({ open, onClose, edit }: { open: boolean; onClose: () => void; edit?: Customer }) {
  const { update } = useApp();
  const [f, setF] = useState({ name: edit?.name ?? "", phone: edit?.phone ?? "", address: edit?.address ?? "", notes: edit?.notes ?? "" });
  const [g, setG] = useState({ name: edit?.guarantor?.name ?? "", phone: edit?.guarantor?.phone ?? "", address: edit?.guarantor?.address ?? "", idNo: edit?.guarantor?.idNo ?? "" });
  const setg = (k: keyof typeof g) => (e: React.ChangeEvent<HTMLInputElement>) => setG({ ...g, [k]: e.target.value });
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setF({ ...f, [k]: e.target.value });
  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!f.name.trim()) { toast.error("اكتب اسم العميل"); return; }
    const guarantor = g.name.trim() ? { ...g, name: g.name.trim() } : undefined;
    update((d) => edit
      ? log({ ...d, customers: d.customers.map((c) => (c.id === edit.id ? { ...c, ...f, name: f.name.trim(), guarantor } : c)) }, "customer", `تعديل بيانات العميل ${f.name}`)
      : log({ ...d, customers: [...d.customers, { id: uid(), ...f, name: f.name.trim(), guarantor, archived: false, createdAt: new Date().toISOString() }] }, "customer", `إضافة العميل ${f.name}`));
    toast.success(edit ? "تم حفظ التعديلات" : "تمت إضافة العميل");
    onClose();
  };
  return (
    <Modal open={open} onClose={onClose} title={edit ? "تعديل العميل" : "عميل جديد"}>
      <form onSubmit={save} className="space-y-3">
        <L t="الاسم"><input className="field" value={f.name} onChange={set("name")} autoFocus /></L>
        <L t="رقم الجوال" hint="يُستخدم لإرسال تذكير واتساب"><input className="field" inputMode="tel" dir="ltr" value={f.phone} onChange={set("phone")} /></L>
        <L t="العنوان"><input className="field" value={f.address} onChange={set("address")} /></L>
        <L t="ملاحظات"><textarea className="field min-h-20" value={f.notes} onChange={set("notes")} /></L>
        <details className="rounded-xl border border-border p-3" open={!!g.name}>
          <summary className="cursor-pointer text-sm font-semibold">بيانات الضامن (اختياري)</summary>
          <div className="mt-3 space-y-3">
            <L t="اسم الضامن"><input className="field" value={g.name} onChange={setg("name")} /></L>
            <div className="grid grid-cols-2 gap-3">
              <L t="جوال الضامن"><input className="field" inputMode="tel" dir="ltr" value={g.phone} onChange={setg("phone")} /></L>
              <L t="رقم الهوية"><input className="field" dir="ltr" value={g.idNo} onChange={setg("idNo")} /></L>
            </div>
            <L t="عنوان الضامن"><input className="field" value={g.address} onChange={setg("address")} /></L>
          </div>
        </details>
        <button className="btn w-full">حفظ</button>
      </form>
    </Modal>
  );
}

export function PlanDialog({ open, onClose, customerId }: { open: boolean; onClose: () => void; customerId?: string }) {
  const { db, update } = useApp();
  const active = db.customers.filter((c) => !c.archived);
  const [f, setF] = useState({ customerId: customerId ?? active[0]?.id ?? "", item: "", total: "", down: "0", count: "10", everyDays: "30", start: todayISO() });
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });
  const total = toNum(f.total) || 0, down = toNum(f.down) || 0, count = Math.floor(toNum(f.count) || 0);
  const each = count > 0 ? (total - down) / count : 0;
  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!f.customerId) { toast.error("أضف عميلًا أولًا"); return; }
    if (!f.item.trim() || total <= 0 || count <= 0 || count > 600 || down < 0 || down >= total) { toast.error("تأكد من الصنف والمبلغ وعدد الأقساط"); return; }
    const p: Plan = { id: uid(), customerId: f.customerId, item: f.item.trim(), total, down, count, everyDays: Number(f.everyDays), start: f.start, createdAt: new Date().toISOString() };
    const name = db.customers.find((c) => c.id === p.customerId)?.name ?? "";
    update((d) => log({ ...d, plans: [...d.plans, p], installments: [...d.installments, ...buildSchedule(p)] }, "plan", `خطة أقساط "${p.item}" للعميل ${name} بقيمة ${fmt(total)}`));
    toast.success("تم إنشاء خطة الأقساط وجدولها");
    onClose();
  };
  return (
    <Modal open={open} onClose={onClose} title="خطة أقساط جديدة">
      {active.length === 0 ? <p className="text-sm text-muted-foreground">أضف عميلًا أولًا من صفحة العملاء.</p> : (
        <form onSubmit={save} className="space-y-3">
          <L t="العميل">
            <SelectField ariaLabel="العميل" value={f.customerId} onChange={(v) => setF({ ...f, customerId: v })} disabled={!!customerId} options={active.map((c) => ({ value: c.id, label: c.name }))} />
          </L>
          <L t="الصنف / البيان"><input className="field" value={f.item} onChange={set("item")} placeholder="مثال: ثلاجة" /></L>
          <div className="grid grid-cols-2 gap-3">
            <L t="السعر الإجمالي"><input className="field" inputMode="decimal" value={f.total} onChange={set("total")} /></L>
            <L t="المقدم"><input className="field" inputMode="decimal" value={f.down} onChange={set("down")} /></L>
            <L t="عدد الأقساط"><input className="field" inputMode="numeric" value={f.count} onChange={set("count")} /></L>
            <L t="كل">
              <SelectField ariaLabel="كل" value={f.everyDays} onChange={(v) => setF({ ...f, everyDays: v })} options={[{ value: "30", label: "شهر" }, { value: "14", label: "أسبوعين" }, { value: "7", label: "أسبوع" }]} />
            </L>
          </div>
          <L t="تاريخ أول قسط"><DateField ariaLabel="تاريخ أول قسط" value={f.start} onChange={(v) => setF({ ...f, start: v })} /></L>
          <p className="note">قيمة القسط: <b className="text-gold">{fmt(Math.max(0, each))}</b> × {count || 0} قسط</p>
          <button className="btn w-full">إنشاء الخطة</button>
        </form>
      )}
    </Modal>
  );
}

export function PaymentDialog({ open, onClose, plan, suggest }: { open: boolean; onClose: () => void; plan: Plan; suggest?: number }) {
  const { db, update } = useApp();
  const left = planRemaining(db, plan);
  const [amount, setAmount] = useState(String(suggest ?? left));
  const [date, setDate] = useState(todayISO());
  const [note, setNote] = useState("");
  const [method, setMethod] = useState<PayMethod>("cash");
  const [kind, setKind] = useState<PayKind>("installment");
  const [receipt, setReceipt] = useState<ReceiptData | null>(null);
  const save = (e: React.FormEvent) => {
    e.preventDefault();
    const a = toNum(amount);
    if (!(a > 0)) { toast.error("اكتب مبلغًا صحيحًا"); return; }
    const name = db.customers.find((c) => c.id === plan.customerId)?.name ?? "";
    const pid = uid();
    const next = log({ ...db, payments: [...db.payments, { id: pid, planId: plan.id, amount: a, date, note, method, kind }] }, "payment", `دفعة ${fmt(a)} من ${name} — ${plan.item}`);
    update(() => next);
    toast.success(a > left ? "تم التسجيل — الزيادة أصبحت رصيدًا دائنًا للعميل" : "تم تسجيل الدفعة");
    setReceipt(receiptFor(next, plan, a, date, pid));
  };
  return (
    <Modal open={open} onClose={onClose} title={receipt ? "إيصال الاستلام" : `تسجيل دفعة — ${plan.item}`}>
      {receipt ? <><ReceiptActions r={receipt} /><button className="btn-ghost w-full" onClick={onClose}>تم</button></> : <form onSubmit={save} className="space-y-3">
        <p className="text-sm text-muted-foreground">المتبقي على الخطة: <b className="text-warning">{fmt(left)}</b></p>
        <L t="المبلغ"><input className="field" inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} autoFocus /></L>
        <L t="التاريخ"><DateField ariaLabel="التاريخ" value={date} onChange={setDate} /></L>
        <div className="grid grid-cols-2 gap-3">
          <L t="طريقة الدفع"><SelectField ariaLabel="طريقة الدفع" value={method} onChange={(v) => setMethod(v as PayMethod)} options={PAY_METHODS.map(([value, label]) => ({ value, label }))} /></L>
          <L t="نوع الدفعة"><SelectField ariaLabel="نوع الدفعة" value={kind} onChange={(v) => setKind(v as PayKind)} options={[{ value: "installment", label: "سداد القسط" }, { value: "partial", label: "دفعة جزئية" }]} /></L>
        </div>
        <L t="ملاحظة"><input className="field" value={note} onChange={(e) => setNote(e.target.value)} /></L>
        <button className="btn w-full">تسجيل الدفعة</button>
      </form>}
    </Modal>
  );
}

export const PAY_METHODS: [PayMethod, string][] = [["cash", "نقدًا"], ["bank", "تحويل بنكي"], ["wallet", "محفظة إلكترونية"]];
export const EXPENSE_CATS = ["إيجار", "رواتب", "كهرباء وماء", "إنترنت واتصالات", "بضاعة", "مستلزمات", "صيانة", "نقل وشحن", "ضرائب ورسوم", "أخرى"];
export function ExpenseDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { update } = useApp();
  const [f, setF] = useState({ title: "", category: EXPENSE_CATS[0]!, amount: "", date: todayISO() });
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });
  const save = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = toNum(f.amount);
    if (!(amount > 0)) { toast.error("اكتب مبلغًا صحيحًا"); return; }
    const title = f.title.trim() || f.category;
    update((d) => log({ ...d, expenses: [...d.expenses, { id: uid(), title, category: f.category, amount, date: f.date }] }, "expense", `مصروف ${title} بقيمة ${fmt(amount)}`));
    toast.success("تم تسجيل المصروف");
    onClose();
  };
  return (
    <Modal open={open} onClose={onClose} title="مصروف جديد">
      <form onSubmit={save} className="space-y-3">
        <L t="البيان"><input className="field" value={f.title} onChange={set("title")} placeholder="مثال: إيجار شهر نوفمبر" autoFocus /></L>
        <div className="grid grid-cols-2 gap-3">
          <L t="التصنيف"><SelectField ariaLabel="التصنيف" value={f.category} onChange={(v) => setF({ ...f, category: v })} options={EXPENSE_CATS.map((c) => ({ value: c, label: c }))} /></L>
          <L t="المبلغ"><input className="field" inputMode="decimal" value={f.amount} onChange={set("amount")} /></L>
        </div>
        <L t="التاريخ"><DateField ariaLabel="التاريخ" value={f.date} onChange={(v) => setF({ ...f, date: v })} /></L>
        <button className="btn w-full">حفظ المصروف</button>
      </form>
    </Modal>
  );
}
