import type { LucideIcon } from "lucide-react";
import { SelectField } from "./fields";
import type { ReactNode } from "react";
import { cur, fmt } from "@/lib/store";
import { useApp } from "./ctx";

export function Money({ v, className = "" }: { v: number; className?: string }) {
  const { db } = useApp();
  return <span className={className}>{fmt(v)} {cur(db.settings).sym}</span>;
}

export function Stat({ label, value, sub, tone = "text-foreground", icon: Icon, active }: {
  label: string; value: number; sub?: string; tone?: string; icon?: LucideIcon; active?: boolean;
}) {
  return (
    <div className={`stat ${active ? "border-primary/40 bg-accent/60" : ""}`}>
      <div className="flex items-start justify-between gap-2">
        <span className="text-sm text-muted-foreground">{label}</span>
        {Icon && <Icon className="size-4 text-muted-foreground" />}
      </div>
      <Money v={value} className={`mt-1 block text-xl font-bold ${tone}`} />
      {sub && <span className="text-xs text-muted-foreground">{sub}</span>}
    </div>
  );
}

export function Empty({ icon: Icon, title, sub }: { icon: LucideIcon; title: string; sub: string }) {
  return (
    <div className="flex flex-col items-center px-4 py-12 text-center">
      <div className="icon-tile mb-4"><Icon className="size-5" /></div>
      <p className="font-semibold">{title}</p>
      <p className="mt-1 text-sm text-muted-foreground">{sub}</p>
    </div>
  );
}

export function Section({ title, icon: Icon, count, action, children }: {
  title: string; icon?: LucideIcon; count?: number; action?: ReactNode; children: ReactNode;
}) {
  return (
    <div className="overflow-hidden rounded-2xl border border-border bg-card/70">
      <div className="flex items-center justify-between gap-2 border-b border-border px-4 py-3">
        <div className="flex items-center gap-2 font-bold">
          {Icon && <Icon className="size-4 text-primary" />}{title}
          {count !== undefined && <span className="rounded-full bg-muted px-2 text-xs font-normal text-muted-foreground">{count}</span>}
        </div>
        {action}
      </div>
      {children}
    </div>
  );
}

export function L({ t, hint, children }: { t: string; hint?: string; children: ReactNode }) {
  return (
    <label className="block space-y-1.5">
      <span className="text-sm font-medium">{t}</span>
      {children}
      {hint && <span className="block text-xs text-muted-foreground">{hint}</span>}
    </label>
  );
}

export function Chips<T extends string>({ value, onChange, items }: {
  value: T; onChange: (v: T) => void; items: { v: T; label: string; icon?: LucideIcon }[];
}) {
  return (
    <div className="flex flex-wrap gap-2">
      {items.map(({ v, label, icon: Icon }) => (
        <button key={v} type="button" onClick={() => onChange(v)} className={`chip ${value === v ? "chip-on" : ""}`}>
          {Icon && <Icon className="size-4" />}{label}
        </button>
      ))}
    </div>
  );
}

export type Period = "all" | "month" | "last" | "year";
export const PERIODS: { v: Period; label: string }[] = [
  { v: "all", label: "كل الفترات" }, { v: "month", label: "هذا الشهر" }, { v: "last", label: "الشهر الماضي" }, { v: "year", label: "هذه السنة" },
];
export function inPeriod(date: string, p: Period, now = new Date()) {
  if (p === "all") return true;
  const d = new Date(date.slice(0, 10) + "T00:00:00");
  if (p === "year") return d.getFullYear() === now.getFullYear();
  const ref = p === "month" ? now : new Date(now.getFullYear(), now.getMonth() - 1, 1);
  return d.getFullYear() === ref.getFullYear() && d.getMonth() === ref.getMonth();
}
export function PeriodSelect({ value, onChange }: { value: Period; onChange: (p: Period) => void }) {
  return (
    <SelectField ariaLabel="الفترة" className="w-auto min-w-40" value={value} onChange={(v) => onChange(v as Period)} options={PERIODS.map((p) => ({ value: p.v, label: p.label }))} />
  );
}
