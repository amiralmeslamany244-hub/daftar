import { useMemo, useRef, useState } from "react";
import { SelectField } from "./fields";
import { toast } from "sonner";
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import {
  AlertTriangle, BarChart3, CloudDownload, Database, DatabaseBackup, Eye, EyeOff, FileDown, FileJson, Filter, Gem, HardDrive,
  History, Lock, Share2, LockOpen, Receipt, Save, ShieldCheck, Trash2, TrendingUp, Upload, Users, Wallet, Clock,
} from "lucide-react";
import {
  CURRENCIES, toNum, allRows, customerRemaining, dateAr, fmt, hash, importOld, log, mergeBackup, trashExpense, backupFile, recordBackup, saveAuth, todayISO, totals, uid,
  type DB, type LogKind,
} from "@/lib/store";
import { useApp } from "./ctx";
import { ExpenseDialog } from "./dialogs";
import { QuickUnlockPanel, StaffPanel } from "./security";
import { FinancialReport, LogoPanel } from "./features";
import { DisplayPanel } from "./display-panel";
import { Chips, Empty, L, Money, PeriodSelect, Section, Stat, inPeriod, type Period } from "./ui";

type Move = { id: string; date: string; text: string; amount: number; kind: "in" | "out" };
function moves(d: DB): Move[] {
  const name = (pid: string) => { const p = d.plans.find((x) => x.id === pid); return `${d.customers.find((c) => c.id === p?.customerId)?.name ?? ""} — ${p?.item ?? ""}`; };
  return [
    ...d.plans.filter((p) => p.down > 0).map((p) => ({ id: "d" + p.id, date: p.createdAt.slice(0, 10), text: `مقدم: ${name(p.id)}`, amount: p.down, kind: "in" as const })),
    ...d.payments.map((p) => ({ id: p.id, date: p.date, text: `دفعة: ${name(p.planId)}`, amount: p.amount, kind: "in" as const })),
    ...d.expenses.map((e) => ({ id: e.id, date: e.date, text: `مصروف: ${e.title}`, amount: e.amount, kind: "out" as const })),
  ].sort((a, b) => b.date.localeCompare(a.date));
}

export function Treasury() {
  const { db } = useApp();
  const t = totals(db);
  const [k, setK] = useState<"all" | "in" | "out">("all");
  const [p, setP] = useState<Period>("all");
  const list = moves(db).filter((m) => (k === "all" || m.kind === k) && inPeriod(m.date, p));
  const ins = list.filter((m) => m.kind === "in").reduce((s, m) => s + m.amount, 0);
  const outs = list.filter((m) => m.kind === "out").reduce((s, m) => s + m.amount, 0);
  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-primary/30 bg-hero p-5">
        <p className="flex items-center gap-1.5 text-sm text-muted-foreground"><Wallet className="size-4" />الرصيد النقدي الحالي</p>
        <Money v={t.cash} className="mt-1 block text-4xl font-bold" />
        <p className="text-xs text-muted-foreground">الرصيد الافتتاحي + المقبوضات الفعلية − المصروفات</p>
        <div className="mt-4 grid grid-cols-2 gap-2 text-xs sm:grid-cols-4">
          {[["رصيد افتتاحي", db.settings.opening, ""], ["إجمالي المحصّل", t.collected, "text-success"], ["إجمالي المصروفات", t.expenses, "text-destructive"], ["رصيد دائن للعملاء", t.credit, "text-info"]].map(([l, v, c]) => (
            <div key={l as string} className="rounded-xl border border-border bg-background/30 p-2"><p className="text-muted-foreground">{l}</p><Money v={v as number} className={`font-semibold ${c}`} /></div>
          ))}
        </div>
      </div>
      <div className="grid gap-3 sm:grid-cols-3">
        <Stat label="المبالغ المتوقع تحصيلها" value={t.remaining} sub="أقساط لم تُسدّد بعد" tone="text-warning" icon={TrendingUp} />
        <Stat label="المبالغ المتأخرة" value={t.overdue} sub="تجاوزت تاريخ الاستحقاق" tone="text-destructive" icon={AlertTriangle} />
        <Stat label="غير المستحق بعد" value={t.upcoming} sub="أقساط مستقبلية" tone="text-info" icon={Clock} />
      </div>
      <div className="panel space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-sm text-muted-foreground"><Filter className="size-4" />تصفية
            <Chips value={k} onChange={setK} items={[{ v: "all", label: "كل الحركات" }, { v: "in", label: "مقبوضات" }, { v: "out", label: "مصروفات" }]} /></div>
          <PeriodSelect value={p} onChange={setP} />
        </div>
        <div className="flex flex-wrap gap-4 border-t border-border pt-3 text-sm text-muted-foreground">
          <span>مقبوضات معروضة: <Money v={ins} className="text-success" /></span>
          <span>مصروفات معروضة: <Money v={outs} className="text-destructive" /></span>
          <span>الصافي: <Money v={ins - outs} className="text-gold" /></span>
        </div>
      </div>
      <Section title="سجل حركة الخزينة">
        {list.length === 0 ? <Empty icon={Receipt} title="لا حركات في هذه الفترة" sub="كل دفعة تُسجَّل يُظهرها السجل هنا، وكذلك المصروفات." /> : (
          <div className="divide-y divide-border">{list.map((m) => (
            <div key={m.id} className="flex items-center gap-3 px-4 py-3 text-sm">
              <div className="min-w-0 flex-1"><p className="truncate">{m.text}</p><p className="text-xs text-muted-foreground">{dateAr(m.date)}</p></div>
              <span className={`font-bold ${m.kind === "in" ? "text-success" : "text-destructive"}`}>{m.kind === "in" ? "+" : "−"}<Money v={m.amount} /></span>
            </div>
          ))}</div>
        )}
      </Section>
      <p className="text-xs text-muted-foreground">ملاحظة محاسبية: الأقساط المستقبلية والمتأخرات لا تُعدّ نقدًا في الخزينة، وتظهر أعلاه كـ«مبالغ متوقع تحصيلها» فقط. (تاريخ اليوم {dateAr(todayISO())})</p>
    </div>
  );
}

export function Expenses() {
  const { db, update, can } = useApp();
  const [p, setP] = useState<Period>("all");
  const [add, setAdd] = useState(false);
  const list = db.expenses.filter((e) => inPeriod(e.date, p)).sort((a, b) => b.date.localeCompare(a.date));
  const del = (id: string) => {
    const e = db.expenses.find((x) => x.id === id)!;
    if (!confirm(`حذف المصروف "${e.title}"؟ ينتقل المصروف إلى سلة المحذوفات ويمكن استعادته من هناك.`)) return;
    update((d) => trashExpense(d, id)); void fmt;
    toast.success("نُقل المصروف إلى سلة المحذوفات");
  };
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <PeriodSelect value={p} onChange={setP} />
        <div className="flex items-center gap-3">
          <span className="text-sm text-muted-foreground">إجمالي المصروفات: <Money v={list.reduce((s, e) => s + e.amount, 0)} className="text-destructive" /></span>
          <button className="btn" onClick={() => setAdd(true)}>+ مصروف</button>
        </div>
      </div>
      <Section title="المصروفات" icon={Receipt} count={list.length}>
        {list.length === 0 ? <Empty icon={Receipt} title="لا مصروفات مسجّلة" sub="سجّل إيجار المحل والرواتب وأي مصروف آخر ليُخصم من الخزينة." /> : (
          <div className="divide-y divide-border">{list.map((e) => (
            <div key={e.id} className="flex items-center gap-3 px-4 py-3 text-sm">
              <div className="min-w-0 flex-1"><p className="truncate font-semibold">{e.title}</p><p className="text-xs text-muted-foreground">{e.category} · {dateAr(e.date)}</p></div>
              <Money v={e.amount} className="font-bold text-destructive" />
              {can("delete") && <button className="chip" aria-label="حذف" onClick={() => del(e.id)}><Trash2 className="size-4" /></button>}
            </div>
          ))}</div>
        )}
      </Section>
      {add && <ExpenseDialog open onClose={() => setAdd(false)} />}
    </div>
  );
}

export function Reports() {
  const { db } = useApp();
  const t = totals(db);
  const [tab, setTab] = useState<"sum" | "fin" | "col" | "debt" | "cust" | "exp">("sum");
  const months = useMemo(() => {
    const now = new Date();
    return Array.from({ length: 12 }, (_, i) => {
      const d = new Date(now.getFullYear(), now.getMonth() - 11 + i, 1);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      const ms = moves(db).filter((m) => m.date.startsWith(key));
      return { name: d.toLocaleDateString("ar-EG-u-nu-latn", { month: "short", year: "2-digit" }),
        تحصيل: ms.filter((m) => m.kind === "in").reduce((s, m) => s + m.amount, 0),
        مصروفات: ms.filter((m) => m.kind === "out").reduce((s, m) => s + m.amount, 0) };
    });
  }, [db]);
  const late = allRows(db).filter((r) => r.status === "overdue");
  return (
    <div className="space-y-4">
      <div className="no-print flex flex-wrap items-center justify-between gap-2">
        <Chips value={tab} onChange={setTab} items={[
          { v: "sum", label: "ملخص عام", icon: BarChart3 }, { v: "fin", label: "التقرير المالي", icon: Wallet }, { v: "col", label: "التحصيل", icon: TrendingUp },
          { v: "debt", label: "المديونيات والمتأخرات", icon: AlertTriangle }, { v: "cust", label: "حساب العملاء", icon: Users },
          { v: "exp", label: "المصروفات والتدفق", icon: Receipt },
        ]} />
        <button className="btn-ghost" onClick={() => window.print()}><FileDown className="size-4" />تصدير PDF</button>
      </div>
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="الرصيد النقدي" value={t.cash} />
        <Stat label="إجمالي التحصيل" value={t.collected} tone="text-success" />
        <Stat label="المديونيات المتبقية" value={t.remaining} tone="text-warning" />
        <Stat label="المتأخرات" value={t.overdue} tone="text-destructive" />
      </div>
      {(tab === "sum" || tab === "col" || tab === "exp") && (
        <div className="panel">
          <p className="mb-3 font-bold">التحصيل مقابل المصروفات — آخر 12 شهرًا</p>
          <div className="h-72" dir="ltr">
            <ResponsiveContainer>
              <BarChart data={months}>
                <CartesianGrid stroke="var(--border)" vertical={false} />
                <XAxis dataKey="name" stroke="var(--muted-foreground)" fontSize={11} reversed />
                <YAxis stroke="var(--muted-foreground)" fontSize={11} orientation="right" />
                <Tooltip cursor={{ fill: "var(--muted)", opacity: 0.4 }} contentStyle={{ background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 12 }} formatter={(v: number) => fmt(v)} />
                <Legend />
                <Bar dataKey="تحصيل" fill="var(--chart-1)" radius={[6, 6, 0, 0]} />
                <Bar dataKey="مصروفات" fill="var(--chart-2)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
      {tab === "fin" && <FinancialReport />}
      {tab === "sum" && (
        <div className="grid gap-3 sm:grid-cols-3">
          <Stat label="صافي التدفق النقدي" value={t.collected - t.expenses} sub="المحصّل − المصروفات" tone="text-success" />
          <Stat label="الأقساط غير المستحقة بعد" value={t.upcoming} sub="مبالغ مستقبلية" tone="text-info" />
          <Stat label="أرصدة دائنة للعملاء" value={t.credit} sub="دفعات مقدمة لم تُسوَّ بعد" tone="text-warning" />
        </div>
      )}
      {tab === "debt" && (
        <Section title="الأقساط المتأخرة" icon={AlertTriangle} count={late.length}>
          {late.length === 0 ? <Empty icon={AlertTriangle} title="لا متأخرات" sub="كل العملاء ملتزمون بمواعيدهم." /> : (
            <div className="divide-y divide-border">{late.map((r) => {
              const p = db.plans.find((x) => x.id === r.planId)!; const c = db.customers.find((x) => x.id === p.customerId);
              return <div key={r.id} className="flex gap-3 px-4 py-2 text-sm"><span className="flex-1">{c?.name} — {p.item} · قسط {r.n}</span><span className="text-muted-foreground">{dateAr(r.due)}</span><Money v={r.left} className="font-bold text-destructive" /></div>;
            })}</div>
          )}
        </Section>
      )}
      {tab === "cust" && (
        <Section title="حساب العملاء" icon={Users} count={db.customers.length}>
          <div className="divide-y divide-border">{db.customers.map((c) => {
            const ps = db.plans.filter((p) => p.customerId === c.id);
            const total = ps.reduce((s, p) => s + p.total, 0);
            return <div key={c.id} className="grid grid-cols-3 gap-3 px-4 py-2 text-sm"><span className="font-semibold">{c.name}</span><span>الإجمالي <Money v={total} /></span><span>المتبقي <Money v={customerRemaining(db, c.id)} className="text-warning" /></span></div>;
          })}</div>
          {db.customers.length === 0 && <Empty icon={Users} title="لا يوجد عملاء" sub="أضف عملاء لتظهر حساباتهم هنا." />}
        </Section>
      )}
      {tab === "exp" && (
        <Section title="المصروفات حسب التصنيف" icon={Receipt}>
          <div className="divide-y divide-border">{Object.entries(db.expenses.reduce<Record<string, number>>((m, e) => ({ ...m, [e.category]: (m[e.category] ?? 0) + e.amount }), {})).map(([k, v]) => (
            <div key={k} className="flex justify-between px-4 py-2 text-sm"><span>{k}</span><Money v={v} className="font-bold text-destructive" /></div>
          ))}</div>
          {db.expenses.length === 0 && <Empty icon={Receipt} title="لا مصروفات" sub="سجّل المصروفات لتظهر هنا." />}
        </Section>
      )}
    </div>
  );
}

const KINDS: { v: LogKind | "all"; label: string }[] = [
  { v: "all", label: "الكل" }, { v: "payment", label: "المدفوعات" }, { v: "expense", label: "المصروفات" },
  { v: "customer", label: "العملاء" }, { v: "plan", label: "الخطط" }, { v: "security", label: "الأمان" },
];
export function LogPage() {
  const { db } = useApp();
  const [k, setK] = useState<LogKind | "all">("all");
  const list = db.log.filter((l) => k === "all" || l.kind === k);
  return (
    <div className="space-y-3">
      <Chips value={k} onChange={setK} items={KINDS} />
      <Section title="سجل العمليات" icon={History} count={list.length}>
        {list.length === 0 ? <Empty icon={History} title="لا عمليات" sub="كل إضافة أو دفعة أو تعديل يُسجَّل هنا." /> : (
          <div className="divide-y divide-border">{list.map((l) => (
            <div key={l.id} className="flex items-start gap-3 px-4 py-3">
              <div className="grid size-9 shrink-0 place-items-center rounded-lg border border-border bg-muted/50 text-muted-foreground"><ShieldCheck className="size-4" /></div>
              <div className="min-w-0 flex-1">
                <p className="text-sm">{l.text}</p>
                <p className="mt-1 flex items-center gap-2 text-xs text-muted-foreground">
                  {new Date(l.at).toLocaleString("ar-EG-u-nu-latn", { dateStyle: "long", timeStyle: "short" })}
                  <span className="rounded-md bg-muted px-2 py-0.5 text-foreground">{KINDS.find((x) => x.v === l.kind)?.label}</span>
                </p>
              </div>
            </div>
          ))}</div>
        )}
      </Section>
    </div>
  );
}

export function Backups() {
  const { db, update } = useApp();
  const file = useRef<HTMLInputElement>(null);
  const download = () => {
    const f = backupFile(db);
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([f.body], { type: "application/json" }));
    a.download = f.name; a.click();
    update((d) => recordBackup(d, f.at, f.body.length, "حفظ على الجهاز"));
    toast.success("تم حفظ ملف النسخة الاحتياطية على الجهاز");
  };
  const share = async () => {
    const f = backupFile(db);
    const file = new File([f.body], f.name, { type: "application/json" });
    if (navigator.canShare?.({ files: [file] })) {
      try {
        await navigator.share({ files: [file], title: "نسخة دفتر زمرد", text: `نسخة احتياطية — ${db.settings.shop}` });
        update((d) => recordBackup(d, f.at, f.body.length, "مشاركة"));
        toast.success("تمت مشاركة النسخة — احتفظ بالرسالة");
      } catch (e) { if ((e as Error).name !== "AbortError") toast.error("تعذّرت المشاركة — جرّب الحفظ على الجهاز"); }
      return;
    }
    // Desktop browsers usually can't share files: save it, then open the mail app so the user attaches it.
    download();
    toast.info("أرفق الملف الذي تم حفظه في رسالة البريد أو الواتساب");
    window.location.href = `mailto:?subject=${encodeURIComponent(`نسخة احتياطية — ${db.settings.shop}`)}&body=${encodeURIComponent(`أرفق ملف ${f.name} من مجلد التنزيلات.`)}`;
  };
  const restore = async (f: File) => {
    try {
      const j = JSON.parse(await f.text());
      const b: DB = j.db ?? j;
      if (!Array.isArray(b.customers)) throw new Error();
      update((d) => log(mergeBackup(d, b), "security", `استعادة نسخة احتياطية (${f.name})`));
      toast.success("تمت الاستعادة ودمج البيانات");
    } catch { toast.error("الملف غير صالح"); }
  };
  const migrate = () => {
    const r = importOld(db);
    if (!r) { toast.info("لا توجد بيانات قديمة على هذا الجهاز"); return; }
    update(() => r.db); toast.success(`تم نسخ ${r.added} سجل من النسخة السابقة`);
  };
  return (
    <div className="space-y-4">
      <div className="panel space-y-3">
        <div className="flex gap-3">
          <div className="grid size-11 shrink-0 place-items-center rounded-xl border border-gold/30 bg-hero text-gold"><DatabaseBackup className="size-5" /></div>
          <div><p className="font-bold">النسخ الاحتياطي والاستعادة</p>
            <p className="text-sm leading-6 text-muted-foreground">كل شيء في هذا الدفتر محفوظ على هذا الجهاز فقط. الملف يجمع العملاء والخطط والأقساط والمدفوعات والمصروفات والإعدادات، ويُنشأ على جهازك دون إنترنت، فتحتفظ بنسخة تستعيد بها الدفتر على أي هاتف.</p></div>
        </div>
        <div className="flex flex-wrap gap-2">
          <button className="btn flex-1" onClick={share}><Share2 className="size-4" />مشاركة النسخة (واتساب / بريد)</button>
          <button className="btn-ghost" onClick={download}><HardDrive className="size-4" />حفظ على الجهاز</button>
          <button className="btn-ghost" onClick={() => file.current?.click()}><Upload className="size-4" />استعادة من ملف</button>
          <input ref={file} type="file" accept="application/json,.json" hidden onChange={(e) => { const f = e.target.files?.[0]; if (f) restore(f); e.target.value = ""; }} />
        </div>
        <p className="warn flex gap-2"><AlertTriangle className="mt-0.5 size-4 shrink-0 text-warning" />البيانات على هذا الجهاز وحده: إن حذفت بيانات المتصفح أو غيّرت الهاتف دون نسخة احتياطية فلا سبيل لاستعادتها. الاستعادة لا تحذف شيئًا — تُضيف السجلات وتحدّث الموجود بنفس المعرّف.</p>
      </div>
      <Section title="النسخ المحفوظة" icon={FileJson} count={db.backups.length}>
        {db.backups.length === 0 ? <Empty icon={DatabaseBackup} title="لا نسخ محفوظة بعد" sub="أنشئ نسخة احتياطية يدويًا في أي وقت — يُستحسن أسبوعيًا." /> : (
          <div className="divide-y divide-border">{db.backups.map((b) => (
            <div key={b.id} className="flex justify-between px-4 py-3 text-sm"><span>{new Date(b.at).toLocaleString("ar-EG-u-nu-latn", { dateStyle: "long", timeStyle: "short" })}</span><span className="text-muted-foreground">{b.counts} · {(b.size / 1024).toFixed(1)} ك.ب</span></div>
          ))}</div>
        )}
      </Section>
      <div className="panel flex gap-3">
        <div className="icon-tile shrink-0"><CloudDownload className="size-5" /></div>
        <div className="space-y-3">
          <p className="font-bold">نسخ بياناتك القديمة مرة واحدة</p>
          <p className="text-sm text-muted-foreground">إن كنت أدخلت عملاء أو أقساطًا في نسخة سابقة من التطبيق، اضغط هنا مرة واحدة لنقلها إلى هذا الجهاز. هذه عملية نسخ يدوية تُنفَّذ مرة واحدة — التطبيق لا يتزامن مع أي خادم بعدها.</p>
          <button className="btn-ghost" onClick={migrate}>نسخ البيانات القديمة الآن</button>
        </div>
      </div>
      <p className="note">نصيحة: صدّر نسخة احتياطية بانتظام، واحفظها خارج الهاتف (بريد إلكتروني أو ذاكرة خارجية) — هي وحدها طريقك لنقل الدفتر إلى جهاز آخر أو استعادته بعد حذف بيانات المتصفح.</p>
    </div>
  );
}

export function Settings() {
  const { db, update, auth, setAuth } = useApp();
  const [s, setS] = useState({ ...db.settings, opening: String(db.settings.opening) });
  const [a, setA] = useState({ user: auth.user, cur: "", np: "", np2: "", rec: "" });
  const [show, setShow] = useState(false);
  const t = show ? "text" : "password";
  const saveSettings = () => {
    update((d) => log({ ...d, settings: { ...d.settings, shop: s.shop.trim() || "دفتر زمرد", currency: s.currency, opening: toNum(s.opening) || 0, backupEveryDays: Number(s.backupEveryDays), autoLockMin: Number(s.autoLockMin) } }, "security", "تحديث إعدادات المحل"));
    toast.success("تم حفظ الإعدادات");
  };
  const saveAuthForm = async () => {
    if ((await hash(a.cur)) !== auth.pass) { toast.error("كلمة المرور الحالية غير صحيحة"); return; }
    if ((auth.staff ?? []).some((x) => x.user === a.user.trim())) { toast.error("اسم المستخدم مستخدم لموظف"); return; }
    if (a.np && (a.np.length < 4 || a.np !== a.np2)) { toast.error("كلمة المرور الجديدة قصيرة أو غير متطابقة"); return; }
    if (a.rec && a.rec.trim().length < 4) { toast.error("كلمة الاسترداد 4 أحرف على الأقل"); return; }
    const next = { ...auth, user: a.user.trim() || auth.user, enabled: true, pass: a.np ? await hash(a.np) : auth.pass, recovery: a.rec ? await hash(a.rec) : auth.recovery };
    saveAuth(next); setAuth(next); update((d) => log(d, "security", "تغيير بيانات الدخول المحلي"));
    setA({ ...a, cur: "", np: "", np2: "", rec: "" }); toast.success("تم حفظ بيانات الدخول");
  };
  const toggleLock = async () => {
    if ((await hash(a.cur)) !== auth.pass) { toast.error("اكتب كلمة المرور الحالية أولًا"); return; }
    const next = { ...auth, enabled: !auth.enabled }; saveAuth(next); setAuth(next);
    update((d) => log(d, "security", next.enabled ? "تفعيل قفل التطبيق" : "إلغاء قفل التطبيق"));
    setA({ ...a, cur: "" }); toast.success(next.enabled ? "تم تفعيل القفل" : "تم إلغاء القفل");
  };
  return (
    <div className="space-y-4">
      <div className="panel space-y-4">
        <p className="flex items-center gap-2 font-bold"><Gem className="size-4 text-gold" />بيانات المحل</p>
        <div className="grid gap-4 sm:grid-cols-2">
          <L t="اسم المحل / الدفتر"><input className="field" value={s.shop} onChange={(e) => setS({ ...s, shop: e.target.value })} /></L>
          <L t="عملة الدفتر" hint="تُستخدم في كل الشاشات والتقارير">
            <SelectField ariaLabel="عملة الدفتر" value={s.currency} onChange={(v) => setS({ ...s, currency: v })} options={CURRENCIES.map((c) => ({ value: c.code, label: c.label }))} />
          </L>
          <L t="الرصيد الافتتاحي للخزينة" hint="النقد الموجود في المحل عند بدء استخدام التطبيق"><input className="field" inputMode="decimal" value={s.opening} onChange={(e) => setS({ ...s, opening: e.target.value })} /></L>
          <L t="تذكير النسخ الاحتياطي كل" hint="بالأيام — يظهر تنبيه في الرئيسية">
            <SelectField ariaLabel="تذكير النسخ الاحتياطي" value={String(s.backupEveryDays)} onChange={(v) => setS({ ...s, backupEveryDays: Number(v) })} options={[0, 3, 7, 14, 30].map((n) => ({ value: String(n), label: n === 0 ? "بدون تذكير" : `${n} يوم` }))} />
          </L>
        </div>
        <L t="قفل تلقائي بعد فترة خمول" hint="يعمل عندما يكون القفل مفعّلًا">
          <SelectField ariaLabel="قفل تلقائي" value={String(s.autoLockMin)} onChange={(v) => setS({ ...s, autoLockMin: Number(v) })} options={[0, 1, 5, 15, 30].map((n) => ({ value: String(n), label: n === 0 ? "معطّل" : `${n} دقيقة` }))} />
        </L>
        <button className="btn" onClick={saveSettings}><Save className="size-4" />حفظ الإعدادات</button>
      </div>
      <LogoPanel />
      <DisplayPanel />
      <DailyReminderPanel />
      <div className="panel space-y-4">
        <div className="flex items-center justify-between">
          <p className="flex items-center gap-2 font-bold"><Lock className="size-4 text-primary" />الدخول المحلي وقفل التطبيق</p>
          <span className={`rounded-lg px-2 py-0.5 text-xs ${auth.enabled ? "bg-success/15 text-success" : "bg-muted text-muted-foreground"}`}>{auth.enabled ? "مفعّل" : "معطّل"}</span>
        </div>
        <p className="text-sm text-muted-foreground">يفتح التطبيق على شاشة دخول باسم المستخدم وكلمة المرور قبل إظهار أي بيانات للعملاء.</p>
        <L t="اسم المستخدم"><input className="field" value={a.user} onChange={(e) => setA({ ...a, user: e.target.value })} /></L>
        <L t="كلمة المرور الحالية"><input type={t} className="field" placeholder="••••••" value={a.cur} onChange={(e) => setA({ ...a, cur: e.target.value })} /></L>
        <div className="grid gap-4 sm:grid-cols-2">
          <L t="كلمة مرور جديدة (اختياري)"><input type={t} className="field" placeholder="4 أحرف على الأقل" value={a.np} onChange={(e) => setA({ ...a, np: e.target.value })} /></L>
          <L t="تأكيد كلمة المرور"><input type={t} className="field" placeholder="••••••" value={a.np2} onChange={(e) => setA({ ...a, np2: e.target.value })} /></L>
        </div>
        <L t="كلمة استرداد جديدة (اختياري)" hint="بها وحدها يمكن فتح الدفتر إذا نسيت كلمة المرور — 4 أحرف على الأقل"><input type={t} className="field" placeholder="مثال: اسم المدينة" value={a.rec} onChange={(e) => setA({ ...a, rec: e.target.value })} /></L>
        <button type="button" onClick={() => setShow(!show)} className="flex items-center gap-1.5 text-sm text-muted-foreground">{show ? <EyeOff className="size-4" /> : <Eye className="size-4" />}إظهار كلمات المرور</button>
        <div className="flex flex-wrap gap-2">
          <button className="btn" disabled={!a.cur} onClick={saveAuthForm}><Save className="size-4" />حفظ التغييرات</button>
          <button className="btn-ghost" disabled={!a.cur} onClick={toggleLock}>{auth.enabled ? <LockOpen className="size-4" /> : <Lock className="size-4" />}{auth.enabled ? "إلغاء القفل" : "تفعيل القفل"}</button>
        </div>
        <p className="text-xs leading-6 text-muted-foreground">الدخول محلي فقط: لا يوجد تسجيل دخول بجوجل ولا بأي حساب خارجي، ولا يخرج اسم المستخدم ولا كلمة المرور من هذا الجهاز. تُحفظ كلمة المرور كبصمة مشفّرة ولا يمكن قراءتها، ودخول خطأ متكرر يوقف المحاولات دقيقة. إذا نسيت كلمة المرور فكلمة الاسترداد هي الطريق الوحيد لفتح الدفتر من شاشة القفل.</p>
      </div>
      <QuickUnlockPanel />
      <StaffPanel />
      <div className="panel space-y-2 text-sm">
        <p className="flex items-center gap-2 font-bold"><Database className="size-4 text-primary" />البيانات والنسخ الاحتياطي</p>
        <p className="text-muted-foreground">عدد العملاء: {db.customers.length}</p>
        <p>البيانات محفوظة على هذا الجهاز فقط — لا تُرسل إلى أي خادم ولا تُزامن مع أي حساب، والعملاء والأقساط والمدفوعات والمصروفات لا تظهر إلا بعد إدخال اسم المستخدم وكلمة المرور المحليين.</p>
        <p className="text-gold">النسخة الاحتياطية هي طريقك لنقل الدفتر إلى هاتف آخر أو استعادته بعد أي طارئ — صدّرها من صفحة النسخ الاحتياطي واحفظ الملف في مكان آمن.</p>
      </div>
      <p className="text-center text-xs text-muted-foreground">دفتر زمرد — إدارة أقساط العملاء والحسابات</p>
    </div>
  );
}

function DailyReminderPanel() {
  const { db, update } = useApp();
  const on = !!db.settings.dailyReminder;
  const supported = typeof window !== "undefined" && "Notification" in window;
  const toggle = async () => {
    if (!on) {
      if (!supported) { toast.error("هذا المتصفح لا يدعم التنبيهات"); return; }
      const p = await Notification.requestPermission();
      if (p !== "granted") { toast.error("اسمح بالتنبيهات من إعدادات المتصفح أولًا"); return; }
    }
    update((d) => ({ ...d, settings: { ...d.settings, dailyReminder: !on, lastReminder: undefined } }));
    toast.success(on ? "تم إيقاف التذكير اليومي" : "تم تفعيل التذكير اليومي");
  };
  return (
    <div className="panel flex flex-wrap items-center justify-between gap-3">
      <div className="min-w-0">
        <p className="font-bold">تذكير يومي بالأقساط</p>
        <p className="text-xs text-muted-foreground">تنبيه على الجهاز مرة كل يوم عند أول فتح للتطبيق بعدد أقساط اليوم والمتأخرة وإجماليها.</p>
      </div>
      <button className={on ? "btn" : "btn-ghost"} onClick={toggle}>{on ? "مفعّل — إيقاف" : "تفعيل التذكير"}</button>
    </div>
  );
}
