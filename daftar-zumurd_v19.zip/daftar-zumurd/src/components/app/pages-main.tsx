import { openExternal } from "@/lib/utils";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import {
  AlertTriangle, Archive, ArchiveRestore, ArrowLeft, CalendarDays, CheckCircle2, Clock, DatabaseBackup, Filter,
  Gauge, MessageCircle, Pencil, Plus, Receipt, Search, Sparkles, Trash2, TrendingUp, UserPlus, Users, Wallet,
} from "lucide-react";
import {
  allRows, cur, customerRemaining, dateAr, fmt, log, planCredit, planRemaining, planRows, todayISO, totals, whatsappLink,
  type InstRow, type InstStatus, type Plan,
} from "@/lib/store";
import { useApp } from "./ctx";
import { CustomerDetail } from "./customer-detail";
import { CustomerDialog, ExpenseDialog, PaymentDialog, PlanDialog } from "./dialogs";
import { Chips, Empty, Money, Section, Stat } from "./ui";
import { BulkRemindDialog, DocsPanel, RatingBadge } from "./extras";

export function Home() {
  const { db, go, can } = useApp();
  const t = totals(db);
  const [dlg, setDlg] = useState<"" | "cust" | "plan" | "exp">("");
  const today = allRows(db).filter((r) => r.status === "today" || r.status === "overdue").slice(0, 8);
  const every = db.settings.backupEveryDays;
  const last = db.settings.lastBackup;
  const backupDue = can("backups") && every > 0 && (!last || (Date.now() - new Date(last).getTime()) / 864e5 >= every);
  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-primary/30 bg-hero p-5">
        <div className="flex items-start justify-between">
          <div>
            <p className="flex items-center gap-1.5 text-sm text-muted-foreground"><Wallet className="size-4" />الرصيد النقدي في الخزينة</p>
            <Money v={t.cash} className="mt-1 block text-4xl font-bold" />
          </div>
          <div className="grid size-11 place-items-center rounded-xl border border-border bg-muted/50 text-gold"><Gauge className="size-5" /></div>
        </div>
        <div className="mt-4 grid grid-cols-3 gap-2 text-center text-xs">
          <div className="rounded-xl border border-border bg-background/30 p-2"><p className="text-muted-foreground">رصيد افتتاحي</p><Money v={db.settings.opening} className="font-semibold" /></div>
          <div className="rounded-xl border border-border bg-background/30 p-2"><p className="text-muted-foreground">مقبوضات</p><Money v={t.collected} className="font-semibold text-success" /></div>
          <div className="rounded-xl border border-border bg-background/30 p-2"><p className="text-muted-foreground">مصروفات</p><Money v={t.expenses} className="font-semibold text-destructive" /></div>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="إجمالي التحصيل" value={t.collected} sub="المبالغ المقبوضة فعليًا" tone="text-success" icon={TrendingUp} />
        <Stat label="إجمالي المتبقي" value={t.remaining} sub="مستحق لم يُحصّل بعد" tone="text-warning" icon={Clock} />
        <Stat label="المتأخرات" value={t.overdue} sub={`${t.overdueCount} قسط متأخر`} tone="text-destructive" icon={AlertTriangle} />
        <Stat label="المصروفات" value={t.expenses} sub={`${t.activeCustomers} عميل نشط`} icon={Receipt} />
      </div>
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <button className="btn-ghost" onClick={() => setDlg("cust")}><UserPlus className="size-4" />عميل جديد</button>
        <button className="btn-ghost" onClick={() => setDlg("plan")}><CalendarDays className="size-4" />خطة أقساط</button>
        <button className="btn-ghost" onClick={() => setDlg("exp")}><Receipt className="size-4" />مصروف</button>
        <button className="btn-ghost" onClick={() => go("customers")}><Plus className="size-4" />العملاء</button>
      </div>
      {backupDue && (
        <button onClick={() => go("backups")} className="flex w-full items-center justify-between rounded-2xl border border-border bg-card/70 p-4 text-right">
          <div className="flex items-center gap-3">
            <DatabaseBackup className="size-5 text-gold" />
            <div><p className="font-semibold text-gold">لم تأخذ نسخة احتياطية حديثًا</p>
              <p className="text-xs text-muted-foreground">{last ? `آخر نسخة ${dateAr(last)}` : "لم تُنشئ أي نسخة بعد"} — اضغط للتصدير الآن</p></div>
          </div>
          <ArrowLeft className="size-4 text-muted-foreground" />
        </button>
      )}
      <Section title="أقساط مستحقة اليوم" icon={Sparkles} action={<button className="text-xs text-primary hover:underline" onClick={() => go("installments")}>عرض الكل</button>}>
        {today.length === 0 ? <Empty icon={CalendarDays} title="لا توجد أقساط مستحقة اليوم" sub="أقساطك القادمة تظهر في صفحة الأقساط." /> : <InstList rows={today} />}
      </Section>
      {db.customers.length === 0 && <p className="note">ابدأ بإضافة أول عميل، ثم أنشئ له خطة أقساط — سيتم توليد جدول الأقساط تلقائيًا ومتابعة المتأخرات.</p>}
      {dlg === "cust" && <CustomerDialog open onClose={() => setDlg("")} />}
      {dlg === "plan" && <PlanDialog open onClose={() => setDlg("")} />}
      {dlg === "exp" && <ExpenseDialog open onClose={() => setDlg("")} />}
    </div>
  );
}

const STATUS: Record<InstStatus, { label: string; cls: string }> = {
  paid: { label: "مسدد", cls: "bg-success/15 text-success" },
  today: { label: "اليوم", cls: "bg-warning/15 text-warning" },
  overdue: { label: "متأخر", cls: "bg-destructive/15 text-destructive" },
  upcoming: { label: "قادم", cls: "bg-info/15 text-info" },
};

function InstList({ rows }: { rows: InstRow[] }) {
  const { db, go } = useApp();
  const [pay, setPay] = useState<{ plan: Plan; amount: number } | null>(null);
  return (
    <div className="divide-y divide-border">
      {rows.map((r) => {
        const plan = db.plans.find((p) => p.id === r.planId)!;
        const c = db.customers.find((x) => x.id === plan.customerId);
        return (
          <div key={r.id} className="flex flex-wrap items-center gap-3 px-4 py-3">
            <button className="min-w-0 basis-full text-right sm:basis-auto sm:flex-1" onClick={() => go("customers", c?.id)}>
              <p className="truncate font-semibold">{c?.name ?? "—"} <span className="text-xs font-normal text-muted-foreground">· {plan.item} · قسط {r.n}/{plan.count}</span></p>
              <p className="text-xs text-muted-foreground">{dateAr(r.due)}</p>
            </button>
            <span className={`rounded-lg px-2 py-0.5 text-xs ${STATUS[r.status].cls}`}>{STATUS[r.status].label}</span>
            <Money v={r.status === "paid" ? r.amount : r.left} className="ms-auto font-bold sm:ms-0 sm:w-24 sm:text-left" />
            {r.status !== "paid" && <button className="btn min-h-9 px-3 text-sm" onClick={() => setPay({ plan, amount: r.left })}>تحصيل</button>}
          </div>
        );
      })}
      {pay && <PaymentDialog open plan={pay.plan} suggest={pay.amount} onClose={() => setPay(null)} />}
    </div>
  );
}

export function Customers({ openId, setOpenId }: { openId?: string | undefined; setOpenId: (id?: string) => void }) {
  const { db } = useApp();
  const [q, setQ] = useState("");
  const [view, setView] = useState<"active" | "archived">("active");
  const [add, setAdd] = useState(false);
  if (openId && db.customers.some((c) => c.id === openId)) return <CustomerDetail id={openId} back={() => setOpenId(undefined)} />;
  const list = db.customers.filter((c) => (view === "archived") === c.archived && (c.name.includes(q) || c.phone.includes(q)));
  const totalLeft = list.reduce((s, c) => s + customerRemaining(db, c.id), 0);
  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <input className="field pr-9" placeholder="ابحث بالاسم أو رقم الجوال..." value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <button className="btn" onClick={() => setAdd(true)}><UserPlus className="size-4" />عميل جديد</button>
      </div>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <Chips value={view} onChange={setView} items={[{ v: "active", label: "العملاء النشطون" }, { v: "archived", label: "المؤرشفون", icon: Archive }]} />
        <p className="text-xs text-muted-foreground">{list.length} عميل · إجمالي المتبقي <Money v={totalLeft} className="text-warning" /></p>
      </div>
      <div className="overflow-hidden rounded-2xl border border-border bg-card/70">
        {list.length === 0 ? <Empty icon={Users} title={view === "active" ? "لا يوجد عملاء بعد" : "لا يوجد عملاء مؤرشفون"} sub="أضف أول عميل لتبدأ متابعة الأقساط." /> : (
          <div className="divide-y divide-border">
            {list.map((c) => {
              const left = customerRemaining(db, c.id);
              const late = db.plans.filter((p) => p.customerId === c.id).some((p) => planRows(db, p.id).some((r) => r.status === "overdue"));
              return (
                <button key={c.id} onClick={() => setOpenId(c.id)} className="flex w-full items-center gap-3 px-4 py-3 text-right hover:bg-muted/40">
                  <div className="grid size-10 shrink-0 place-items-center rounded-xl bg-accent font-bold text-accent-foreground">{c.name.slice(0, 1)}</div>
                  <div className="min-w-0 flex-1">
                    <p className="break-words font-semibold">{c.name}</p>
                    <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1">
                      <span className="text-xs text-muted-foreground" dir="ltr">{c.phone}</span>
                      {late && <span className="rounded-lg bg-destructive/15 px-2 py-0.5 text-xs text-destructive">متأخر</span>}
                      <RatingBadge id={c.id} />
                      <Money v={left} className={`ms-auto font-bold ${left > 0 ? "text-warning" : "text-success"}`} />
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>
      {add && <CustomerDialog open onClose={() => setAdd(false)} />}
    </div>
  );
}

export function Installments() {
  const { db } = useApp();
  const [f, setF] = useState<InstStatus | "all">("today");
  const [q, setQ] = useState("");
  const [bulk, setBulk] = useState(false);
  const rows = useMemo(() => allRows(db, todayISO()).sort((a, b) => a.due.localeCompare(b.due)), [db]);
  const by = (s: InstStatus) => rows.filter((r) => r.status === s);
  const sum = (rs: InstRow[], paid = false) => rs.reduce((s, r) => s + (paid ? r.amount : r.left), 0);
  const list = (f === "all" ? rows : by(f)).filter((r) => !q || String(r.n) === q.trim() || r.id.includes(q.trim()));
  const cards: { s: InstStatus; label: string; tone: string }[] = [
    { s: "today", label: "اليوم", tone: "text-warning" }, { s: "overdue", label: "متأخرة", tone: "text-destructive" },
    { s: "upcoming", label: "قادمة", tone: "text-info" }, { s: "paid", label: "مسدّدة", tone: "text-success" },
  ];
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {cards.map((c) => (
          <button key={c.s} onClick={() => setF(c.s)} className={`stat text-right ${f === c.s ? "border-primary/40 bg-accent/60" : ""}`}>
            <p className="text-sm text-muted-foreground">{c.label} ({by(c.s).length})</p>
            <Money v={sum(by(c.s), c.s === "paid")} className={`text-lg font-bold ${c.tone}`} />
          </button>
        ))}
      </div>
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <input className="field pr-9" placeholder="بحث برقم القسط..." value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <button className="btn" onClick={() => setBulk(true)}><MessageCircle className="size-4" />تذكير جماعي</button>
      </div>
      {bulk && <BulkRemindDialog onClose={() => setBulk(false)} />}
      <Chips value={f} onChange={setF} items={[
        { v: "today", label: "مستحقة اليوم", icon: CalendarDays }, { v: "overdue", label: "متأخرة", icon: AlertTriangle },
        { v: "upcoming", label: "قادمة", icon: Clock }, { v: "paid", label: "مسدّدة", icon: CheckCircle2 }, { v: "all", label: "الكل", icon: Filter },
      ]} />
      <Section title={`${list.length} قسط`} action={<span className="text-xs text-muted-foreground">الإجمالي: <Money v={sum(list, f === "paid")} className="text-gold" /></span>}>
        {list.length === 0 ? <Empty icon={CheckCircle2} title="لا توجد أقساط في هذا القسم" sub="ستظهر الأقساط هنا تلقائيًا حسب تواريخ استحقاقها." /> : <InstList rows={list.slice(0, 300)} />}
      </Section>
    </div>
  );
}
