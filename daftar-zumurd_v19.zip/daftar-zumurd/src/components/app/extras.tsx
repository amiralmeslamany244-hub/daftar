import { openExternal } from "@/lib/utils";
import { SelectField } from "./fields";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Download, FileImage, MessageCircle, Printer, Share2, Trash2, Upload } from "lucide-react";
import { loadDisplay, saveDisplay, type Paper } from "@/lib/display";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import {
  allRows, cur, receiptCode, receiptNo, customerRating, dateAr, fmt, log, planRemaining, RATING_LABEL, todayISO, uid, whatsappLink,
  type Customer, type DB, type Plan, type Rating,
} from "@/lib/store";
import { useApp } from "./ctx";
import { qrDataUrl } from "./features";

const RATING_CLS: Record<Rating, string> = {
  new: "bg-info/15 text-info", regular: "bg-success/15 text-success",
  sometimes: "bg-warning/15 text-warning", defaulting: "bg-destructive/15 text-destructive",
};
export function RatingBadge({ id }: { id: string }) {
  const { db } = useApp();
  const r = customerRating(db, id);
  return <span className={`shrink-0 rounded-lg px-2 py-0.5 text-xs ${RATING_CLS[r]}`}>{RATING_LABEL[r]}</span>;
}

/* ---------- Daily reminder (local notification once a day when the app opens) ---------- */
export function dueSummary(db: DB) {
  const rows = allRows(db).filter((r) => r.status === "today" || r.status === "overdue");
  return { today: rows.filter((r) => r.status === "today").length, overdue: rows.filter((r) => r.status === "overdue").length, total: rows.reduce((s, r) => s + r.left, 0) };
}
export function useDailyReminder(db: DB, update: (fn: (d: DB) => DB) => void) {
  useEffect(() => {
    const s = db.settings;
    if (!s.dailyReminder || s.lastReminder === todayISO() || typeof Notification === "undefined" || Notification.permission !== "granted") return;
    const d = dueSummary(db);
    update((x) => ({ ...x, settings: { ...x.settings, lastReminder: todayISO() } }));
    if (d.today + d.overdue === 0) return;
    const body = `اليوم: ${d.today} قسط · متأخر: ${d.overdue} قسط · الإجمالي ${fmt(d.total)} ${cur(s).sym}`;
    navigator.serviceWorker?.getRegistration().then((reg) => {
      if (reg) reg.showNotification(`أقساط اليوم — ${s.shop}`, { body, icon: "/icons/icon-192.png", lang: "ar", dir: "rtl" });
      else new Notification(`أقساط اليوم — ${s.shop}`, { body, icon: "/icons/icon-192.png" });
    }).catch(() => new Notification(`أقساط اليوم — ${s.shop}`, { body }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
}

/* ---------- Bulk WhatsApp reminders ---------- */
export function BulkRemindDialog({ onClose }: { onClose: () => void }) {
  const { db } = useApp();
  const cc = cur(db.settings);
  const byCust = new Map<string, { c: Customer; amount: number; count: number }>();
  for (const r of allRows(db)) {
    if (r.status !== "overdue" && r.status !== "today") continue;
    const plan = db.plans.find((p) => p.id === r.planId);
    const c = plan && db.customers.find((x) => x.id === plan.customerId);
    if (!c || c.archived) continue;
    const e = byCust.get(c.id) ?? { c, amount: 0, count: 0 };
    e.amount += r.left; e.count++; byCust.set(c.id, e);
  }
  const list = [...byCust.values()].sort((a, b) => b.amount - a.amount);
  const [sent, setSent] = useState<string[]>([]);
  const send = (e: { c: Customer; amount: number; count: number }) => {
    const msg = `مرحبًا ${e.c.name}، تذكير من ${db.settings.shop}: مستحق عليك ${fmt(e.amount)} ${cc.sym} (${e.count} قسط). نرجو السداد في أقرب وقت. شكرًا لك.`;
    openExternal(whatsappLink(e.c.phone, msg, cc.cc));
    setSent((s) => [...s, e.c.id]);
  };
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent dir="rtl" className="max-h-[90vh] overflow-y-auto rounded-2xl border-border bg-card text-right">
        <DialogTitle className="text-lg font-bold">تذكير جماعي بالواتساب</DialogTitle>
        {list.length === 0 ? <p className="text-sm text-muted-foreground">لا يوجد عملاء عليهم أقساط مستحقة أو متأخرة.</p> : (
          <>
            <p className="note">اضغط "إرسال" لكل عميل — يفتح واتساب برسالة جاهزة، ثم ارجع للضغط على التالي. ({sent.length}/{list.length})</p>
            <div className="divide-y divide-border">
              {list.map((e) => (
                <div key={e.c.id} className="flex items-center gap-2 py-2.5">
                  <div className="min-w-0 flex-1"><p className="truncate font-semibold">{e.c.name}</p>
                    <p className="text-xs text-muted-foreground">{e.count} قسط · {fmt(e.amount)} {cc.sym}</p></div>
                  {!e.c.phone ? <span className="text-xs text-muted-foreground">بدون رقم</span> : (
                    <button className={sent.includes(e.c.id) ? "btn-ghost min-h-9 px-3 text-sm" : "btn min-h-9 px-3 text-sm"} onClick={() => send(e)}>
                      <MessageCircle className="size-4" />{sent.includes(e.c.id) ? "أُرسل" : "إرسال"}
                    </button>)}
                </div>
              ))}
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

/* ---------- Payment receipt image ---------- */
export type ReceiptData = { shop: string; customer: string; phone: string; item: string; amount: number; date: string; left: number; sym: string; no: string; code?: string; logo?: string; method?: string; qr?: string };
const METHOD: Record<string, string> = { cash: "نقدًا", bank: "تحويل بنكي", wallet: "محفظة إلكترونية" };
export function receiptFor(db: DB, plan: Plan, amount: number, date: string, payId?: string): ReceiptData {
  const c = db.customers.find((x) => x.id === plan.customerId);
  const pay = payId ? db.payments.find((p) => p.id === payId) : undefined;
  return { shop: db.settings.shop, customer: c?.name ?? "", phone: c?.phone ?? "", item: plan.item, amount, date, left: planRemaining(db, plan), sym: cur(db.settings).sym,
    no: payId ? receiptNo(payId) : String(db.payments.length).padStart(5, "0"), ...(payId ? { code: receiptCode(payId, amount, date) } : {}),
    ...(db.settings.logo ? { logo: db.settings.logo } : {}), ...(pay?.method ? { method: METHOD[pay.method] } : {}) };
}
async function withQr(r: ReceiptData): Promise<ReceiptData> { return r.code && !r.qr ? { ...r, qr: await qrDataUrl(r.code) } : r; }
function loadImg(src: string) { return new Promise<HTMLImageElement>((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = src; }); }
async function drawReceipt(r0: ReceiptData): Promise<Blob> {
  await document.fonts?.ready;
  const r = await withQr(r0);
  const W = 720, H = r.qr ? 1120 : 900, cv = document.createElement("canvas");
  cv.width = W; cv.height = H;
  const g = cv.getContext("2d")!;
  const font = (w: number, s: number) => `${w} ${s}px "IBM Plex Sans Arabic", sans-serif`;
  g.fillStyle = "#0c1f19"; g.fillRect(0, 0, W, H);
  g.strokeStyle = "#c9a24a"; g.lineWidth = 3; g.strokeRect(24, 24, W - 48, H - 48);
  g.direction = "rtl"; g.textAlign = "center"; g.fillStyle = "#c9a24a";
  g.font = font(700, 44); g.fillText(r.shop, W / 2, 110);
  g.fillStyle = "#e8f0ec"; g.font = font(600, 30); g.fillText("إيصال استلام دفعة", W / 2, 165);
  g.fillStyle = "#8fa89c"; g.font = font(400, 22); g.fillText(`رقم ${r.no} · ${dateAr(r.date)}`, W / 2, 205);
  g.strokeStyle = "#2a4a3e"; g.lineWidth = 1; g.beginPath(); g.moveTo(70, 240); g.lineTo(W - 70, 240); g.stroke();
  const row = (y: number, k: string, v: string, color = "#e8f0ec") => {
    g.textAlign = "right"; g.fillStyle = "#8fa89c"; g.font = font(400, 26); g.fillText(k, W - 70, y);
    g.textAlign = "left"; g.fillStyle = color; g.font = font(600, 28); g.fillText(v, 70, y);
  };
  row(310, "العميل", r.customer); row(380, "الصنف", r.item); row(450, "المتبقي على الخطة", `${fmt(r.left)} ${r.sym}`, "#e6b85c");
  g.fillStyle = "#123528"; g.fillRect(70, 510, W - 140, 170);
  g.textAlign = "center"; g.fillStyle = "#8fa89c"; g.font = font(400, 26); g.fillText("المبلغ المستلم", W / 2, 565);
  g.fillStyle = "#5fd39a"; g.font = font(700, 60); g.fillText(`${fmt(r.amount)} ${r.sym}`, W / 2, 645);
  g.fillStyle = "#8fa89c"; g.font = font(400, 22); g.fillText("شكرًا لتعاملكم معنا", W / 2, 780);
  g.fillText(r.method ? `صادر من دفتر زمرد · ${r.method}` : "صادر من دفتر زمرد", W / 2, 820);
  if (r.logo) { try { const im = await loadImg(r.logo); const k = 70 / Math.max(im.width, im.height); g.drawImage(im, 60, 50, im.width * k, im.height * k); } catch { /* skip */ } }
  if (r.qr) { const im = await loadImg(r.qr); g.fillStyle = "#fff"; g.fillRect(W / 2 - 100, 860, 200, 200); g.drawImage(im, W / 2 - 95, 865, 190, 190); g.fillStyle = "#8fa89c"; g.font = font(400, 18); g.fillText(`رمز التحقق من الإيصال · ${r.no}`, W / 2, 1090); }
  return new Promise((res) => cv.toBlob((b) => res(b!), "image/png"));
}
/* ---------- Thermal printer receipt (58 / 80 mm roll) ---------- */
export const esc = (v: string) => v.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);
export function thermalHtml(r: ReceiptData, paper: Paper) {
  const logo = r.logo ? `<p class="c" style="margin:0"><img src="${r.logo}" style="max-height:16mm;max-width:40mm"></p>` : "";
  const qr = r.qr ? `<hr><p class="c" style="margin:0"><img src="${r.qr}" style="width:28mm;height:28mm"></p><p class="c s" style="margin:0">رمز التحقق من الإيصال</p><p class="c s" style="margin:0">امسحه بكاميرا التطبيق للتأكد أن الورقة تطابق ما هو مسجّل في الدفتر</p>` : "";
  const w = paper === "58" ? 48 : 72; // printable width in mm
  const fs = paper === "58" ? 11 : 13;
  const row = (k: string, v: string) => `<tr><td>${esc(k)}</td><td class="v">${esc(v)}</td></tr>`;
  return `<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><title>إيصال ${esc(r.no)}</title><style>
@page { size: ${paper}mm auto; margin: 0; }
* { box-sizing: border-box; }
html, body { margin: 0; padding: 0; background: #fff; color: #000; }
body { width: ${w}mm; margin: 0 auto; padding: 3mm 0 6mm; font: ${fs}px/1.45 "IBM Plex Sans Arabic", Tahoma, Arial, sans-serif; }
h1 { font-size: ${fs + 5}px; margin: 0; text-align: center; }
.c { text-align: center; } .s { font-size: ${fs - 1}px; }
hr { border: 0; border-top: 1px dashed #000; margin: 2mm 0; }
table { width: 100%; border-collapse: collapse; } td { padding: .6mm 0; vertical-align: top; } td.v { text-align: left; font-weight: 700; }
.amt { border: 1.5px solid #000; padding: 2mm; margin: 2mm 0; text-align: center; }
.amt b { display: block; font-size: ${fs + 9}px; }
</style></head><body>
${logo}<h1>${esc(r.shop)}</h1><p class="c" style="margin:1mm 0 0">إيصال استلام دفعة</p>
<p class="c s" style="margin:0">رقم ${esc(r.no)} · ${esc(dateAr(r.date))}</p><hr>
<table>${row("العميل", r.customer)}${r.phone ? row("الجوال", r.phone) : ""}${row("الصنف", r.item)}${r.method ? row("طريقة الدفع", r.method) : ""}</table>
<div class="amt">المبلغ المستلم<b>${esc(fmt(r.amount))} ${esc(r.sym)}</b></div>
<table>${row("المتبقي على الخطة", `${fmt(r.left)} ${r.sym}`)}</table><hr>
<p class="c s" style="margin:0">شكرًا لتعاملكم معنا</p><p class="c s" style="margin:0">التوقيع: ..................</p>${qr}
</body></html>`;
}
/** Prints a full HTML document. Android cannot print from a hidden iframe, so it opens its own page there. */
export function printHtml(html: string) {
  if (/android/i.test(navigator.userAgent)) {
    const blob = new Blob([html.replace("</body>", "<script>window.onload=()=>setTimeout(()=>print(),400)</script></body>")], { type: "text/html" });
    const u = URL.createObjectURL(blob);
    openExternal(u);
    setTimeout(() => URL.revokeObjectURL(u), 120_000);
    return;
  }
  const f = document.createElement("iframe");
  f.setAttribute("aria-hidden", "true");
  Object.assign(f.style, { position: "fixed", right: "0", bottom: "0", width: "0", height: "0", border: "0" });
  f.srcdoc = html;
  f.onload = () => {
    const w = f.contentWindow!;
    const done = () => setTimeout(() => f.remove(), 500);
    w.addEventListener("afterprint", done);
    (w.document.fonts?.ready ?? Promise.resolve()).then(() => { w.focus(); w.print(); setTimeout(done, 60_000); });
  };
  document.body.appendChild(f);
}
export async function printThermal(r: ReceiptData, paper: Paper) { printHtml(thermalHtml(await withQr(r), paper)); }

export function ReceiptActions({ r }: { r: ReceiptData }) {
  const [url, setUrl] = useState("");
  const [blob, setBlob] = useState<Blob | null>(null);
  const [paper, setPaper] = useState<Paper>("80");
  useEffect(() => setPaper(loadDisplay().paper), []);
  useEffect(() => { let u = ""; drawReceipt(r).then((b) => { setBlob(b); u = URL.createObjectURL(b); setUrl(u); }); return () => URL.revokeObjectURL(u); }, [r]);
  const name = `ايصال-${r.no}.png`;
  const text = `إيصال من ${r.shop}: استلمنا ${fmt(r.amount)} ${r.sym} عن "${r.item}" بتاريخ ${dateAr(r.date)}. المتبقي ${fmt(r.left)} ${r.sym}. شكرًا لك.`;
  const download = () => { const a = document.createElement("a"); a.href = url; a.download = name; a.click(); };
  const share = async () => {
    if (!blob) return;
    const file = new File([blob], name, { type: "image/png" });
    if (navigator.canShare?.({ files: [file] })) {
      try { await navigator.share({ files: [file], text }); return; } catch (e) { if ((e as Error).name === "AbortError") return; }
    }
    download();
    setTimeout(() => openExternal(whatsappLink(r.phone, text)), 300);
    toast.info("تم حفظ صورة الإيصال — أرفقها في محادثة الواتساب");
  };
  return (
    <div className="space-y-3">
      {url ? <img src={url} alt="إيصال الدفعة" className="mx-auto w-full max-w-xs rounded-xl border border-border" /> : <div className="h-64 animate-pulse rounded-xl bg-muted" />}
      <div className="grid grid-cols-2 gap-2">
        <button className="btn" onClick={share} disabled={!blob}><Share2 className="size-4" />إرسال بالواتساب</button>
        <button className="btn-ghost" onClick={download} disabled={!url}><Download className="size-4" />حفظ الصورة</button>
      </div>
      <div className="flex items-center gap-2">
        <button className="btn-ghost flex-1" onClick={() => void printThermal(r, paper)}><Printer className="size-4" />طباعة على طابعة صغيرة</button>
        <SelectField ariaLabel="مقاس الورق" className="w-28" value={paper} onChange={(v) => { const p = v as Paper; setPaper(p); saveDisplay({ ...loadDisplay(), paper: p }); }} options={[{ value: "58", label: "58 مم" }, { value: "80", label: "80 مم" }]} />
      </div>
    </div>
  );
}

/* ---------- Guarantor & documents ---------- */
async function compressImage(file: File, max = 1100, q = 0.7): Promise<string> {
  const img = await createImageBitmap(file);
  const k = Math.min(1, max / Math.max(img.width, img.height));
  const cv = document.createElement("canvas");
  cv.width = Math.round(img.width * k); cv.height = Math.round(img.height * k);
  cv.getContext("2d")!.drawImage(img, 0, 0, cv.width, cv.height);
  return cv.toDataURL("image/jpeg", q);
}
export function DocsPanel({ c }: { c: Customer }) {
  const { update, can } = useApp();
  const [view, setView] = useState<string | null>(null);
  const docs = c.docs ?? [];
  const add = async (files: FileList | null) => {
    if (!files?.length) return;
    try {
      const added = await Promise.all([...files].filter((f) => f.type.startsWith("image/")).map(async (f) => ({ id: uid(), name: f.name.replace(/\.[^.]+$/, ""), data: await compressImage(f), at: new Date().toISOString() })));
      update((d) => log({ ...d, customers: d.customers.map((x) => (x.id === c.id ? { ...x, docs: [...(x.docs ?? []), ...added] } : x)) }, "customer", `إضافة ${added.length} مستند للعميل ${c.name}`));
      toast.success("تم حفظ المستندات على الجهاز");
    } catch { toast.error("تعذّر حفظ الصورة — قد تكون مساحة التخزين ممتلئة"); }
  };
  const del = (id: string) => {
    if (!confirm("حذف هذا المستند؟")) return;
    update((d) => ({ ...d, customers: d.customers.map((x) => (x.id === c.id ? { ...x, docs: (x.docs ?? []).filter((y) => y.id !== id) } : x)) }));
  };
  const g = c.guarantor;
  return (
    <div className="panel space-y-3">
      <div>
        <h3 className="mb-1 font-bold">الضامن</h3>
        {g?.name ? (
          <p className="text-sm">{g.name} · <span dir="ltr">{g.phone}</span>{g.idNo && ` · رقم الهوية ${g.idNo}`}{g.address && ` · ${g.address}`}</p>
        ) : <p className="text-sm text-muted-foreground">لا يوجد ضامن — أضفه من "تعديل".</p>}
      </div>
      <div>
        <div className="mb-2 flex items-center justify-between">
          <h3 className="font-bold">المستندات ({docs.length})</h3>
          <label className="chip cursor-pointer"><Upload className="size-4" />إضافة صورة
            <input type="file" accept="image/*" multiple className="hidden" onChange={(e) => { void add(e.target.files); e.target.value = ""; }} />
          </label>
        </div>
        {docs.length === 0 ? <p className="text-sm text-muted-foreground">صوّر البطاقة أو العقد أو إيصال الأمانة واحفظه هنا.</p> : (
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
            {docs.map((d) => (
              <div key={d.id} className="group relative overflow-hidden rounded-xl border border-border">
                <button onClick={() => setView(d.data)} className="block w-full"><img src={d.data} alt={d.name} className="aspect-square w-full object-cover" /></button>
                {can("delete") && <button aria-label="حذف" onClick={() => del(d.id)} className="absolute left-1 top-1 rounded-lg bg-background/80 p-1 text-destructive"><Trash2 className="size-3.5" /></button>}
                <p className="truncate px-1.5 py-1 text-[11px] text-muted-foreground"><FileImage className="me-1 inline size-3" />{d.name}</p>
              </div>
            ))}
          </div>
        )}
      </div>
      {view && (
        <Dialog open onOpenChange={(o) => !o && setView(null)}>
          <DialogContent dir="rtl" className="max-w-3xl rounded-2xl border-border bg-card p-3"><DialogTitle className="sr-only">مستند</DialogTitle>
            <img src={view} alt="مستند" className="max-h-[80vh] w-full rounded-xl object-contain" /></DialogContent>
        </Dialog>
      )}
    </div>
  );
}
