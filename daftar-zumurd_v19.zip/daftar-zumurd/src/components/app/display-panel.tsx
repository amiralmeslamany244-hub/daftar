import { useEffect, useState } from "react";
import { Moon, Printer, Sun, Type } from "lucide-react";
import { DEFAULT_DISPLAY, loadDisplay, saveDisplay, SCALES, type Display } from "@/lib/display";
import { printThermal } from "./extras";
import { useApp } from "./ctx";
import { cur } from "@/lib/store";

/** Theme, text size and receipt paper — saved on this device. */
export function DisplayPanel() {
  const { db } = useApp();
  const [d, setD] = useState<Display>(DEFAULT_DISPLAY);
  useEffect(() => setD(loadDisplay()), []);
  const set = (p: Partial<Display>) => { const n = { ...d, ...p }; setD(n); saveDisplay(n); };
  const opt = (on: boolean) => (on ? "chip chip-on" : "chip");
  const test = () => printThermal({ shop: db.settings.shop, customer: "عميل تجريبي", phone: "", item: "صنف تجريبي", amount: 1000, date: new Date().toISOString().slice(0, 10), left: 4000, sym: cur(db.settings).sym, no: "00000" }, d.paper);
  return (
    <div className="panel space-y-4">
      <p className="flex items-center gap-2 font-bold"><Sun className="size-4 text-gold" />العرض والطباعة</p>
      <div className="space-y-2">
        <p className="text-sm text-muted-foreground">المظهر</p>
        <div className="flex flex-wrap gap-2">
          <button className={opt(d.theme === "dark")} aria-pressed={d.theme === "dark"} onClick={() => set({ theme: "dark" })}><Moon className="size-4" />داكن</button>
          <button className={opt(d.theme === "light")} aria-pressed={d.theme === "light"} onClick={() => set({ theme: "light" })}><Sun className="size-4" />فاتح</button>
        </div>
      </div>
      <div className="space-y-2">
        <p className="flex items-center gap-1.5 text-sm text-muted-foreground"><Type className="size-4" />حجم الخط</p>
        <div className="flex flex-wrap gap-2">
          {SCALES.map((s) => <button key={s.v} className={opt(d.scale === s.v)} aria-pressed={d.scale === s.v} onClick={() => set({ scale: s.v })} style={{ fontSize: `${s.v * 0.875}rem` }}>{s.label}</button>)}
        </div>
      </div>
      <div className="space-y-2">
        <p className="flex items-center gap-1.5 text-sm text-muted-foreground"><Printer className="size-4" />مقاس ورق الطابعة الصغيرة</p>
        <div className="flex flex-wrap gap-2">
          {(["58", "80"] as const).map((p) => <button key={p} className={opt(d.paper === p)} aria-pressed={d.paper === p} onClick={() => set({ paper: p })}>{p} مم</button>)}
          <button className="btn-ghost" onClick={test}><Printer className="size-4" />طباعة إيصال تجريبي</button>
        </div>
        <p className="text-xs text-muted-foreground">وصّل الطابعة بالجهاز (بلوتوث أو USB) واخترها من نافذة الطباعة. اجعل الهوامش «بدون» إن ظهرت.</p>
      </div>
    </div>
  );
}
