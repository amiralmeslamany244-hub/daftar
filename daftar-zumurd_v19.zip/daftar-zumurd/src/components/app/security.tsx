import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Fingerprint, KeyRound, Pencil, Trash2, UserPlus, Users } from "lucide-react";
import { bioRegister, bioSupported } from "@/lib/biometric";
import { hash, hashPin, log, pinTaken, saveAuth, uid, usernameTaken, validPin, type Auth, type Staff } from "@/lib/store";
import { useApp } from "./ctx";
import { L } from "./ui";

const digits = (v: string) => v.replace(/[٠-٩]/g, (c) => String(c.charCodeAt(0) - 0x660)).replace(/\s/g, "");

function useSaveAuth() {
  const { auth, setAuth, update } = useApp();
  void auth;
  return (next: Auth, msg: string) => { saveAuth(next); setAuth(next); update((d) => log(d, "security", msg)); };
}

/** Owner quick unlock: PIN and device fingerprint / face. */
export function QuickUnlockPanel() {
  const { auth } = useApp();
  const save = useSaveAuth();
  const [pin, setPin] = useState(""); const [pin2, setPin2] = useState("");
  const [bioOk, setBioOk] = useState<boolean | null>(null);
  useEffect(() => { bioSupported().then(setBioOk); }, []);
  const setOwnerPin = async () => {
    const p = digits(pin);
    if (!validPin(p)) { toast.error("الرقم السري من 4 إلى 6 أرقام"); return; }
    if (p !== digits(pin2)) { toast.error("الرقمان غير متطابقين"); return; }
    if (await pinTaken(auth, p, undefined, true)) { toast.error("هذا الرقم مستخدم لموظف — اختر رقمًا آخر"); return; }
    save({ ...auth, pin: await hashPin(p) }, auth.pin ? "تغيير الرقم السري لصاحب المحل" : "تفعيل الرقم السري لصاحب المحل");
    setPin(""); setPin2(""); toast.success("تم حفظ الرقم السري");
  };
  const addBio = async () => {
    try { const id = await bioRegister(auth.user); save({ ...auth, bio: id }, "تفعيل الفتح بالبصمة"); toast.success("تم تفعيل الفتح بالبصمة على هذا الجهاز"); }
    catch { toast.error("لم يكتمل تسجيل البصمة"); }
  };
  return (
    <div className="panel space-y-4">
      <p className="flex items-center gap-2 font-bold"><KeyRound className="size-4 text-primary" />الفتح السريع</p>
      <p className="text-sm text-muted-foreground">بدل كتابة كلمة المرور كل مرة: رقم سري من 4 إلى 6 أرقام، أو بصمة / وجه الجهاز. كلمة المرور تبقى تعمل دائمًا.</p>
      <div className="grid gap-4 sm:grid-cols-2">
        <L t={auth.pin ? "رقم سري جديد" : "الرقم السري"}><input className="field" type="password" inputMode="numeric" dir="ltr" maxLength={6} value={pin} onChange={(e) => setPin(e.target.value)} placeholder="4–6 أرقام" /></L>
        <L t="تأكيد الرقم السري"><input className="field" type="password" inputMode="numeric" dir="ltr" maxLength={6} value={pin2} onChange={(e) => setPin2(e.target.value)} /></L>
      </div>
      <div className="flex flex-wrap gap-2">
        <button className="btn" disabled={!pin} onClick={setOwnerPin}>{auth.pin ? "تغيير الرقم السري" : "تفعيل الرقم السري"}</button>
        {auth.pin && <button className="btn-ghost" onClick={() => { save({ ...auth, pin: undefined }, "إلغاء الرقم السري لصاحب المحل"); toast.success("تم إلغاء الرقم السري"); }}>إلغاء الرقم السري</button>}
      </div>
      <div className="flex flex-wrap items-center justify-between gap-3 border-t border-border pt-4">
        <div className="min-w-0">
          <p className="flex items-center gap-2 font-semibold"><Fingerprint className="size-4 text-primary" />البصمة / الوجه {auth.bio && <span className="rounded-lg bg-success/15 px-2 py-0.5 text-xs text-success">مفعّلة</span>}</p>
          <p className="text-xs text-muted-foreground">{bioOk === false ? "هذا الجهاز أو المتصفح لا يدعم البصمة — ثبّت التطبيق على الهاتف وجرّب مجددًا." : "لصاحب المحل فقط، وتعمل على هذا الجهاز وحده."}</p>
        </div>
        {auth.bio ? <button className="btn-ghost" onClick={() => { save({ ...auth, bio: undefined }, "إلغاء الفتح بالبصمة"); toast.success("تم إلغاء البصمة"); }}>إلغاء البصمة</button>
          : <button className="btn-ghost" disabled={!bioOk} onClick={addBio}><Fingerprint className="size-4" />تفعيل البصمة</button>}
      </div>
    </div>
  );
}

/** Staff accounts with limited permissions. */
export function StaffPanel() {
  const { auth } = useApp();
  const save = useSaveAuth();
  const staff = auth.staff ?? [];
  const [edit, setEdit] = useState<Staff | "new" | null>(null);
  const empty = { name: "", user: "", pass: "", pin: "" };
  const [f, setF] = useState(empty);
  const open = (s: Staff | "new") => { setEdit(s); setF(s === "new" ? empty : { name: s.name, user: s.user, pass: "", pin: "" }); };
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const isNew = edit === "new"; const id = isNew ? uid() : (edit as Staff).id;
    const pin = digits(f.pin);
    if (!f.name.trim() || !f.user.trim()) { toast.error("اكتب اسم الموظف واسم المستخدم"); return; }
    if (usernameTaken(auth, f.user, id)) { toast.error("اسم المستخدم مستخدم بالفعل"); return; }
    if (isNew && f.pass.length < 4) { toast.error("كلمة المرور 4 أحرف على الأقل"); return; }
    if (!isNew && f.pass && f.pass.length < 4) { toast.error("كلمة المرور 4 أحرف على الأقل"); return; }
    if (pin && !validPin(pin)) { toast.error("الرقم السري من 4 إلى 6 أرقام"); return; }
    if (pin && (await pinTaken(auth, pin, id))) { toast.error("هذا الرقم السري مستخدم — اختر رقمًا آخر"); return; }
    const prev = isNew ? undefined : (edit as Staff);
    const s: Staff = { id, name: f.name.trim(), user: f.user.trim(), active: prev?.active ?? true,
      pass: f.pass ? await hash(f.pass) : prev!.pass, pin: pin ? await hashPin(pin) : prev?.pin };
    save({ ...auth, staff: isNew ? [...staff, s] : staff.map((x) => (x.id === id ? s : x)) }, `${isNew ? "إضافة" : "تعديل"} الموظف ${s.name}`);
    setEdit(null); toast.success(isNew ? "تمت إضافة الموظف" : "تم حفظ التعديل");
  };
  const toggle = (s: Staff) => save({ ...auth, staff: staff.map((x) => (x.id === s.id ? { ...x, active: !x.active } : x)) }, `${s.active ? "إيقاف" : "تفعيل"} الموظف ${s.name}`);
  const remove = (s: Staff) => { if (confirm(`حذف الموظف ${s.name}؟`)) save({ ...auth, staff: staff.filter((x) => x.id !== s.id) }, `حذف الموظف ${s.name}`); };
  return (
    <div className="panel space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="flex items-center gap-2 font-bold"><Users className="size-4 text-primary" />المستخدمون على هذا الجهاز</p>
        {!edit && <button className="btn-ghost" onClick={() => open("new")}><UserPlus className="size-4" />إضافة موظف</button>}
      </div>
      <p className="text-sm text-muted-foreground">الموظف يضيف العملاء والخطط ويسجّل الدفعات والمصروفات، لكنه لا يحذف ولا يؤرشف، ولا يرى التقارير ولا سجل العمليات ولا النسخ الاحتياطي ولا الإعدادات. كل ما يسجّله يظهر في السجل باسمه.</p>
      {!auth.enabled && staff.length > 0 && <p className="warn">القفل معطّل الآن، فيفتح الدفتر مباشرة بصلاحيات صاحب المحل. فعّل القفل ليدخل كل موظف بحسابه.</p>}
      <div className="divide-y divide-border rounded-xl border border-border">
        <div className="flex items-center justify-between px-3 py-2.5 text-sm"><span className="font-semibold">{auth.user}</span><span className="rounded-lg bg-gold/15 px-2 py-0.5 text-xs text-gold">صاحب المحل</span></div>
        {staff.map((s) => (
          <div key={s.id} className="flex flex-wrap items-center gap-2 px-3 py-2.5 text-sm">
            <div className="min-w-0 flex-1"><p className={`font-semibold ${s.active ? "" : "text-muted-foreground line-through"}`}>{s.name}</p><p className="text-xs text-muted-foreground" dir="ltr">{s.user}{s.pin ? " · PIN" : ""}</p></div>
            <span className={`rounded-lg px-2 py-0.5 text-xs ${s.active ? "bg-info/15 text-info" : "bg-muted text-muted-foreground"}`}>{s.active ? "موظف" : "موقوف"}</span>
            <button className="chip" onClick={() => toggle(s)}>{s.active ? "إيقاف" : "تفعيل"}</button>
            <button className="chip" aria-label="تعديل الموظف" onClick={() => open(s)}><Pencil className="size-4" /></button>
            <button className="chip" aria-label="حذف الموظف" onClick={() => remove(s)}><Trash2 className="size-4" /></button>
          </div>
        ))}
      </div>
      {edit && (
        <form onSubmit={submit} className="space-y-3 rounded-xl border border-border p-3">
          <p className="font-semibold">{edit === "new" ? "موظف جديد" : `تعديل ${(edit as Staff).name}`}</p>
          <div className="grid gap-3 sm:grid-cols-2">
            <L t="اسم الموظف"><input className="field" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></L>
            <L t="اسم المستخدم"><input className="field" dir="ltr" value={f.user} onChange={(e) => setF({ ...f, user: e.target.value })} autoComplete="off" /></L>
            <L t={edit === "new" ? "كلمة المرور" : "كلمة مرور جديدة (اختياري)"}><input className="field" type="password" value={f.pass} onChange={(e) => setF({ ...f, pass: e.target.value })} autoComplete="new-password" placeholder="4 أحرف على الأقل" /></L>
            <L t={edit !== "new" && (edit as Staff).pin ? "رقم سري جديد (اختياري)" : "رقم سري سريع (اختياري)"}><input className="field" type="password" inputMode="numeric" dir="ltr" maxLength={6} value={f.pin} onChange={(e) => setF({ ...f, pin: e.target.value })} placeholder="4–6 أرقام" /></L>
          </div>
          <div className="flex gap-2"><button className="btn">حفظ</button><button type="button" className="btn-ghost" onClick={() => setEdit(null)}>إلغاء</button></div>
        </form>
      )}
    </div>
  );
}
