import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import QRCode from "qrcode";
import {
  ArchiveRestore, BadgeCheck, CalendarClock, Camera, CameraOff, ImageUp, Scale, ScanLine, ShieldAlert, ShieldCheck, ShieldX, Trash2, TrendingDown, TrendingUp, Undo2,
} from "lucide-react";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import {
  cashForecast, dateAr, delayStats, fmt, lastMonths, log, monthStats, planCredit, planRemaining, postpone, receiptNo, restoreTrash,
  settleCredit, toNum, verifyReceipt, type InstRow, type Plan, type VerifyResult,
} from "@/lib/store";
import { useApp } from "./ctx";
import { DateField, SelectField } from "./fields";
import { Empty, L, Money, Section, Stat } from "./ui";

export const qrDataUrl = (text: string) => QRCode.toDataURL(text, { margin: 1, width: 240, errorCorrectionLevel: "M" });
const monthLabel = (k: string) => new Date(k + "-01T00:00:00").toLocaleDateString("ar-EG-u-nu-latn", { month: "long", year: "numeric" });

/* ---------- Undo ---------- */
export function UndoButton() {
  const { undo, undoLabel } = useApp();
  if (!undoLabel) return null;
  return (
    <button className="chip" title={`تراجع عن: ${undoLabel}`} aria-label="تراجع عن آخر عملية"
      onClick={() => { if (confirm(`سيعود الدفتر إلى حالته قبل: ${undoLabel}\nأي تعديل جرى بعدها يُلغى أيضًا، والبيانات تعود كما كانت قبل العملية.`)) undo(); }}>
      <Undo2 className="size-4" /><span className="hidden sm:inline">تراجع</span>
    </button>
  );
}

/* ---------- Trash ---------- */
const KIND_LABEL = { customer: "عميل", plan: "خطة", payment: "دفعة", expense: "مصروف" } as const;
export function TrashPage() {
  const { db, update, can } = useApp();
  const list = db.trash ?? [];
  const restore = (id: string, label: string) => {
    update((d) => log(restoreTrash(d, id), "security", `استعادة من سلة المحذوفات: ${label}`));
    toast.success("تمت الاستعادة إلى الدفتر بحالته المحفوظة، وتُحدَّث الأرصدة والمتبقي تلقائيًا");
  };
  const purge = (id: string, label: string) => {
    if (!confirm(`سيُحذف «${label}» من السلة نهائيًا ولا يمكن استعادته بعد ذلك.`)) return;
    update((d) => log({ ...d, trash: d.trash.filter((x) => x.id !== id) }, "security", `حذف نهائي من السلة: ${label}`));
  };
  const empty = () => {
    if (!confirm(`سيتم حذف ${list.length} عنصرًا من السلة نهائيًا. لا يمكن التراجع بعد ذلك.`)) return;
    update((d) => log({ ...d, trash: [] }, "security", `إفراغ سلة المحذوفات (${list.length} عنصر)`));
    toast.success("تم إفراغ السلة");
  };
  return (
    <div className="space-y-3">
      <p className="note">كل ما تحذفه يبقى هنا على هذا الجهاز ولا يضيع. استعِد ما تحتاجه، واحذفه نهائيًا حين تتأكد.</p>
      <Section title="سلة المحذوفات" icon={Trash2} count={list.length}
        action={list.length > 0 && can("delete") ? <button className="chip text-destructive" onClick={empty}><Trash2 className="size-4" />إفراغ السلة</button> : undefined}>
        {list.length === 0 ? <Empty icon={Trash2} title="السلة فارغة" sub="أي حذف لدفعة أو مصروف أو عميل أو خطة سيظهر هنا لاستعادته." /> : (
          <div className="divide-y divide-border">{list.map((t) => (
            <div key={t.id} className="flex flex-wrap items-center gap-3 px-4 py-3 text-sm">
              <span className="rounded-lg bg-muted px-2 py-0.5 text-xs">{KIND_LABEL[t.kind]}</span>
              <div className="min-w-0 flex-1"><p className="truncate font-semibold">{t.label}</p>
                <p className="text-xs text-muted-foreground">حُذف {new Date(t.at).toLocaleString("ar-EG-u-nu-latn", { dateStyle: "medium", timeStyle: "short" })}</p></div>
              <button className="btn min-h-9 px-3 text-sm" onClick={() => restore(t.id, t.label)}><ArchiveRestore className="size-4" />استعادة</button>
              {can("delete") && <button className="chip text-destructive" aria-label="حذف نهائي" onClick={() => purge(t.id, t.label)}><Trash2 className="size-4" /></button>}
            </div>
          ))}</div>
        )}
      </Section>
    </div>
  );
}

/* ---------- Postpone ---------- */
const REASONS = ["طلب العميل تأجيل شهر", "دفعة جزئية بموافقة العميل", "ظرف طارئ", "أخرى"];
export function PostponeDialog({ row, onClose }: { row: InstRow; onClose: () => void }) {
  const { update } = useApp();
  const [date, setDate] = useState(row.due);
  const [reason, setReason] = useState(REASONS[0]!);
  const [note, setNote] = useState("");
  const save = () => {
    if (!date || date === row.due) { toast.error("اختر التاريخ الجديد"); return; }
    update((d) => postpone(d, row.id, date, reason === "أخرى" ? note.trim() : reason + (note.trim() ? ` — ${note.trim()}` : "")));
    toast.success("تم تأجيل القسط"); onClose();
  };
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent dir="rtl" className="w-[calc(100%-1rem)] rounded-2xl border-border bg-card text-right">
        <DialogTitle className="text-lg font-bold">تأجيل قسط {row.n}</DialogTitle>
        <p className="text-sm text-muted-foreground">الموعد الحالي: {dateAr(row.due)}</p>
        <L t="اختر التاريخ الجديد"><DateField ariaLabel="التاريخ الجديد" value={date} onChange={setDate} /></L>
        <L t="سبب التأجيل"><SelectField ariaLabel="سبب التأجيل" value={reason} onChange={setReason} options={REASONS.map((r) => ({ value: r, label: r }))} /></L>
        <L t="ملاحظة (اختياري)"><input className="field" value={note} onChange={(e) => setNote(e.target.value)} /></L>
        <p className="text-xs text-muted-foreground">يُحفظ التاريخ السابق في سجل القسط، وتظهر عملية التأجيل في سجل العمليات.</p>
        {(row.history ?? []).length > 0 && (
          <div className="rounded-xl border border-border p-2 text-xs text-muted-foreground">
            {(row.history ?? []).map((h, i) => <p key={i}>مؤجَّل من {dateAr(h.from)} إلى {dateAr(h.to)}{h.reason ? ` — ${h.reason}` : ""}</p>)}
          </div>
        )}
        <button className="btn w-full" onClick={save}><CalendarClock className="size-4" />حفظ التأجيل</button>
      </DialogContent>
    </Dialog>
  );
}

/* ---------- Credit settlement ---------- */
export function CreditDialog({ plans, onClose }: { plans: Plan[]; onClose: () => void }) {
  const { db, update } = useApp();
  const from = plans.filter((p) => planCredit(db, p) > 0);
  const to = plans.filter((p) => planRemaining(db, p) > 0);
  const [f, setF] = useState(from[0]?.id ?? "");
  const [t, setT] = useState(to[0]?.id ?? "");
  const fp = from.find((p) => p.id === f); const tp = to.find((p) => p.id === t);
  const max = fp && tp ? Math.min(planCredit(db, fp), planRemaining(db, tp)) : 0;
  const [amount, setAmount] = useState(String(max));
  const save = () => {
    const a = toNum(amount);
    if (!fp || !tp) { toast.error("لا يوجد رصيد دائن متاح لتسويته"); return; }
    if (!(a > 0) || a > max + 0.001) { toast.error("أدخل مبلغًا صحيحًا"); return; }
    update((d) => settleCredit(d, fp.id, tp.id, a));
    toast.success("تمت التسوية — هذه تسوية حسابية ولا تُحسب كإيراد نقدي جديد"); onClose();
  };
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent dir="rtl" className="w-[calc(100%-1rem)] rounded-2xl border-border bg-card text-right">
        <DialogTitle className="text-lg font-bold">تسوية رصيد دائن</DialogTitle>
        {from.length === 0 || to.length === 0 ? <p className="text-sm text-muted-foreground">لا يوجد رصيد دائن متاح لتسويته على قسط مستحق.</p> : <>
          <L t="من خطة (رصيد دائن)"><SelectField ariaLabel="من" value={f} onChange={(v) => { setF(v); }} options={from.map((p) => ({ value: p.id, label: `${p.item} — ${fmt(planCredit(db, p))}` }))} /></L>
          <L t="إلى خطة (متبقي)"><SelectField ariaLabel="إلى" value={t} onChange={setT} options={to.map((p) => ({ value: p.id, label: `${p.item} — ${fmt(planRemaining(db, p))}` }))} /></L>
          <L t="المبلغ" hint={`الحد الأقصى ${fmt(max)}`}><input className="field" inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} /></L>
          <p className="text-xs text-muted-foreground">الرصيد الدائن لا يُضاف إلى المديونية، وهذه تسوية حسابية ولا تُحسب كإيراد نقدي جديد.</p>
          <button className="btn w-full" onClick={save}><Scale className="size-4" />تسوية</button>
        </>}
      </DialogContent>
    </Dialog>
  );
}

/* ---------- Customer regularity ---------- */
export function DelayPanel({ id }: { id: string }) {
  const { db } = useApp();
  const s = delayStats(db, id);
  if (!s.count) return null;
  return (
    <div className="panel">
      <p className="mb-2 font-bold">انتظام العميل</p>
      <div className="grid grid-cols-3 gap-2 text-center text-xs">
        <div className="rounded-xl border border-border p-2"><p className="text-muted-foreground">سداد في الموعد</p><p className="text-lg font-bold text-success">{s.onTime}/{s.count}</p></div>
        <div className="rounded-xl border border-border p-2"><p className="text-muted-foreground">متوسط التأخير</p><p className="text-lg font-bold text-warning">{s.avg} يوم</p></div>
        <div className="rounded-xl border border-border p-2"><p className="text-muted-foreground">أطول تأخير</p><p className="text-lg font-bold text-destructive">{s.max} يوم</p></div>
      </div>
    </div>
  );
}

/* ---------- Financial report ---------- */
export function FinancialReport() {
  const { db } = useApp();
  const [n, setN] = useState(6);
  const months = lastMonths(n).map((k) => monthStats(db, k));
  const cur = months[months.length - 1]!; const prev = months[months.length - 2];
  const fc = cashForecast(db, 3);
  const diff = (a: number, b?: number) => (b === undefined ? null : a - b);
  const Trend = ({ v, good = "up" }: { v: number | null; good?: "up" | "down" }) => v === null || v === 0
    ? <span className="text-xs text-muted-foreground">لا تغيّر عن الشهر الماضي</span>
    : <span className={`flex items-center gap-1 text-xs ${(v > 0) === (good === "up") ? "text-success" : "text-destructive"}`}>{v > 0 ? <TrendingUp className="size-3" /> : <TrendingDown className="size-3" />}{v > 0 ? "زادت" : "نقصت"} {fmt(Math.abs(v))} عن الشهر الماضي</span>;
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <div className="stat"><p className="text-sm text-muted-foreground">تحصيل هذا الشهر</p><Money v={cur.collected} className="block text-xl font-bold text-success" /><Trend v={diff(cur.collected, prev?.collected)} /></div>
        <div className="stat"><p className="text-sm text-muted-foreground">نسبة التحصيل هذا الشهر</p><p className="text-xl font-bold">{cur.rate}%</p><span className="text-xs text-muted-foreground">نسبة التحصيل الشهر الماضي {prev?.rate ?? 0}%</span></div>
        <div className="stat"><p className="text-sm text-muted-foreground">المتأخر الآن</p><Money v={fc.overdue} className="block text-xl font-bold text-destructive" /><Trend v={diff(cur.overdueEnd, prev?.overdueEnd)} good="down" /></div>
        <div className="stat"><p className="text-sm text-muted-foreground">متوسط المصروف الشهري</p><Money v={fc.avgExp} className="block text-xl font-bold" /><span className="text-xs text-muted-foreground">آخر ثلاثة أشهر</span></div>
      </div>
      <Section title="المقارنة الشهرية" action={<SelectField ariaLabel="المدة" className="w-auto" value={String(n)} onChange={(v) => setN(Number(v))} options={[{ value: "3", label: "آخر ثلاثة أشهر" }, { value: "6", label: "آخر ٦ أشهر" }, { value: "12", label: "آخر 12 شهرًا" }]} />}>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/40 text-xs text-muted-foreground"><tr>{["الشهر", "المستحق", "التحصيل الفعلي", "نسبة التحصيل", "المصروفات", "الصافي", "المتأخر آخر الشهر"].map((h) => <th key={h} className="px-3 py-2 text-right font-medium">{h}</th>)}</tr></thead>
            <tbody className="divide-y divide-border">{[...months].reverse().map((m) => (
              <tr key={m.key}><td className="px-3 py-2 whitespace-nowrap">{monthLabel(m.key)}</td><td className="px-3 py-2"><Money v={m.due} /></td>
                <td className="px-3 py-2"><Money v={m.collected} className="text-success" /></td><td className="px-3 py-2">{m.rate}%</td>
                <td className="px-3 py-2"><Money v={m.expenses} className="text-destructive" /></td><td className="px-3 py-2"><Money v={m.net} className="text-gold" /></td>
                <td className="px-3 py-2"><Money v={m.overdueEnd} className="text-destructive" /></td></tr>
            ))}</tbody>
          </table>
        </div>
        <p className="px-4 py-2 text-xs text-muted-foreground">أرقام كل شهر محسوبة من تواريخ الدفعات والاستحقاقات المسجّلة على جهازك، لا من أرقام اليوم. نسبة التحصيل = المحصّل مقابل المستحق في ذلك الشهر، وقد تتجاوز ١٠٠٪ إذا سُدّد فيه أكثر من أقساطه.</p>
      </Section>
      <Section title="التدفق النقدي المتوقع" icon={TrendingUp}>
        <div className="grid gap-3 p-4 sm:grid-cols-4">
          <Stat label="المتأخر مستحق الآن" value={fc.overdue} tone="text-destructive" />
          {fc.months.map((m) => <div key={m.key} className="stat"><p className="text-sm text-muted-foreground">{monthLabel(m.key)}</p><Money v={m.expected} className="block text-lg font-bold text-info" /><span className="block text-xs text-muted-foreground">بعد المصروف المتوقع: <Money v={m.net} className={m.net >= 0 ? "text-success" : "text-destructive"} /></span></div>)}
        </div>
        <p className="px-4 pb-3 text-xs text-muted-foreground">التوقع حسابي من تواريخ استحقاق الأقساط المتبقية على جهازك، بافتراض سداد العملاء في مواعيدها. الأقساط المتأخرة تُعرض منفصلة حتى لا تُحسب مرتين، والمصروف المتوقع تقديري بمتوسط آخر ثلاثة أشهر.</p>
      </Section>
    </div>
  );
}

/* ---------- Receipt verifier ---------- */
type BD = { detect: (s: CanvasImageSource) => Promise<{ rawValue: string }[]> };
export function VerifyPage() {
  const { db } = useApp();
  const [code, setCode] = useState("");
  const [res, setRes] = useState<VerifyResult | null>(null);
  const [cam, setCam] = useState(false);
  const video = useRef<HTMLVideoElement>(null);
  const check = (v = code) => setRes(verifyReceipt(db, v));
  useEffect(() => {
    if (!cam) return;
    let stream: MediaStream | null = null; let stop = false;
    const Det = (window as unknown as { BarcodeDetector?: new (o: { formats: string[] }) => BD }).BarcodeDetector;
    if (!Det) { toast.error("هذا المتصفح لا يدعم قراءة الرمز بالكاميرا — اكتب رقم الإيصال يدويًا"); setCam(false); return; }
    const det = new Det({ formats: ["qr_code"] });
    navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } }).then(async (s) => {
      stream = s; if (!video.current) return; video.current.srcObject = s; await video.current.play();
      const loop = async () => {
        if (stop || !video.current) return;
        try { const r = await det.detect(video.current); if (r[0]) { setCode(r[0].rawValue); check(r[0].rawValue); setCam(false); return; } } catch { /* keep scanning */ }
        setTimeout(loop, 300);
      };
      void loop();
    }).catch(() => { toast.error("اسمح بالوصول إلى الكاميرا ثم حاول مرة أخرى"); setCam(false); });
    return () => { stop = true; stream?.getTracks().forEach((t) => t.stop()); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cam]);
  const pay = res && "pay" in res ? res.pay : null;
  const plan = pay ? db.plans.find((p) => p.id === pay.planId) : null;
  const cust = plan ? db.customers.find((c) => c.id === plan.customerId) : null;
  return (
    <div className="space-y-4">
      <div className="panel space-y-3">
        <p className="flex items-center gap-2 font-bold"><ScanLine className="size-4 text-primary" />التحقق من إيصال</p>
        <p className="text-sm text-muted-foreground">امسح رمز التحقق المطبوع أسفل الإيصال، أو اكتب رقم الإيصال الظاهر على الورقة، ليخبرك الدفتر هل هذا الإيصال صادر منه وما مبلغه وتاريخه.</p>
        {cam && <video ref={video} className="mx-auto w-full max-w-sm rounded-xl border border-border" muted playsInline />}
        <div className="flex gap-2">
          <input className="field flex-1" dir="ltr" placeholder="رقم الإيصال المكتوب على الورقة" value={code} onChange={(e) => setCode(e.target.value)} onKeyDown={(e) => e.key === "Enter" && check()} />
          <button className="btn" onClick={() => check()}>تحقّق</button>
          <button className="btn-ghost" onClick={() => setCam(!cam)}>{cam ? <CameraOff className="size-4" /> : <Camera className="size-4" />}<span className="hidden sm:inline">{cam ? "إيقاف الكاميرا" : "قراءة بالكاميرا"}</span></button>
        </div>
        <p className="text-xs text-muted-foreground">الإدخال اليدوي برقم الإيصال يعمل دون إنترنت دائمًا، ولا يحتاج كاميرا.</p>
      </div>
      {res && (
        <div className={`panel space-y-2 ${res.ok === "match" ? "border-success/40" : "border-destructive/40"}`}>
          {res.ok === "match" && <p className="flex items-center gap-2 font-bold text-success"><ShieldCheck className="size-5" />إيصال مطابق وصادر من هذا الدفتر</p>}
          {res.ok === "differs" && <><p className="flex items-center gap-2 font-bold text-warning"><ShieldAlert className="size-5" />الإيصال موجود، لكن الورقة لا تطابق الدفتر</p>
            <p className="text-sm">الرمز يحمل مبلغًا أو تاريخًا مختلفًا عن المسجّل في دفترك: المبلغ في الرمز {fmt(res.amount)} · التاريخ في الرمز {dateAr(res.date)}</p></>}
          {res.ok === "missing" && <p className="flex items-center gap-2 font-bold text-destructive"><ShieldX className="size-5" />رمز صحيح، لكن الدفعة غير موجودة هنا — الأرجح أن الإيصال من دفتر آخر أو من جهاز آخر، أو أن الدفعة حُذفت من الدفتر.</p>}
          {res.ok === "tampered" && <p className="flex items-center gap-2 font-bold text-destructive"><ShieldX className="size-5" />الرمز غير متماسك — حرف التحقق داخل الرمز لا يطابق رقمه ومبلغه وتاريخه، فقد يكون الرقم المكتوب عليها مُعدّلًا.</p>}
          {res.ok === "invalid" && <p className="flex items-center gap-2 font-bold text-destructive"><ShieldX className="size-5" />هذا ليس رمز إيصال من دفتر زمرد. تأكد من الرقم أو امسح رمز التحقق أسفل الإيصال.</p>}
          {pay && <div className="grid grid-cols-2 gap-2 text-sm">
            <p>رقم الإيصال: <b dir="ltr">{receiptNo(pay.id)}</b></p><p>العميل: <b>{cust?.name ?? "عميل غير معروف"}</b></p>
            <p>المبلغ في الدفتر: <Money v={pay.amount} className="font-bold" /></p><p>التاريخ في الدفتر: <b>{dateAr(pay.date)}</b></p>
            {plan && <p className="col-span-2">البند: {plan.item}</p>}
          </div>}
          <p className="text-xs text-muted-foreground">الرمز يقارن الورقة بما هو مسجّل في دفترك على هذا الجهاز، ويكشف رقمًا أو مبلغًا معدّلًا، وهو ليس توقيعًا رقميًا مضمونًا.</p>
        </div>
      )}
    </div>
  );
}

/* ---------- Shop logo ---------- */
export function LogoPanel() {
  const { db, update } = useApp();
  const pick = async (f?: File) => {
    if (!f) return;
    if (!f.type.startsWith("image/")) { toast.error("الملف المختار ليس صورة"); return; }
    try {
      const img = await createImageBitmap(f); const k = Math.min(1, 320 / Math.max(img.width, img.height));
      const cv = document.createElement("canvas"); cv.width = Math.round(img.width * k); cv.height = Math.round(img.height * k);
      cv.getContext("2d")!.drawImage(img, 0, 0, cv.width, cv.height);
      const logo = cv.toDataURL("image/png");
      update((d) => log({ ...d, settings: { ...d.settings, logo } }, "security", "تحديث شعار المحل"));
      toast.success("تم حفظ الشعار");
    } catch { toast.error("الملف ليس صورة صالحة"); }
  };
  return (
    <div className="panel space-y-3">
      <p className="flex items-center gap-2 font-bold"><BadgeCheck className="size-4 text-gold" />شعار المحل على الأوراق</p>
      <p className="text-xs text-muted-foreground">يظهر في رأس كل إيصال سداد وكشف حساب. الصورة تُحفظ داخل الدفتر على هذا الجهاز، فتعمل في الطباعة دون إنترنت.</p>
      <div className="flex items-center gap-3">
        {db.settings.logo ? <img src={db.settings.logo} alt="شعار المحل" className="size-16 rounded-xl border border-border bg-background object-contain" /> : <div className="grid size-16 place-items-center rounded-xl border border-dashed border-border text-xs text-muted-foreground">لا يوجد شعار بعد</div>}
        <label className="btn-ghost cursor-pointer"><ImageUp className="size-4" />اختيار صورة الشعار<input type="file" accept="image/*" hidden onChange={(e) => { void pick(e.target.files?.[0]); e.target.value = ""; }} /></label>
        {db.settings.logo && <button className="chip text-destructive" onClick={() => update((d) => ({ ...d, settings: { ...d.settings, logo: undefined } }))}><Trash2 className="size-4" />إزالة</button>}
      </div>
    </div>
  );
}
