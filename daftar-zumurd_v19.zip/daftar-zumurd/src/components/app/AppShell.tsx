import { useEffect, useRef, useState } from "react";
import { BarChart3, LayoutGrid, Moon, Sun, CalendarDays, DatabaseBackup, Gem, History, Home as HomeIcon, Lock, Receipt, Settings as SettingsIcon, Users, Wallet, Trash2, ScanLine, type LucideIcon } from "lucide-react";
import { Toaster } from "@/components/ui/sonner";
import { toast } from "sonner";
import { loadDisplay, saveDisplay, type Theme } from "@/lib/display";
import { backupDue, can as canDo, saveDB, type Action, type Auth, type DB, type Session } from "@/lib/store";
import { AppCtx, type Tab } from "./ctx";
import { useDailyReminder } from "./extras";
import { Customers, Home, Installments } from "./pages-main";
import { TrashPage, UndoButton, VerifyPage } from "./features";
import { Backups, Expenses, LogPage, Reports, Settings, Treasury } from "./pages-more";

const NEEDS: Partial<Record<Tab, Action>> = { reports: "reports", log: "log", backups: "backups", settings: "settings", trash: "delete" };
const ALL_NAV: { v: Tab; label: string; icon: LucideIcon }[] = [
  { v: "home", label: "الرئيسية", icon: HomeIcon }, { v: "customers", label: "العملاء", icon: Users },
  { v: "installments", label: "الأقساط", icon: CalendarDays }, { v: "treasury", label: "الخزينة", icon: Wallet },
  { v: "expenses", label: "المصروفات", icon: Receipt }, { v: "reports", label: "التقارير", icon: BarChart3 },
  { v: "verify", label: "التحقق من إيصال", icon: ScanLine }, { v: "trash", label: "سلة المحذوفات", icon: Trash2 },
  { v: "log", label: "سجل العمليات", icon: History }, { v: "backups", label: "النسخ الاحتياطي", icon: DatabaseBackup },
  { v: "settings", label: "الإعدادات", icon: SettingsIcon },
];

export function AppShell({ db: initial, auth, session, setAuth, onLock }: { db: DB; auth: Auth; session: Session; setAuth: (a: Auth) => void; onLock: () => void }) {
  const [db, setDb] = useState(initial);
  const [theme, setTheme] = useState<Theme>("dark");
  useEffect(() => { const f = () => setTheme(loadDisplay().theme); f(); window.addEventListener("zumurd-display", f); return () => window.removeEventListener("zumurd-display", f); }, []);
  const can = (a: Action) => canDo(session.role, a);
  const NAV = ALL_NAV.filter((n) => !NEEDS[n.v] || can(NEEDS[n.v]!));
  const [tab, setTab] = useState<Tab>("home");
  const [cust, setCust] = useState<string | undefined>();
  const [more, setMore] = useState(false);
  // Session-only undo stack: the last ten changes, labelled by their log entry.
  const hist = useRef<{ db: DB; label: string }[]>([]);
  const [undoLabel, setUndoLabel] = useState<string | null>(null);
  const undo = () => {
    const h = hist.current.pop(); if (!h) { toast.info("لا يوجد ما يمكن التراجع عنه"); return; }
    saveDB(h.db); setDb(h.db); setUndoLabel(hist.current.at(-1)?.label ?? null);
    toast.success(`تم التراجع عن: ${h.label}`);
  };
  const update = (fn: (d: DB) => DB) => setDb((d) => {
    let n = fn(d);
    if (n !== d && n.log !== d.log && n.log[0]) {
      const label = n.log[0].text;
      if (hist.current.at(-1)?.db !== d) { hist.current.push({ db: d, label }); hist.current = hist.current.slice(-10); }
      setUndoLabel(label);
    }
    // Tag new log entries with the staff member who made them.
    if (session.role === "staff" && n.log !== d.log) {
      const old = new Set(d.log.map((l) => l.id));
      n = { ...n, log: n.log.map((l) => (old.has(l.id) ? l : { ...l, text: `${l.text} — بواسطة ${session.name}` })) };
    }
    saveDB(n); return n;
  });
  // Backup reminder when the owner opens the ledger and a backup is due.
  useEffect(() => {
    if (session.role !== "owner" || !backupDue(db.settings)) return;
    const id = setTimeout(() => toast.warning("حان وقت النسخة الاحتياطية", { description: "احفظها على الجهاز أو أرسلها لنفسك بالواتساب أو البريد.", duration: 10000, action: { label: "نسخ الآن", onClick: () => go("backups") } }), 800);
    return () => clearTimeout(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const go = (t: Tab, id?: string) => {
    setTab(t); setCust(id); window.scrollTo(0, 0);
    // Record each screen so the phone's back button returns to the previous screen instead of leaving the app.
    window.history.pushState({ tab: t, cust: id }, "");
  };
  useEffect(() => {
    window.history.replaceState({ tab: "home" }, "");
    const onPop = (e: PopStateEvent) => { const s = e.state as { tab?: Tab; cust?: string } | null; setTab(s?.tab ?? "home"); setCust(s?.cust); };
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, []);
  useDailyReminder(db, update);
  const setOpenCust = (id?: string) => go("customers", id);

  // Auto-lock after inactivity when the lock is on.
  useEffect(() => {
    const min = db.settings.autoLockMin;
    if (!auth.enabled || !min) return;
    let timer = setTimeout(onLock, min * 60_000);
    const reset = () => { clearTimeout(timer); timer = setTimeout(onLock, min * 60_000); };
    const evs = ["pointerdown", "keydown", "scroll"];
    evs.forEach((e) => window.addEventListener(e, reset, { passive: true }));
    return () => { clearTimeout(timer); evs.forEach((e) => window.removeEventListener(e, reset)); };
  }, [db.settings.autoLockMin, auth.enabled, onLock]);

  const title = ALL_NAV.find((n) => n.v === tab)!.label;
  const page = {
    home: <Home />, customers: <Customers openId={cust} setOpenId={setOpenCust} />, installments: <Installments />,
    treasury: <Treasury />, expenses: <Expenses />, reports: <Reports />, log: <LogPage />, backups: <Backups />, settings: <Settings />, trash: <TrashPage />, verify: <VerifyPage />,
  }[NEEDS[tab] && !can(NEEDS[tab]!) ? "home" : tab];

  return (
    <AppCtx.Provider value={{ db, update, auth, setAuth, lock: onLock, go, session, can, undo, undoLabel }}>
      <div className="min-h-dvh lg:flex">
        <aside className="no-print sticky top-0 hidden h-dvh w-64 shrink-0 flex-col border-l border-sidebar-border bg-sidebar/80 p-3 backdrop-blur lg:flex">
          <Brand shop={db.settings.shop} />
          <nav className="mt-4 space-y-1">
            {NAV.map((n) => <NavBtn key={n.v} n={n} on={tab === n.v} click={() => go(n.v)} />)}
          </nav>
          {auth.enabled && <button onClick={onLock} className="mt-auto flex items-center gap-2 rounded-xl px-3 py-2.5 text-sm text-muted-foreground hover:bg-sidebar-accent"><Lock className="size-4" />قفل الدفتر</button>}
        </aside>
        <div className="min-w-0 flex-1 pb-24 lg:pb-0">
          <header className="no-print sticky top-0 z-20 flex items-center justify-between gap-3 border-b border-border bg-background/70 px-4 py-3 backdrop-blur lg:px-8">
            <div className="min-w-0">
              <h1 className="text-gold-gradient whitespace-nowrap text-[clamp(1rem,5.2vw,1.5rem)] font-bold leading-snug">{title}</h1>
              <p className="text-xs text-muted-foreground">{new Date().toLocaleDateString("ar-EG-u-nu-latn", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}</p>
            </div>
            <div className="flex shrink-0 items-center gap-2">
              {session.role === "staff" && <span className="rounded-xl border border-border bg-muted px-2.5 py-1.5 text-xs text-muted-foreground">موظف: {session.name}</span>}
              <span className={`${session.role === "staff" ? "hidden sm:flex" : "flex"} max-w-[8.5rem] items-center gap-1.5 whitespace-nowrap rounded-xl border border-gold/30 bg-gold/10 px-3 py-1.5 text-xs text-gold`}><Gem className="size-3.5 shrink-0" /><span className="truncate">{db.settings.shop}</span></span>
              <UndoButton />
              <button onClick={() => saveDisplay({ ...loadDisplay(), theme: theme === "dark" ? "light" : "dark" })} aria-label={theme === "dark" ? "الوضع الفاتح" : "الوضع الداكن"} className="chip">{theme === "dark" ? <Sun className="size-4" /> : <Moon className="size-4" />}</button>
              {auth.enabled && <button onClick={onLock} aria-label="قفل الدفتر" className="chip lg:hidden"><Lock className="size-4" /></button>}
            </div>
          </header>
          <main className="mx-auto max-w-5xl p-4 pb-28 lg:p-8 lg:pb-8">{page}</main>
        </div>
        {more && <div className="no-print fixed inset-0 z-30 bg-background/60 backdrop-blur-sm lg:hidden" onClick={() => setMore(false)} />}
        {more && (
          <div className="no-print fixed inset-x-2 bottom-20 z-40 grid grid-cols-3 gap-2 rounded-2xl border border-border bg-sidebar p-3 shadow-lg lg:hidden" style={{ marginBottom: "env(safe-area-inset-bottom)" }}>
            {NAV.slice(4).map(({ v, label, icon: Icon }) => (
              <button key={v} onClick={() => { setMore(false); go(v); }} className={`flex flex-col items-center gap-1.5 rounded-xl px-2 py-3 text-xs ${tab === v ? "bg-sidebar-accent text-sidebar-accent-foreground" : "text-muted-foreground"}`}>
                <Icon className="size-5" />{label}
              </button>
            ))}
          </div>
        )}
        <nav className="no-print fixed inset-x-0 bottom-0 z-40 grid grid-cols-5 gap-1 border-t border-border bg-sidebar/95 px-2 py-2 backdrop-blur lg:hidden" style={{ paddingBottom: "max(0.5rem, env(safe-area-inset-bottom))" }}>
          {NAV.slice(0, 4).map(({ v, label, icon: Icon }) => (
            <button key={v} onClick={() => { setMore(false); go(v); }} className={`flex flex-col items-center gap-1 rounded-xl px-1 py-1.5 text-[11px] ${tab === v && !more ? "bg-sidebar-accent text-sidebar-accent-foreground" : "text-muted-foreground"}`}>
              <Icon className="size-5" />{label}
            </button>
          ))}
          <button onClick={() => setMore((m) => !m)} aria-expanded={more} className={`flex flex-col items-center gap-1 rounded-xl px-1 py-1.5 text-[11px] ${more || NAV.slice(4).some((n) => n.v === tab) ? "bg-sidebar-accent text-sidebar-accent-foreground" : "text-muted-foreground"}`}>
            <LayoutGrid className="size-5" />المزيد
          </button>
        </nav>
      </div>
      <Toaster position="bottom-center" dir="rtl" theme={theme} richColors mobileOffset={{ bottom: "calc(5.5rem + env(safe-area-inset-bottom))" }} />
    </AppCtx.Provider>
  );
}

function Brand({ shop }: { shop: string }) {
  return (
    <div className="flex items-center gap-3 px-1 py-2">
      <div className="grid size-11 place-items-center rounded-xl border border-gold/30 bg-hero text-gold"><Gem className="size-5" /></div>
      <div className="min-w-0"><p className="truncate font-bold">{shop}</p><p className="text-xs text-muted-foreground">دفتر الأقساط</p></div>
    </div>
  );
}

function NavBtn({ n: { label, icon: Icon }, on, click }: { n: (typeof ALL_NAV)[number]; on: boolean; click: () => void }) {
  return (
    <button onClick={click} className={`flex w-full items-center gap-3 rounded-xl border px-3 py-2.5 text-sm transition ${on ? "border-primary/30 bg-sidebar-accent text-sidebar-accent-foreground" : "border-transparent text-sidebar-foreground hover:bg-sidebar-accent/50"}`}>
      <Icon className="size-4" />{label}
    </button>
  );
}
