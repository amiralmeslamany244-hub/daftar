import { useState } from "react";
import { DateField } from "./fields";
import { toast } from "sonner";
import {
  Archive, ArchiveRestore, ArrowLeft, CalendarClock, CalendarDays, ChevronLeft, FileText, HandCoins, MapPin,
  MessageCircle, Pencil, Phone, Plus, Printer, ReceiptText, Share2, Trash2, WalletCards, Scale, UserX,
} from "lucide-react";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { loadDisplay } from "@/lib/display";
import {
  cur, dateAr, fmt, log, paidFor, trashCustomer, trashPayment, trashPlan, planCredit, planRemaining, planRows, todayISO, whatsappLink,
  type Customer, type DB, type InstRow, type Plan,
} from "@/lib/store";
import { openExternal } from "@/lib/utils";
import { useApp } from "./ctx";
import { CustomerDialog, PaymentDialog, PlanDialog } from "./dialogs";
import { DocsPanel, RatingBadge, esc, printHtml, printThermal, receiptFor } from "./extras";
import { Empty } from "./ui";
import { CreditDialog, DelayPanel, PostponeDialog } from "./features";

const DAY = 86_400_000;
const daysBetween = (a: string, b: string) => Math.round((new Date(b + "T00:00:00").getTime() - new Date(a + "T00:00:00").getTime()) / DAY);

function StatusBadge({ r, today }: { r: InstRow; today: string }) {
  const d = daysBetween(today, r.due);
  const [label, cls] =
    r.status === "paid" ? ["مسدّد", "border-success/40 bg-success/15 text-success"]
    : r.status === "today" ? ["مستحق اليوم", "border-warning/40 bg-warning/15 text-warning"]
    : r.status === "overdue" ? [`متأخر ${-d} يوم`, "border-destructive/40 bg-destructive/15 text-destructive"]
    : [`بعد ${d} يوم`, "border-info/40 bg-info/15 text-info"];
  return <span className={`rounded-lg border px-2 py-0.5 text-xs font-semibold ${cls}`}>{label}</span>;
}

function MiniStat({ label, v, sym, tone }: { label: string; v: number; sym: string; tone: string }) {
  return (
    <div className="min-w-0 rounded-xl border border-border bg-background/50 px-1.5 py-3 text-center">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p dir="ltr" className={`mt-1 break-all text-[clamp(0.8rem,3.6vw,1rem)] font-bold leading-tight tabular-nums ${tone}`}>{fmt(v)}</p>
      <p className={`text-xs ${tone}`}>{sym}</p>
    </div>
  );
}

function IconBtn({ label, onClick, tone = "", children }: { label: string; onClick: () => void; tone?: string; children: React.ReactNode }) {
  return (
    <button aria-label={label} title={label} onClick={onClick}
      className={`grid size-11 shrink-0 place-items-center rounded-xl border border-border bg-card/70 text-foreground transition active:scale-95 ${tone}`}>
      {children}
    </button>
  );
}

function statementHtml(db: DB, c: Customer) {
  const sym = cur(db.settings).sym;
  const plans = db.plans.filter((p) => p.customerId === c.id);
  const body = plans.map((p) => {
    const rows = planRows(db, p.id).map((r) => `<tr><td>${r.n}</td><td>${esc(dateAr(r.due))}</td><td>${fmt(r.amount)}</td><td>${fmt(r.paid)}</td><td>${fmt(r.left)}</td></tr>`).join("");
    const pays = db.payments.filter((x) => x.planId === p.id).sort((a, b) => a.date.localeCompare(b.date))
      .map((x) => `<tr><td>${esc(dateAr(x.date))}</td><td>${fmt(x.amount)}</td><td>${esc(x.note || "قسط")}</td></tr>`).join("");
    return `<h2>${esc(p.item)}</h2><p class="m">الإجمالي ${fmt(p.total)} ${esc(sym)} · المقدم ${fmt(p.down)} · المدفوع ${fmt(paidFor(db, p.id))} · المتبقي ${fmt(planRemaining(db, p))}</p>
<table><thead><tr><th>#</th><th>الاستحقاق</th><th>القيمة</th><th>المدفوع</th><th>المتبقي</th></tr></thead><tbody>${rows}</tbody></table>
${pays ? `<h3>المدفوعات</h3><table><thead><tr><th>التاريخ</th><th>المبلغ</th><th>البيان</th></tr></thead><tbody>${pays}</tbody></table>` : ""}`;
  }).join("");
  return `<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><title>كشف حساب ${esc(c.name)}</title><style>
@page{size:A4;margin:14mm}body{font-family:"IBM Plex Sans Arabic",Tahoma,sans-serif;color:#000;font-size:13px}
h1{margin:0;font-size:20px}h2{margin:18px 0 4px;font-size:16px}h3{font-size:14px;margin:10px 0 4px}.m{margin:0 0 6px;color:#444}
table{width:100%;border-collapse:collapse}th,td{border:1px solid #bbb;padding:4px 6px;text-align:right}th{background:#eee}</style></head><body>
${db.settings.logo ? `<img src="${db.settings.logo}" style="max-height:60px;float:left">` : ""}<h1>${esc(db.settings.shop)} — كشف حساب</h1><p class="m">العميل: ${esc(c.name)} · ${esc(c.phone)} · ${esc(dateAr(todayISO()))}</p>${body || "<p>لا توجد خطط</p>"}</body></html>`;
}

async function statementImage(db: DB, c: Customer): Promise<Blob> {
  await document.fonts?.ready;
  const sym = cur(db.settings).sym;
  const plans = db.plans.filter((p) => p.customerId === c.id);
  const W = 900, rowH = 44;
  const blocks = plans.map((p) => ({ p, rows: planRows(db, p.id) }));
  const H = 330 + blocks.reduce((s, b) => s + 190 + b.rows.length * rowH, 0) + 110;
  const cv = document.createElement("canvas"); cv.width = W; cv.height = H;
  const g = cv.getContext("2d")!;
  const font = (w: number, z: number) => `${w} ${z}px "IBM Plex Sans Arabic", sans-serif`;
  const C = { bg: "#0c1f19", gold: "#c9a24a", fg: "#e8f0ec", mut: "#8fa89c", line: "#2a4a3e", ok: "#5fd39a", warn: "#e6b85c", bad: "#ef7a6b", card: "#123528" };
  g.fillStyle = C.bg; g.fillRect(0, 0, W, H);
  g.strokeStyle = C.gold; g.lineWidth = 3; g.strokeRect(20, 20, W - 40, H - 40);
  g.direction = "rtl"; g.textAlign = "center";
  g.fillStyle = C.gold; g.font = font(700, 42); g.fillText(db.settings.shop, W / 2, 95);
  g.fillStyle = C.fg; g.font = font(600, 30); g.fillText("كشف حساب عميل", W / 2, 145);
  g.fillStyle = C.mut; g.font = font(400, 22); g.fillText(`${c.name}${c.phone ? " · " + c.phone : ""} · ${dateAr(todayISO())}`, W / 2, 185);
  const left = plans.reduce((s, p) => s + planRemaining(db, p), 0);
  const paid = plans.reduce((s, p) => s + paidFor(db, p.id) + p.down, 0);
  const box = (x: number, label: string, v: number, col: string) => {
    g.fillStyle = C.card; g.fillRect(x, 210, 240, 90);
    g.textAlign = "center"; g.fillStyle = C.mut; g.font = font(400, 20); g.fillText(label, x + 120, 245);
    g.fillStyle = col; g.font = font(700, 28); g.fillText(`${fmt(v)} ${sym}`, x + 120, 283);
  };
  box(W - 60 - 240, "المتبقي", left, C.warn); box(W / 2 - 120, "إجمالي المدفوع", paid, C.ok);
  g.fillStyle = C.card; g.fillRect(60, 210, 240, 90);
  g.fillStyle = C.mut; g.font = font(400, 20); g.fillText("عدد الخطط", 180, 245); g.fillStyle = C.fg; g.font = font(700, 28); g.fillText(String(plans.length), 180, 283);
  let y = 340;
  const cols = [W - 60, W - 140, W - 380, W - 560, 170];
  for (const { p, rows } of blocks) {
    g.textAlign = "right"; g.fillStyle = C.gold; g.font = font(700, 28); g.fillText(p.item, W - 60, y + 30);
    g.fillStyle = C.mut; g.font = font(400, 19);
    g.fillText(`الإجمالي ${fmt(p.total)} · المقدم ${fmt(p.down)} · المدفوع ${fmt(paidFor(db, p.id))} · المتبقي ${fmt(planRemaining(db, p))} ${sym}`, W - 60, y + 65);
    y += 90;
    g.fillStyle = C.card; g.fillRect(50, y, W - 100, rowH);
    g.fillStyle = C.mut; g.font = font(600, 19);
    ["#", "الاستحقاق", "القيمة", "المدفوع", "الحالة"].forEach((t, i) => g.fillText(t, cols[i]!, y + 29));
    y += rowH;
    for (const r of rows) {
      g.font = font(400, 20); g.fillStyle = C.fg;
      g.fillText(String(r.n), cols[0]!, y + 29); g.fillText(dateAr(r.due), cols[1]!, y + 29);
      g.fillText(fmt(r.amount), cols[2]!, y + 29); g.fillStyle = C.ok; g.fillText(fmt(r.paid), cols[3]!, y + 29);
      const st = r.status === "paid" ? ["مسدّد", C.ok] : r.status === "overdue" ? ["متأخر", C.bad] : r.status === "today" ? ["اليوم", C.warn] : ["قادم", C.mut];
      g.fillStyle = st[1]!; g.fillText(st[0]!, cols[4]!, y + 29);
      g.strokeStyle = C.line; g.lineWidth = 1; g.beginPath(); g.moveTo(50, y + rowH); g.lineTo(W - 50, y + rowH); g.stroke();
      y += rowH;
    }
    y += 56;
  }
  g.textAlign = "center"; g.fillStyle = C.mut; g.font = font(400, 20); g.fillText("صادر من دفتر زمرد", W / 2, H - 50);
  return new Promise((res) => cv.toBlob((b) => res(b!), "image/png"));
}

async function shareStatement(db: DB, c: Customer) {
  const blob = await statementImage(db, c);
  const name = `كشف-حساب-${c.name}.png`;
  const file = new File([blob], name, { type: "image/png" });
  const sym = cur(db.settings).sym;
  const left = db.plans.filter((p) => p.customerId === c.id).reduce((s, p) => s + planRemaining(db, p), 0);
  const text = `كشف حساب ${c.name} من ${db.settings.shop} — المتبقي ${fmt(left)} ${sym}.`;
  if (navigator.canShare?.({ files: [file] })) {
    try { await navigator.share({ files: [file], text }); return; } catch (e) { if ((e as Error).name === "AbortError") return; }
  }
  const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 60_000);
  if (c.phone) setTimeout(() => openExternal(whatsappLink(c.phone, text, cur(db.settings).cc)), 300);
  toast.info("تم حفظ صورة الكشف — أرفقها في محادثة الواتساب");
}

export function CustomerDetail({ id, back }: { id: string; back: () => void }) {
  const { db, update, can } = useApp();
  const c = db.customers.find((x) => x.id === id)!;
  const plans = db.plans.filter((p) => p.customerId === id);
  const [dlg, setDlg] = useState<"" | "edit" | "plan">("");
  const [pay, setPay] = useState<{ plan: Plan; amount?: number } | null>(null);
  const [resched, setResched] = useState<InstRow | null>(null);
  const [creditDlg, setCreditDlg] = useState(false);
  const [open, setOpen] = useState<string | null>(null);
  const cc = cur(db.settings);
  const today = todayISO();

  const left = plans.reduce((s, p) => s + planRemaining(db, p), 0);
  const paid = plans.reduce((s, p) => s + paidFor(db, p.id) + p.down, 0);
  const credit = plans.reduce((s, p) => s + planCredit(db, p), 0);
  const openPlan = plans.find((p) => planRemaining(db, p) > 0);

  const archive = () => {
    if (!confirm(c.archived ? `استعادة العميل ${c.name}؟` : `أرشفة العميل ${c.name}؟`)) return;
    update((d) => log({ ...d, customers: d.customers.map((x) => (x.id === id ? { ...x, archived: !x.archived } : x)) }, "customer", `${c.archived ? "استعادة" : "أرشفة"} العميل ${c.name}`));
    toast.success(c.archived ? "تمت استعادة العميل" : "تمت أرشفة العميل");
  };
  const delPlan = (p: Plan) => {
    if (!confirm(`حذف خطة "${p.item}"؟ ستُنقل الخطة وأقساطها إلى سلة المحذوفات، ويمكن استعادتها من هناك.`)) return;
    update((d) => trashPlan(d, p.id)); toast.success("نُقلت الخطة إلى سلة المحذوفات");
  };
  const delPay = (pid: string, amount: number) => {
    if (!confirm(`سيتم حذف هذه الدفعة (${fmt(amount)} ${cc.sym}) وإعادة المبلغ إلى المتبقي على القسط. يمكن استعادتها من سلة المحذوفات.`)) return;
    update((d) => trashPayment(d, pid));
    toast.success("نُقلت الدفعة إلى سلة المحذوفات");
  };
  const delCustomer = () => {
    if (!confirm(`حذف العميل ${c.name}؟ سينتقل العميل وخططه وأقساطه إلى سلة المحذوفات، ويمكن استعادته من هناك.`)) return;
    update((d) => trashCustomer(d, id)); toast.success("نُقل العميل إلى سلة المحذوفات"); back();
  };
  const remind = (p: Plan, r?: InstRow) => {
    const msg = r
      ? `مرحبًا ${c.name}، تذكير من ${db.settings.shop}: القسط رقم ${r.n} عن "${p.item}" بقيمة ${fmt(r.left)} ${cc.sym} مستحق بتاريخ ${dateAr(r.due)}. شكرًا لك.`
      : `مرحبًا ${c.name}، تذكير من ${db.settings.shop}: المتبقي ${fmt(planRemaining(db, p))} ${cc.sym} عن "${p.item}". شكرًا لك.`;
    openExternal(whatsappLink(c.phone, msg, cc.cc));
  };

  type LogRow = { key: string; plan: Plan; amount: number; date: string; note: string; down: boolean; pid?: string; method?: string | undefined; credit?: boolean };
  const payLog: LogRow[] = plans.flatMap((p) => [
    ...(p.down > 0 ? [{ key: p.id + "-down", plan: p, amount: p.down, date: p.createdAt.slice(0, 10), note: "دفعة مقدمة عند التعاقد", down: true }] : []),
    ...db.payments.filter((x) => x.planId === p.id).map((x) => ({ key: x.id, plan: p, amount: x.amount, date: x.date, note: x.note, down: false, pid: x.id, method: x.method, credit: x.kind === "credit" })),
  ]).sort((a, b) => b.date.localeCompare(a.date));

  return (
    <div className="space-y-4">
      <button className="flex items-center gap-1 text-sm text-muted-foreground" onClick={back}><ArrowLeft className="size-4 rotate-180" />كل العملاء</button>

      {/* بطاقة العميل */}
      <div className="panel space-y-4">
        <div className="flex items-start gap-3">
          <div className="grid size-14 shrink-0 place-items-center rounded-2xl border border-primary/30 bg-primary/15 text-xl font-bold text-primary">{c.name.slice(0, 1)}</div>
          <div className="min-w-0 flex-1">
            <p className="flex flex-wrap items-center gap-2 text-xl font-bold">
              <span className="break-words">{c.name}</span><RatingBadge id={c.id} />
              {c.archived && <span className="rounded-lg bg-muted px-2 text-xs text-muted-foreground">مؤرشف</span>}
            </p>
            <div className="mt-1 flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted-foreground">
              {c.phone && <a href={`tel:${c.phone}`} className="flex items-center gap-1"><Phone className="size-3.5" /><span dir="ltr">{c.phone}</span></a>}
              {c.address && <span className="flex items-center gap-1"><MapPin className="size-3.5" />{c.address}</span>}
            </div>
            {c.notes && <p className="mt-1 text-xs text-muted-foreground">{c.notes}</p>}
          </div>
        </div>
        <div className="grid grid-cols-3 gap-2">
          <MiniStat label="المتبقي" v={left} sym={cc.sym} tone="text-warning" />
          <MiniStat label="إجمالي المدفوع" v={paid} sym={cc.sym} tone="text-success" />
          <MiniStat label="رصيد دائن" v={credit} sym={cc.sym} tone="text-info" />
        </div>
        <div className="grid grid-cols-2 gap-2">
          {!c.archived && <button className="btn" onClick={() => setDlg("plan")}><Plus className="size-4" />خطة أقساط</button>}
          <button className="btn-ghost" onClick={() => void shareStatement(db, c)}><Share2 className="size-4" />كشف حساب</button>
        </div>
        <div className="flex gap-2">
          <IconBtn label="طباعة كشف الحساب" onClick={() => printHtml(statementHtml(db, c))}><FileText className="size-4" /></IconBtn>
          <button className="btn-ghost flex-1" disabled={!openPlan} onClick={() => openPlan && setPay({ plan: openPlan })}><WalletCards className="size-4" />دفعة مقدمة</button>
          <IconBtn label="تعديل العميل" onClick={() => setDlg("edit")}><Pencil className="size-4" /></IconBtn>
          {can("archive") && <IconBtn label={c.archived ? "استعادة" : "أرشفة"} onClick={archive}>{c.archived ? <ArchiveRestore className="size-4" /> : <Archive className="size-4" />}</IconBtn>}
          {can("delete") && <IconBtn label="حذف العميل" onClick={delCustomer} tone="text-destructive"><UserX className="size-4" /></IconBtn>}
        </div>
      </div>

      {credit > 0 && plans.some((p) => planRemaining(db, p) > 0) && <button className="btn-ghost w-full" onClick={() => setCreditDlg(true)}><Scale className="size-4" />تسوية رصيد دائن ({fmt(credit)} {cc.sym})</button>}
      <DelayPanel id={id} />
      <DocsPanel c={c} />

      {plans.length === 0 && <div className="panel"><Empty icon={CalendarDays} title="لا توجد خطط لهذا العميل" sub="أنشئ خطة وسيُولَّد جدول الأقساط تلقائيًا." /></div>}

      {/* خطط الأقساط */}
      {plans.map((p) => {
        const rows = planRows(db, p.id, today);
        const financed = Math.max(0, p.total - p.down);
        const got = Math.min(financed, paidFor(db, p.id));
        const pct = financed > 0 ? Math.round((got / financed) * 100) : 100;
        const months = Math.round((p.count * p.everyDays) / 30);
        return (
          <div key={p.id} className="overflow-hidden rounded-2xl border border-border bg-card/70">
            <div className="flex items-start justify-between gap-2 p-4">
              <div className="min-w-0">
                <h3 className="truncate text-lg font-bold">{p.item}</h3>
                <p className="text-xs text-muted-foreground">{dateAr(p.start)} · {p.count} {p.everyDays >= 28 ? `قسط (${months} شهر)` : "قسط"} · إجمالي {fmt(p.total)} {cc.sym}</p>
              </div>
              <div className="flex shrink-0 gap-2">
                {c.phone && planRemaining(db, p) > 0 && <IconBtn label="تذكير واتساب" onClick={() => remind(p)} tone="text-success"><MessageCircle className="size-4" /></IconBtn>}
                {can("delete") && <IconBtn label="حذف الخطة" onClick={() => delPlan(p)} tone="text-destructive"><Trash2 className="size-4" /></IconBtn>}
              </div>
            </div>
            <div className="border-y border-border bg-background/40 px-4 py-3">
              <div className="mb-2 flex items-center justify-between text-xs">
                <span className="text-muted-foreground">مسدود <b className="text-foreground tabular-nums">{fmt(got)}</b> {cc.sym} من <b className="text-foreground tabular-nums">{fmt(financed)}</b> {cc.sym}</span>
                <span className="font-bold text-success">{pct}%</span>
              </div>
              <div className="h-2 overflow-hidden rounded-full bg-muted">
                <div className="h-full rounded-full bg-gradient-to-l from-success to-warning transition-all" style={{ width: `${pct}%` }} />
              </div>
            </div>
            <div className="space-y-2 p-3">
              {rows.map((r) => {
                const isOpen = open === r.id;
                return (
                  <div key={r.id} className={`rounded-xl border p-3 ${r.status === "overdue" ? "border-destructive/40 bg-destructive/5" : r.status === "today" ? "border-warning/40 bg-warning/5" : "border-border bg-background/40"}`}>
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-muted-foreground">القسط {r.n}</span>
                      <StatusBadge r={r} today={today} />
                    </div>
                    <p className="mt-1.5 flex flex-wrap items-center gap-x-3 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1"><CalendarDays className="size-3.5" />{dateAr(r.due)}</span>
                      <span>القيمة: {fmt(r.amount)} {cc.sym}</span>
                      {(r.history ?? []).length > 0 && <span className="text-info">مؤجَّل من {dateAr(r.history![0]!.from)}</span>}
                    </p>
                    <div className="mt-2 flex items-end justify-between gap-2">
                      <div>
                        <p className="text-xs text-muted-foreground">المتبقي</p>
                        <p className={`text-lg font-bold tabular-nums ${r.left > 0 ? "text-warning" : "text-success"}`}>{fmt(r.left)} {cc.sym}</p>
                      </div>
                      <div className="flex gap-2">
                        {r.left > 0 && <IconBtn label="تسجيل دفعة" onClick={() => setPay({ plan: p, amount: r.left })} tone="border-success/40 bg-success/15 text-success"><HandCoins className="size-4" /></IconBtn>}
                        {r.left > 0 && <IconBtn label="تأجيل القسط" onClick={() => setResched(r)}><CalendarClock className="size-4" /></IconBtn>}
                        <IconBtn label="تفاصيل" onClick={() => setOpen(isOpen ? null : r.id)}><ChevronLeft className={`size-4 transition ${isOpen ? "-rotate-90" : ""}`} /></IconBtn>
                      </div>
                    </div>
                    {isOpen && (
                      <div className="mt-3 grid grid-cols-3 gap-2 border-t border-border pt-3 text-center text-xs">
                        <div><p className="text-muted-foreground">القيمة</p><p className="font-semibold">{fmt(r.amount)}</p></div>
                        <div><p className="text-muted-foreground">المدفوع</p><p className="font-semibold text-success">{fmt(r.paid)}</p></div>
                        <div><p className="text-muted-foreground">المتبقي</p><p className="font-semibold text-warning">{fmt(r.left)}</p></div>
                        {c.phone && r.left > 0 && <button className="chip col-span-3 justify-center" onClick={() => remind(p, r)}><MessageCircle className="size-4" />تذكير بهذا القسط</button>}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        );
      })}

      {/* سجل المدفوعات */}
      {payLog.length > 0 && (
        <div className="overflow-hidden rounded-2xl border border-border bg-card/70">
          <div className="flex items-center gap-2 border-b border-border px-4 py-3 font-bold">
            <ReceiptText className="size-4 text-success" />سجل المدفوعات
            <span className="rounded-full bg-muted px-2 text-xs font-normal text-muted-foreground">{payLog.length}</span>
          </div>
          <div className="divide-y divide-border">
            {payLog.map((x) => (
              <div key={x.key} className="flex items-center gap-3 px-4 py-3">
                <div className="min-w-0 flex-1">
                  <p className="flex flex-wrap items-center gap-2">
                    <b className="text-lg tabular-nums text-success">{fmt(x.amount)} {cc.sym}</b>
                    <span className="rounded-lg border border-success/30 bg-success/10 px-2 py-0.5 text-xs text-success">{x.down ? "مقدم تعاقد" : x.credit ? "تسوية" : "قسط"}</span>
                  </p>
                  <p className="text-xs text-muted-foreground">{dateAr(x.date)} · {x.method === "bank" ? "تحويل بنكي" : x.method === "wallet" ? "محفظة إلكترونية" : "نقدًا"}{x.note ? ` · ${x.note}` : ""}{plans.length > 1 ? ` · ${x.plan.item}` : ""}</p>
                </div>
                <IconBtn label="طباعة إيصال" onClick={() => void printThermal(receiptFor(db, x.plan, x.amount, x.date, x.pid), loadDisplay().paper)} tone="border-success/40 bg-success/10 text-success"><Printer className="size-4" /></IconBtn>
                {!x.down && x.pid && can("delete") && <IconBtn label="حذف الدفعة" onClick={() => delPay(x.pid!, x.amount)} tone="text-destructive"><Trash2 className="size-4" /></IconBtn>}
              </div>
            ))}
          </div>
        </div>
      )}

      {dlg === "edit" && <CustomerDialog open edit={c} onClose={() => setDlg("")} />}
      {dlg === "plan" && <PlanDialog open customerId={id} onClose={() => setDlg("")} />}
      {pay && <PaymentDialog open plan={pay.plan} {...(pay.amount !== undefined ? { suggest: pay.amount } : {})} onClose={() => setPay(null)} />}
      {resched && <PostponeDialog row={resched} onClose={() => setResched(null)} />}
      {creditDlg && <CreditDialog plans={plans} onClose={() => setCreditDlg(false)} />}
    </div>
  );
}
