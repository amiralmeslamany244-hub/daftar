import { createContext, useContext } from "react";
import type { Action, Auth, DB, Session } from "@/lib/store";

export type Ctx = {
  db: DB;
  update: (fn: (d: DB) => DB) => void;
  auth: Auth;
  setAuth: (a: Auth) => void;
  lock: () => void;
  go: (tab: Tab, customerId?: string) => void;
  session: Session;
  can: (a: Action) => boolean;
  undo: () => void;
  undoLabel: string | null;
};
export type Tab = "home" | "customers" | "installments" | "treasury" | "expenses" | "reports" | "log" | "backups" | "settings" | "trash" | "verify";
export const AppCtx = createContext<Ctx | null>(null);
export const useApp = () => {
  const c = useContext(AppCtx);
  if (!c) throw new Error("AppCtx missing");
  return c;
};
