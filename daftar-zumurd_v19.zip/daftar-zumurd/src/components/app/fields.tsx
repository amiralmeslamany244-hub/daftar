import { useState } from "react";
import * as SelectPrimitive from "@radix-ui/react-select";
import { arEG } from "date-fns/locale";
import { CalendarDays, Check, ChevronDown } from "lucide-react";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { todayISO } from "@/lib/store";

const LOC = "ar-EG-u-nu-latn";
/** "YYYY-MM-DD" -> local Date (no timezone shift). */
export const isoToDate = (iso: string) => {
  const [y, m, d] = iso.slice(0, 10).split("-").map(Number);
  return y && m && d ? new Date(y, m - 1, d) : undefined;
};

/** Premium date picker. Same value contract as <input type="date">: "YYYY-MM-DD". */
export function DateField({ value, onChange, ariaLabel }: { value: string; onChange: (iso: string) => void; ariaLabel?: string }) {
  const [open, setOpen] = useState(false);
  const sel = isoToDate(value);
  const pick = (iso: string) => { onChange(iso); setOpen(false); };
  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button type="button" aria-label={ariaLabel ?? "اختيار التاريخ"} className="field picker-trigger">
          <span className="picker-icon"><CalendarDays className="size-4" /></span>
          <span className="flex min-w-0 flex-1 flex-col items-start leading-tight">
            {sel ? <>
              <span className="truncate font-bold">{sel.toLocaleDateString(LOC, { day: "numeric", month: "long", year: "numeric" })}</span>
              <span className="text-xs text-muted-foreground">{sel.toLocaleDateString(LOC, { weekday: "long" })}</span>
            </> : <span className="text-muted-foreground">اختر التاريخ</span>}
          </span>
          <ChevronDown className={cn("size-4 shrink-0 text-gold transition-transform", open && "rotate-180")} />
        </button>
      </PopoverTrigger>
      <PopoverContent dir="rtl" align="start" sideOffset={6} className="picker-pop w-auto p-0">
        <Calendar
          mode="single"
          dir="rtl"
          locale={arEG}
          weekStartsOn={6}
          selected={sel}
          defaultMonth={sel ?? new Date()}
          onSelect={(d) => d && pick(todayISO(d))}
          className="[--cell-size:2.6rem] bg-transparent"
          formatters={{
            formatCaption: (d) => d.toLocaleDateString(LOC, { month: "long", year: "numeric" }),
            formatDay: (d) => String(d.getDate()),
            formatWeekdayName: (d) => d.toLocaleDateString(LOC, { weekday: "short" }).replace(/^ال/, ""),
          }}
          classNames={{
            caption_label: "select-none text-base font-bold text-gold",
            weekday: "flex-1 select-none text-[0.7rem] font-semibold text-muted-foreground",
            today: "rounded-lg ring-1 ring-gold/60 text-gold",
          }}
        />
        <div className="flex gap-2 border-t border-border/60 p-2">
          <button type="button" className="btn-ghost flex-1 min-h-9 text-sm" onClick={() => pick(todayISO())}>اليوم</button>
          <button type="button" className="btn-ghost flex-1 min-h-9 text-sm" onClick={() => { const t = new Date(); t.setDate(t.getDate() + 1); pick(todayISO(t)); }}>غدًا</button>
        </div>
      </PopoverContent>
    </Popover>
  );
}

export type Opt = { value: string; label: string };
/** Premium dropdown. value/onChange use plain strings like a native <select>. */
export function SelectField({ value, onChange, options, disabled, className, ariaLabel }: {
  value: string; onChange: (v: string) => void; options: Opt[]; disabled?: boolean; className?: string; ariaLabel?: string;
}) {
  return (
    <SelectPrimitive.Root dir="rtl" value={value} onValueChange={onChange} disabled={!!disabled}>
      <SelectPrimitive.Trigger aria-label={ariaLabel} className={cn("field picker-trigger group", className)}>
        <span className="min-w-0 flex-1 truncate text-right"><SelectPrimitive.Value placeholder="اختر" /></span>
        <SelectPrimitive.Icon asChild>
          <ChevronDown className="size-4 shrink-0 text-gold transition-transform group-data-[state=open]:rotate-180" />
        </SelectPrimitive.Icon>
      </SelectPrimitive.Trigger>
      <SelectPrimitive.Portal>
        <SelectPrimitive.Content position="popper" sideOffset={6} className="picker-pop z-50 max-h-(--radix-select-content-available-height) min-w-(--radix-select-trigger-width) overflow-hidden">
          <SelectPrimitive.Viewport className="max-h-72 p-1.5">
            {options.map((o) => (
              <SelectPrimitive.Item key={o.value} value={o.value} className="picker-item">
                <SelectPrimitive.ItemText>{o.label}</SelectPrimitive.ItemText>
                <SelectPrimitive.ItemIndicator className="ms-auto"><Check className="size-4 text-gold" /></SelectPrimitive.ItemIndicator>
              </SelectPrimitive.Item>
            ))}
          </SelectPrimitive.Viewport>
        </SelectPrimitive.Content>
      </SelectPrimitive.Portal>
    </SelectPrimitive.Root>
  );
}
