import { useEffect, useState, type ReactNode } from "react";
import { Check, Delete, Eye, EyeOff, Fingerprint, Gem, KeyRound, LockKeyhole } from "lucide-react";
import { emptyDB, hasAnyPin, hash, log, matchLogin, matchPin, oldShopName, saveAuth, saveDB, type Auth, type DB, type Session } from "@/lib/store";
import { bioSupported, bioVerify } from "@/lib/biometric";
import { L } from "@/components/app/ui";

export function Setup({ onDone }: { onDone: (a: Auth, d: DB) => void }) {
  const [f, setF] = useState({ shop: oldShopName() ?? "", user: "", pass: "", pass2: "", rec: "" });
  const [show, setShow] = useState(false);
  const [err, setErr] = useState("");
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });
  const ok = f.user.trim() && f.pass.length >= 4 && f.rec.trim().length >= 4 && f.pass === f.pass2;
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (f.pass !== f.pass2) return setErr("كلمتا المرور غير متطابقتين");
    if (!ok) return setErr("أكمل الحقول (كلمة المرور وكلمة الاسترداد 4 أحرف على الأقل)");
    const a: Auth = { user: f.user.trim(), pass: await hash(f.pass), recovery: await hash(f.rec), enabled: true };
    const d = log(emptyDB(f.shop.trim() || "دفتر زمرد"), "security", "تفعيل الدخول المحلي وقفل التطبيق");
    saveAuth(a); saveDB(d); onDone(a, d);
  };
  const t = show ? "text" : "password";
  return (
    <Shell title="أنشئ دفترك لأول مرة" sub="عيّن اسم مستخدم وكلمة مرور خاصة بهذا الجهاز. لا يوجد حساب خارجي ولا دخول بجوجل — القفل محلي بالكامل."
      foot="احفظ كلمة الاسترداد في مكان آمن — لا يمكن استعادة الدفتر بدونها.">
      <form onSubmit={submit} className="space-y-4">
        <L t="اسم المحل / الدفتر" hint="يظهر في شاشة القفل وأعلى التطبيق"><input className="field" placeholder="دفتر زمرد" value={f.shop} onChange={set("shop")} /></L>
        <L t="اسم المستخدم"><input className="field" placeholder="مثال: owner" value={f.user} onChange={set("user")} autoComplete="username" /></L>
        <div className="grid grid-cols-2 gap-3">
          <L t="كلمة المرور"><input type={t} className="field" placeholder="4 أحرف على الأقل" value={f.pass} onChange={set("pass")} autoComplete="new-password" /></L>
          <L t="تأكيد كلمة المرور"><input type={t} className="field" placeholder="••••••" value={f.pass2} onChange={set("pass2")} autoComplete="new-password" /></L>
        </div>
        <L t="كلمة الاسترداد" hint="كلمة تتذكرها (اسم، مدينة، رقم) — بها وحدها يمكنك فتح الدفتر إذا نسيت كلمة المرور">
          <input type={t} className="field" placeholder="4 أحرف على الأقل" value={f.rec} onChange={set("rec")} />
        </L>
        <ShowToggle show={show} setShow={setShow} />
        {err && <p className="text-sm text-destructive">{err}</p>}
        <button className="btn w-full" disabled={!ok}><KeyRound className="size-4" />إنشاء الدفتر وفتحه</button>
      </form>
    </Shell>
  );
}

export function Lock({ auth, shop, onOpen }: { auth: Auth; shop: string; onOpen: (a: Auth, s: Session) => void }) {
  const [mode, setMode] = useState<"pin" | "login" | "recover">(hasAnyPin(auth) ? "pin" : "login");
  const [u, setU] = useState(""); const [p, setP] = useState(""); const [np, setNp] = useState("");
  const [show, setShow] = useState(false);
  const [err, setErr] = useState("");
  const [wait, setWait] = useState(0);
  const [fails, setFails] = useState(0);
  const [bio, setBio] = useState(false);
  useEffect(() => { if (auth.bio) bioSupported().then(setBio); }, [auth.bio]);
  const fail = (m: string) => {
    const n = fails + 1; setFails(n); setErr(m);
    if (n >= 5) { setWait(Date.now() + 60_000); setFails(0); setErr("محاولات كثيرة — انتظر دقيقة ثم حاول مجددًا"); }
  };
  const blocked = () => { if (Date.now() < wait) { setErr("محاولات كثيرة — انتظر دقيقة ثم حاول مجددًا"); return true; } return false; };
  const login = async (e: React.FormEvent) => {
    e.preventDefault(); if (blocked()) return;
    const s = await matchLogin(auth, u, p);
    if (s) onOpen(auth, s); else fail("اسم المستخدم أو كلمة المرور غير صحيحة");
  };
  const tryPin = async (v: string) => {
    if (blocked()) return;
    const s = await matchPin(auth, v);
    if (s) onOpen(auth, s); else { setP(""); fail("الرقم السري غير صحيح"); }
  };
  const recover = async (e: React.FormEvent) => {
    e.preventDefault(); if (blocked()) return;
    if ((await hash(p)) !== auth.recovery) return fail("كلمة الاسترداد غير صحيحة");
    if (np.length < 4) return setErr("كلمة المرور الجديدة 4 أحرف على الأقل");
    const a = { ...auth, pass: await hash(np) }; saveAuth(a); onOpen(a, { role: "owner", name: a.user });
  };
  const useBio = async () => {
    if (!auth.bio || blocked()) return;
    if (await bioVerify(auth.bio)) onOpen(auth, { role: "owner", name: auth.user });
    else setErr("لم يتم التحقق بالبصمة — استخدم الرقم السري أو كلمة المرور");
  };
  const t = show ? "text" : "password";
  const swap = (m: "pin" | "login" | "recover") => { setMode(m); setErr(""); setP(""); };
  const titles = { pin: "أدخل الرقم السري", login: "الدفتر مقفل", recover: "استرداد الدخول" };
  const subs = { pin: "الرقم السري السريع لصاحب المحل أو للموظف.", login: "أدخل اسم المستخدم وكلمة المرور لفتح الدفتر.", recover: "أدخل كلمة الاسترداد ثم اختر كلمة مرور جديدة لصاحب المحل." };
  const bioBtn = bio && <button type="button" className="btn-ghost w-full" onClick={useBio}><Fingerprint className="size-4" />فتح بالبصمة / الوجه</button>;
  return (
    <Shell brand={shop} title={titles[mode]} sub={subs[mode]}>
      {mode === "pin" ? (
        <div className="space-y-4">
          <PinPad value={p} onChange={(v) => { setP(v); setErr(""); }} onSubmit={tryPin} />
          {err && <p className="text-center text-sm text-destructive">{err}</p>}
          {bioBtn}
          <button type="button" className="w-full text-sm text-primary" onClick={() => swap("login")}>الدخول بكلمة المرور</button>
        </div>
      ) : mode === "login" ? (
        <form onSubmit={login} className="space-y-4">
          <L t="اسم المستخدم"><input className="field" value={u} onChange={(e) => setU(e.target.value)} autoComplete="username" /></L>
          <L t="كلمة المرور"><input type={t} className="field" value={p} onChange={(e) => setP(e.target.value)} autoComplete="current-password" /></L>
          <ShowToggle show={show} setShow={setShow} />
          {err && <p className="text-sm text-destructive">{err}</p>}
          <button className="btn w-full"><LockKeyhole className="size-4" />فتح الدفتر</button>
          {bioBtn}
          {hasAnyPin(auth) && <button type="button" className="w-full text-sm text-primary" onClick={() => swap("pin")}>الدخول بالرقم السري</button>}
          <button type="button" className="w-full text-sm text-muted-foreground" onClick={() => swap("recover")}>نسيت كلمة المرور؟ (لصاحب المحل)</button>
        </form>
      ) : (
        <form onSubmit={recover} className="space-y-4">
          <L t="كلمة الاسترداد"><input type={t} className="field" value={p} onChange={(e) => setP(e.target.value)} /></L>
          <L t="كلمة مرور جديدة"><input type={t} className="field" value={np} onChange={(e) => setNp(e.target.value)} placeholder="4 أحرف على الأقل" /></L>
          <ShowToggle show={show} setShow={setShow} />
          {err && <p className="text-sm text-destructive">{err}</p>}
          <button className="btn w-full">تعيين وفتح</button>
          <button type="button" className="w-full text-sm text-primary" onClick={() => swap("login")}>رجوع</button>
        </form>
      )}
    </Shell>
  );
}

/** Numeric keypad for 4–6 digit PINs; submits automatically at 6 digits or on the check key. */
export function PinPad({ value, onChange, onSubmit }: { value: string; onChange: (v: string) => void; onSubmit: (v: string) => void }) {
  const press = (k: string) => { const v = (value + k).slice(0, 6); onChange(v); if (v.length === 6) onSubmit(v); };
  return (
    <div className="space-y-4" dir="ltr">
      <div className="flex justify-center gap-3" aria-label="الرقم السري">
        {Array.from({ length: 6 }, (_, i) => <span key={i} className={`size-3.5 rounded-full border ${i < value.length ? "border-primary bg-primary" : "border-border"}`} />)}
      </div>
      <input className="sr-only" aria-label="أدخل الرقم السري" inputMode="numeric" value={value}
        onChange={(e) => onChange(e.target.value.replace(/[٠-٩]/g, (c) => String(c.charCodeAt(0) - 0x660)).replace(/\D/g, "").slice(0, 6))}
        onKeyDown={(e) => { if (e.key === "Enter" && value.length >= 4) onSubmit(value); }} autoFocus />
      <div className="mx-auto grid max-w-64 grid-cols-3 gap-2">
        {["1", "2", "3", "4", "5", "6", "7", "8", "9"].map((k) => <button key={k} type="button" className="btn-ghost h-14 text-xl font-bold" onClick={() => press(k)}>{k}</button>)}
        <button type="button" aria-label="مسح" className="btn-ghost h-14" onClick={() => onChange(value.slice(0, -1))}><Delete className="size-5" /></button>
        <button type="button" className="btn-ghost h-14 text-xl font-bold" onClick={() => press("0")}>0</button>
        <button type="button" aria-label="دخول" className="btn h-14" disabled={value.length < 4} onClick={() => onSubmit(value)}><Check className="size-5" /></button>
      </div>
    </div>
  );
}

function ShowToggle({ show, setShow }: { show: boolean; setShow: (v: boolean) => void }) {
  return (
    <button type="button" onClick={() => setShow(!show)} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
      {show ? <EyeOff className="size-4" /> : <Eye className="size-4" />}إظهار كلمات المرور
    </button>
  );
}

function Shell({ brand = "دفتر زمرد", title, sub, foot, children }: { brand?: string; title: string; sub: string; foot?: string; children: ReactNode }) {
  return (
    <div className="flex min-h-dvh flex-col items-center justify-center p-4">
      <div className="mb-6 flex items-center gap-3">
        <div className="grid size-14 place-items-center rounded-2xl border border-gold/30 bg-hero text-gold"><Gem className="size-6" /></div>
        <div><h1 className="text-2xl font-bold">{brand}</h1><p className="text-sm text-muted-foreground">دفتر الأقساط والحسابات</p></div>
      </div>
      <div className="w-full max-w-md panel p-5">
        <h2 className="text-lg font-bold">{title}</h2>
        <p className="mb-5 mt-1 text-sm leading-6 text-muted-foreground">{sub}</p>
        {children}
      </div>
      {foot && <p className="mt-4 text-xs text-muted-foreground">{foot}</p>}
    </div>
  );
}
