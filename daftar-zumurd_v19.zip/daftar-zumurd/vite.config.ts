// @lovable.dev/vite-tanstack-config already includes tanstackStart, react, tailwind, nitro etc. — do NOT add them manually.
import { defineConfig } from "@lovable.dev/vite-tanstack-config";
import { VitePWA } from "vite-plugin-pwa";

// Client files land in a different folder per host; the offline worker must be written there.
const clientDir = process.env["VERCEL"]
  ? ".vercel/output/static"
  : process.env["NITRO_PRESET"] === "node-server"
    ? ".output/public"
    : "dist/client"; // Cloudflare Workers (default): static files are served from dist/client

export default defineConfig({
  tanstackStart: {
    server: { entry: "server" },
  },
  vite: {
    plugins: [
      VitePWA({
        strategies: "generateSW",
        registerType: "autoUpdate",
        injectRegister: null,
        manifest: false,
        filename: "sw.js",
        devOptions: { enabled: false },
        outDir: clientDir,
        workbox: {
          globDirectory: clientDir,
          globPatterns: ["**/*.{js,css,png,ico,svg,woff2,webmanifest}"],
          navigateFallback: null,
          cleanupOutdatedCaches: true,
          clientsClaim: true,
          skipWaiting: true,
          runtimeCaching: [
            {
              urlPattern: ({ request, url }) => request.mode === "navigate" && !url.pathname.startsWith("/~oauth"),
              handler: "NetworkFirst",
              options: { cacheName: "pages", networkTimeoutSeconds: 4 },
            },
            {
              urlPattern: ({ url }) => url.origin === "https://fonts.googleapis.com" || url.origin === "https://fonts.gstatic.com",
              handler: "StaleWhileRevalidate",
              options: { cacheName: "fonts" },
            },
          ],
        },
      }),
    ],
  },
});
