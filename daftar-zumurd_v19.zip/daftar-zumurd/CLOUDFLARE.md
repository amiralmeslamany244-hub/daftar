# رفع دفتر زمرد على Cloudflare

المشروع مجهّز للعمل على Cloudflare Workers (يُنشئ البناء ملف الإعداد تلقائيًا).

## الطريقة 1: من جهازك
1. ثبّت Node.js 22 أو أحدث.
2. افتح مجلد المشروع ونفّذ:
   ```
   npm install
   npx wrangler login
   npm run deploy
   ```
3. سيظهر رابط التطبيق على ‎*.workers.dev‎ في نهاية الأمر.

## الطريقة 2: من لوحة Cloudflare مع GitHub
1. ارفع المجلد إلى مستودع GitHub.
2. في Cloudflare: Workers & Pages ← Create ← Import a repository.
3. Build command: `npm run build`
4. Deploy command: `npx wrangler deploy`
5. اضغط Deploy.

ملاحظة: كل بيانات الدفتر محفوظة على جهاز المستخدم فقط، فلا تحتاج قاعدة بيانات ولا مفاتيح سرية.
