<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

## Project rules
- All ledger data and the local lock live in browser localStorage via `src/lib/store.ts`; there is no server or account, so every feature must work offline on one device.
- Screens are tabs inside `src/components/app/AppShell.tsx` (single `/` route), keeping the lock gate in front of all data.
- Users and permissions live in `Auth` (owner + `staff[]`) with rules in `can()` in `src/lib/store.ts`; UI hides actions via `useApp().can`, so add new restricted actions there first. Why: one tested source of truth for who can do what.
- Fingerprint unlock uses a local WebAuthn platform credential (`src/lib/biometric.ts`) with no server verification. Why: the app is offline-only; the device's own check is the gate.
- Display preferences (theme, text size, receipt paper) live in their own localStorage key via `src/lib/display.ts`, not in the ledger. Why: they are per-device and must apply on the lock screen and survive backup restores.
